#!/bin/bash
#
# respin_upgrade.sh by Mark Lord
#
# This script is used to maintain a root filesystem (rootfs) image
# for the empeg, automatically repacking it (and a new kernel)
# into an existing .upgrade file.  This works for builder images
# as well as for regular software images for the empeg.

## Make sure we have all of the necessary commands in our $PATH:
missing=n
for cmd in cp mv ls wc cat mkdir rmdir mount umount gzip gunzip mirrordir upgrader ; do
	t="`type $cmd 2>&1`"
	if [ "${t##*: }" == "not found" ]; then
		echo "command $cmd: not found" 1>&2
		missing=y
	fi
done
[ "$missing" == "y" ] && exit -1

#set -x

# We need an existing rootfs image to begin with:
#
if [ ! -e _dev_hda5.gz -a ! -e hda5_zeroed ]; then
	echo "_dev_hda5.gz: not found" 1>&2
	echo "hda5_zeroed: not found" 1>&2
fi

# We need either a parameter for the name of the existing .upgrade file,
# or a .upgrade file must already exist in this directory.
# This script only updates an existing .upgrade file;
# it does not create a new one from scratch.
#
IMAGE="$1"
if [ "$1" = "" ]; then
	if [ "`ls -1 *.upgrade 2>/dev/null | wc -l`" = "1" ]; then
		IMAGE="`ls -1 *.upgrade`"
	else
		echo "missing .upgrade file parameter"
		exit 1
	fi
fi
cat $IMAGE > /dev/null || exit 1

# Unpack existing _dev_hda5.gz as a starting point, if it exists.
# This also gets rid of the pesky .gz copy, which could mess us up later.
#
[ -e _dev_hda5.gz ] && gunzip _dev_hda5.gz

# hda5_zeroed is a mostly zeroed/empty ext2 filesystem in a file,
# with all of the "right" characteristics needed for the empeg rootfs.
# How it was originally made has been forgotten.
# If it exists, then use it rather than the original _dev_hda5 file,
# because it will compress better, and because we're replacing all
# of the contents with new stuff anyway.
#
[ -e hda5_zeroed ] && cp hda5_zeroed _dev_hda5

# Mount the old rootfs image
#
mkdir -p t || exit 1
mount _dev_hda5 t -o loop || exit 1

# Replace rootfs contents with latest from the hda5/ source directory
#
mirrordir -v hda5/ t/ || exit 1

# Unmount, and compress the new rootfs image
#
umount t
rmdir t
gzip -9 _dev_hda5 || exit 1

# Inject the new rootfs into the existing .upgrade file
#
upgrader --repack=HDA5,_dev_hda5.gz $IMAGE || exit 1
[ -e hda5_zeroed ] && rm _dev_hda5.gz
mv new.upgrade temp.upgrade

# Inject the latest kernel into the updated .upgrade file
#
upgrader --repack=KERNEL,_proc_empeg_kernel temp.upgrade || exit 1
rm temp.upgrade

# Now rename the original .upgrade file, and replace it with the new one
#
mv $IMAGE $IMAGE.old
echo "Moving new.upgrade to $IMAGE"
mv new.upgrade $IMAGE

# Done.
#
echo
