//
// upgrader.c by Mark Lord, Copyright 2003-2006
//
// This code is redistributable under the terms of the GPL.
//
#define PROGRAM_VERSION	"0.94"

// An empeg .upgrade file has this format:
//
// +------------------------------------------------------------------------+
// |  overall_length (u32), not including this field or the crc field       |
// +------------------------------------------------------------------------+
// |  chunk_type (u32)                                                      |
// +------------------------------------------------------------------------+
// |  chunk_length (u32), bytecount for chunk_data                          |
// +------------------------------------------------------------------------+
// |  chunk_data (chunk_length bytes)                                       |
// +------------------------------------------------------------------------+
//  ...                                  ...                             ...
// +------------------------------------------------------------------------+
// |  chunk_type (u32)                                                      |
// +------------------------------------------------------------------------+
// |  chunk_length (u32), bytecount for chunk_data                          |
// +------------------------------------------------------------------------+
// |  chunk_data (chunk_length bytes)                                       |
// +------------------------------------------------------------------------+
// |  overall_crc (u32), calculated over chunk_data (only)                  |
// +------------------------------------------------------------------------+
//
// In theory, the entire sequence could be repeated multiple times within a file.
// But in practice, the .upgrade file contains exactly *one* such sequence.
// Therefore, we have:   file_size == (4 + overall_length + 4)

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>
#include <string.h>
#ifdef linux
#include <linux/types.h>
#else
typedef unsigned int __u32;
typedef unsigned char __u8;
#endif

#ifdef __BIG_ENDIAN__
#define htole(x) \
     ((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >>  8) | \
      (((x) & 0x0000ff00) <<  8) | (((x) & 0x000000ff) << 24))
#else
#define htole(x) (x)
#endif

//
// chunk_type definitions from "defines.h", part of a GPL'd UpgradeSplitter package by sven@incase.de
//
#define UPGRADER_VERSION	2
#define CHUNK_INFO		0x00
#define CHUNK_WHAT		0x01
#define CHUNK_RELEASE		0x02
#define CHUNK_VERSION		0x03
#define CHUNK_HWREV		0x04
#define CHUNK_FLASHLOADER	0x10
#define CHUNK_FLASHKERNEL	0x11
#define CHUNK_FLASHRAMDISK	0x12
#define CHUNK_FLASHRANDOM	0x13
#define CHUNK_PUMPHDA		0x20
#define CHUNK_PUMPHDA1		0x21
#define CHUNK_PUMPHDA2		0x22
#define CHUNK_PUMPHDA3		0x23
#define CHUNK_PUMPHDA4		0x24
#define CHUNK_PUMPHDA5		0x25
#define CHUNK_PUMPHDA6		0x26
#define CHUNK_PUMPHDA7		0x27
#define CHUNK_PUMPHDA8		0x28
#define CHUNK_PUMPHDB		0x30
#define CHUNK_PUMPHDB1		0x31
#define CHUNK_PUMPHDB2		0x32
#define CHUNK_PUMPHDB3		0x33
#define CHUNK_PUMPHDB4		0x34
#define CHUNK_PUMPHDB5		0x35
#define CHUNK_PUMPHDB6		0x36
#define CHUNK_PUMPHDB7		0x37
#define CHUNK_PUMPHDB8		0x38
#define CHUNK_PUMPHDC		0x40
#define CHUNK_PUMPHDC1		0x41
#define CHUNK_PUMPHDC2		0x42
#define CHUNK_PUMPHDC3		0x43
#define CHUNK_PUMPHDC4		0x44
#define CHUNK_PUMPHDC5		0x45
#define CHUNK_PUMPHDC6		0x46
#define CHUNK_PUMPHDC7		0x47
#define CHUNK_PUMPHDC8		0x48
#define CHUNK_UPGRADERVERSION	0xFF

/*
 * Note:  A "partition_table" chunk causes the firmware to check
 * whether the drive has a valid partition table.  If not,
 * the firmware writes a standard partition table, as follows:
 *
 * Disk /dev/hda: 16 heads, 63 sectors, ?????  cylinders
 * Units = cylinders of 1008 * 512 bytes
 *
 *    Device Boot    Start       End    Blocks   Id  System
 * /dev/hda1             1        66     33232+   5  Extended   (container for root/swap)
 * /dev/hda2            67       132     33264   83  Linux      (spare)
 * /dev/hda3           133       165     16632   10  OPUS       (dynamic data)
 * /dev/hda4           166     ?????  ????????   83  Linux      (music)
 * /dev/hda5             1        33     16569   83  Linux      (root)
 * /dev/hda6            34        66     16600+  82  Linux swap (swap)
 *
 * The /dev/hda4 (music partition) uses all remaining space on the drive.
 *
 * Or at least that's how we think it works.  It might just write the
 * partition table regardless every time.. gotta test it to find out.
 */
typedef enum {display_text, program_flash, partition_table, pump_partition} chunk_action_t;

typedef struct chunk_s {
	__u32		id;
	const char	*name;
	chunk_action_t	action;
	char		*target;
} chunk_t;

static chunk_t chunks[] =
{	{CHUNK_INFO,		"INFO",		display_text,	NULL},
	{CHUNK_WHAT,		"WHAT",		display_text,	NULL},
	{CHUNK_RELEASE,		"RELEASE",	display_text,	NULL},
	{CHUNK_VERSION,		"VERSION",	display_text,	NULL},
 
	{CHUNK_FLASHLOADER,	"LOADER",	program_flash,	"/proc/flash_00000"},
	{CHUNK_FLASHKERNEL,	"KERNEL",	program_flash,	"/proc/flash_00000"},
	{CHUNK_FLASHRAMDISK,	"RAMDISK",	program_flash,	"/proc/flash_00000"},
	{CHUNK_FLASHRANDOM,	"RANDOM",	program_flash,	"/proc/flash_00000"},

	{CHUNK_PUMPHDA,		"HDA",		partition_table,"/dev/hda"},
	{CHUNK_PUMPHDA1,	"HDA1",		pump_partition,	"/dev/hda1"},
	{CHUNK_PUMPHDA2,	"HDA2",		pump_partition,	"/dev/hda2"},
	{CHUNK_PUMPHDA3,	"HDA3",		pump_partition,	"/dev/hda3"},
	{CHUNK_PUMPHDA4,	"HDA4",		pump_partition,	"/dev/hda4"},
	{CHUNK_PUMPHDA5,	"HDA5",		pump_partition,	"/dev/hda5"},
	{CHUNK_PUMPHDA6,	"HDA6",		pump_partition,	"/dev/hda6"},
	{CHUNK_PUMPHDA7,	"HDA7",		pump_partition,	"/dev/hda7"},
	{CHUNK_PUMPHDA8,	"HDA8",		pump_partition,	"/dev/hda8"},

	{CHUNK_PUMPHDB,		"HDB",		partition_table,"/dev/hdb"},
	{CHUNK_PUMPHDB1,	"HDB1",		pump_partition,	"/dev/hdb1"},
	{CHUNK_PUMPHDB2,	"HDB2",		pump_partition,	"/dev/hdb2"},
	{CHUNK_PUMPHDB3,	"HDB3",		pump_partition,	"/dev/hdb3"},
	{CHUNK_PUMPHDB4,	"HDB4",		pump_partition,	"/dev/hdb4"},
	{CHUNK_PUMPHDB5,	"HDB5",		pump_partition,	"/dev/hdb5"},
	{CHUNK_PUMPHDB6,	"HDB6",		pump_partition,	"/dev/hdb6"},
	{CHUNK_PUMPHDB7,	"HDB7",		pump_partition,	"/dev/hdb7"},
	{CHUNK_PUMPHDB8,	"HDB8",		pump_partition,	"/dev/hdb8"},

	{CHUNK_PUMPHDC,		"HDC",		partition_table,"/dev/hdc"},
	{CHUNK_PUMPHDC1,	"HDC1",		pump_partition,	"/dev/hdc1"},
	{CHUNK_PUMPHDC2,	"HDC2",		pump_partition,	"/dev/hdc2"},
	{CHUNK_PUMPHDC3,	"HDC3",		pump_partition,	"/dev/hdc3"},
	{CHUNK_PUMPHDC4,	"HDC4",		pump_partition,	"/dev/hdc4"},
	{CHUNK_PUMPHDC5,	"HDC5",		pump_partition,	"/dev/hdc5"},
	{CHUNK_PUMPHDC6,	"HDC6",		pump_partition,	"/dev/hdc6"},
	{CHUNK_PUMPHDC7,	"HDC7",		pump_partition,	"/dev/hdc7"},
	{CHUNK_PUMPHDC8,	"HDC8",		pump_partition,	"/dev/hdc8"}
};

static int
make_ftp_cmd (char *cmd, char *ftp_user, char *ftp_passwd, char *extra, char *empeg_host, char *target)
{
	int	len;
	char	c;

	if (0 == strcmp(empeg_host, "--extract")) {
		len = sprintf(cmd, "cat - >");
		while ((c = *target++)) {
			if (c == '/')
				c = '_';
			cmd[len++] = c;
		}
		cmd[len] = '\0';
		return len;
	}
	
	len = sprintf(cmd, "ncftpput -E -c");
	if (ftp_user)
		len += sprintf(cmd+len, " -u \"%s\"", ftp_user);
	if (ftp_passwd)
		len += sprintf(cmd+len, " -p \"%s\"", ftp_passwd);
	if (extra)
		len += sprintf(cmd+len, " %s", extra);
	len += sprintf(cmd+len, " \"%s\"", empeg_host);
	if (target)
		len += sprintf(cmd+len, " \"%s\"", target);
	return len;
}

static int
process_chunk (char *empeg_host, char *ftp_user, char *ftp_passwd, int final_pass, int chunk_index, __u32 chunk_type, __u32 chunk_length, __u8 *chunk_data)
{
	int	i, skip_ws, dummy;
	__u32	version;

	dummy = 0 == strcmp(empeg_host, "--dummy") || 0 == strncmp(empeg_host, "--repack", 8);
	if (final_pass)
		printf("index=%u: ", chunk_index);
	if (chunk_type == CHUNK_UPGRADERVERSION) {
		version = htole(*(__u32 *)chunk_data);
		if (final_pass) {
			printf("UPGRADE   Requires upgrader version: %u\n", version);
			fflush(stdout);
		}
		if (version != UPGRADER_VERSION)
			fprintf(stderr, "Error, wrong upgrader version, expected %u, found %u\n", UPGRADER_VERSION, version);
		return 0;
	} else if (chunk_type == CHUNK_HWREV) {
		if (final_pass) {
			printf("HWREV     Supported hardware versions: ");
			skip_ws = 2;
			for (i = 0; i < chunk_length; ++i) {
				char c = chunk_data[i];
				if (c == '\t' || c == ' ' || c == '\n' || c == '\r') {
					if (!skip_ws) {
						skip_ws = 1;
					}
				} else {
					if (skip_ws == 1) {
						putchar(',');
					}
					skip_ws = 0;
					putchar(c);
				}
			}
			putchar('\n');
			fflush(stdout);
		}
		return 0;
	} else for (i = 0; i < (sizeof(chunks)/sizeof(chunks[0])); ++i) {
		chunk_t	*c = &chunks[i];
		char	*target = c->target, target_buf[32];
		if (chunk_type == c->id) {
			if (c->action == display_text) {
				if (final_pass && chunk_length) {
					int prefix = 0;
					printf("%-9s ", c->name);
					for (i = 0; i < chunk_length; i++) {
						char d = chunk_data[i];
						if (prefix) {
							printf("%-9s ", "");
							prefix = 0;
						}
						putchar(d);
						if (d == '\n')
							prefix = 1;
					}
					if (chunk_data[i-1] != '\n')
						putchar('\n');
					fflush(stdout);
				}
				return 0;
			}
			if (c->action == program_flash) {
				__u32 chunk_offset;
				if (chunk_length < 5) {
					fprintf(stderr, "Error, flash chunk (0x%02x) too small\n", chunk_type);
					return EINVAL;
				}
				chunk_offset = htole(*(__u32 *)chunk_data);
				chunk_data += 4;
				chunk_length -= 4;
				if ((chunk_offset + chunk_length) > 0x100000) {
					fprintf(stderr, "Error, flash chunk (0x%02x) too large: 0x%x:0x%x\n", chunk_type, chunk_offset, chunk_length);
					return EINVAL;
				}
				//
				// FIXME: should also check per-partition lengths, right?
				//
				if (chunk_offset == 0x10000) {
					target = "/proc/empeg_kernel";
				} else {
					sprintf(target_buf, "/proc/flash_%05x", chunk_offset);
					target = target_buf;
				}
			}
			if (final_pass) {

				printf("%-9s %s, size=%u bytes\n", c->name, target, chunk_length);
				fflush(stdout);
				if (chunk_type == CHUNK_FLASHLOADER && 0 != strcmp(empeg_host, "--extract")) {
					chunk_data += chunk_length;
					chunk_length = 0;
				}
#if 1
				if (chunk_type == CHUNK_FLASHKERNEL && 0 != strcmp(empeg_host, "--extract")) {
					chunk_data += chunk_length;
					chunk_length = 0;	// avoid wiping out the Hijack kernel
				}
#endif
				if (chunk_length == 0) {
					printf("          --> SKIPPED\n");
					fflush(stdout);
				} else {
					static char cmd[4096], gunzip[] = "gunzip | ";
					int len = 0;
					//
					// Do the actual upgrade here:
					//
					//target = "/dev/null";		// uncommment for DEBUGGING
					//
					if (c->action == pump_partition)
						len += sprintf(cmd, "%s", gunzip);
					len += make_ftp_cmd(cmd+len, ftp_user, ftp_passwd, NULL, empeg_host, target);
					printf("          --> pumping:  %s\n", cmd);
					fflush(stdout);
					if (!dummy) {
						FILE *p = popen(cmd, "w");
						if (p == NULL) {
							fprintf(stderr, "popen(\"%s\") failed\n", cmd);
							return EIO;
						}
						while (chunk_length > 0) {
							size_t rc = fwrite(chunk_data, 1, chunk_length, p);
							//printf("          --> wrote %u of %u bytes\n", rc, chunk_length);
							if (rc != chunk_length) {
								if (ferror(p)) {
									fprintf(stderr, "fwrite() failed\n");
									pclose(p);
									return EIO;
								}
							}
							chunk_data   += rc;
							chunk_length -= rc;
						}
						pclose(p);
					}
				}
			}
			return 0;
		}
	}
	fprintf(stderr, "Error, unknown chunk_type: 0x%02x\n", chunk_type);
	return EINVAL;
}

//
// CRC32 table taken from linux/arch/arm/special/fast_crc32.c
//
static unsigned long crc_table[256] = {
	0x00000000,0x77073096,0xee0e612c,0x990951ba,0x076dc419,0x706af48f,0xe963a535,0x9e6495a3,
	0x0edb8832,0x79dcb8a4,0xe0d5e91e,0x97d2d988,0x09b64c2b,0x7eb17cbd,0xe7b82d07,0x90bf1d91,
	0x1db71064,0x6ab020f2,0xf3b97148,0x84be41de,0x1adad47d,0x6ddde4eb,0xf4d4b551,0x83d385c7,
	0x136c9856,0x646ba8c0,0xfd62f97a,0x8a65c9ec,0x14015c4f,0x63066cd9,0xfa0f3d63,0x8d080df5,
	0x3b6e20c8,0x4c69105e,0xd56041e4,0xa2677172,0x3c03e4d1,0x4b04d447,0xd20d85fd,0xa50ab56b,
	0x35b5a8fa,0x42b2986c,0xdbbbc9d6,0xacbcf940,0x32d86ce3,0x45df5c75,0xdcd60dcf,0xabd13d59,
	0x26d930ac,0x51de003a,0xc8d75180,0xbfd06116,0x21b4f4b5,0x56b3c423,0xcfba9599,0xb8bda50f,
	0x2802b89e,0x5f058808,0xc60cd9b2,0xb10be924,0x2f6f7c87,0x58684c11,0xc1611dab,0xb6662d3d,
	0x76dc4190,0x01db7106,0x98d220bc,0xefd5102a,0x71b18589,0x06b6b51f,0x9fbfe4a5,0xe8b8d433,
	0x7807c9a2,0x0f00f934,0x9609a88e,0xe10e9818,0x7f6a0dbb,0x086d3d2d,0x91646c97,0xe6635c01,
	0x6b6b51f4,0x1c6c6162,0x856530d8,0xf262004e,0x6c0695ed,0x1b01a57b,0x8208f4c1,0xf50fc457,
	0x65b0d9c6,0x12b7e950,0x8bbeb8ea,0xfcb9887c,0x62dd1ddf,0x15da2d49,0x8cd37cf3,0xfbd44c65,
	0x4db26158,0x3ab551ce,0xa3bc0074,0xd4bb30e2,0x4adfa541,0x3dd895d7,0xa4d1c46d,0xd3d6f4fb,
	0x4369e96a,0x346ed9fc,0xad678846,0xda60b8d0,0x44042d73,0x33031de5,0xaa0a4c5f,0xdd0d7cc9,
	0x5005713c,0x270241aa,0xbe0b1010,0xc90c2086,0x5768b525,0x206f85b3,0xb966d409,0xce61e49f,
	0x5edef90e,0x29d9c998,0xb0d09822,0xc7d7a8b4,0x59b33d17,0x2eb40d81,0xb7bd5c3b,0xc0ba6cad,
	0xedb88320,0x9abfb3b6,0x03b6e20c,0x74b1d29a,0xead54739,0x9dd277af,0x04db2615,0x73dc1683,
	0xe3630b12,0x94643b84,0x0d6d6a3e,0x7a6a5aa8,0xe40ecf0b,0x9309ff9d,0x0a00ae27,0x7d079eb1,
	0xf00f9344,0x8708a3d2,0x1e01f268,0x6906c2fe,0xf762575d,0x806567cb,0x196c3671,0x6e6b06e7,
	0xfed41b76,0x89d32be0,0x10da7a5a,0x67dd4acc,0xf9b9df6f,0x8ebeeff9,0x17b7be43,0x60b08ed5,
	0xd6d6a3e8,0xa1d1937e,0x38d8c2c4,0x4fdff252,0xd1bb67f1,0xa6bc5767,0x3fb506dd,0x48b2364b,
	0xd80d2bda,0xaf0a1b4c,0x36034af6,0x41047a60,0xdf60efc3,0xa867df55,0x316e8eef,0x4669be79,
	0xcb61b38c,0xbc66831a,0x256fd2a0,0x5268e236,0xcc0c7795,0xbb0b4703,0x220216b9,0x5505262f,
	0xc5ba3bbe,0xb2bd0b28,0x2bb45a92,0x5cb36a04,0xc2d7ffa7,0xb5d0cf31,0x2cd99e8b,0x5bdeae1d,
	0x9b64c2b0,0xec63f226,0x756aa39c,0x026d930a,0x9c0906a9,0xeb0e363f,0x72076785,0x05005713,
	0x95bf4a82,0xe2b87a14,0x7bb12bae,0x0cb61b38,0x92d28e9b,0xe5d5be0d,0x7cdcefb7,0x0bdbdf21,
	0x86d3d2d4,0xf1d4e242,0x68ddb3f8,0x1fda836e,0x81be16cd,0xf6b9265b,0x6fb077e1,0x18b74777,
	0x88085ae6,0xff0f6a70,0x66063bca,0x11010b5c,0x8f659eff,0xf862ae69,0x616bffd3,0x166ccf45,
	0xa00ae278,0xd70dd2ee,0x4e048354,0x3903b3c2,0xa7672661,0xd06016f7,0x4969474d,0x3e6e77db,
	0xaed16a4a,0xd9d65adc,0x40df0b66,0x37d83bf0,0xa9bcae53,0xdebb9ec5,0x47b2cf7f,0x30b5ffe9,
	0xbdbdf21c,0xcabac28a,0x53b39330,0x24b4a3a6,0xbad03605,0xcdd70693,0x54de5729,0x23d967bf,
	0xb3667a2e,0xc4614ab8,0x5d681b02,0x2a6f2b94,0xb40bbe37,0xc30c8ea1,0x5a05df1b,0x2d02ef8d};

//
// CRC32 function taken from linux/arch/arm/special/fast_crc32.c
//
static inline __u32
crc32 (unsigned char *buf, int len)
{
	__u32	c = 0;
	int	n;

	for (n = 0; n < len; n++)
		c = crc_table[(c ^ buf[n]) & 0xff] ^ (c >> 8);
	return c;
}

static void *mmap_file (const char *pathname, __u32 *fsize)
{
	void *data;
	int fd, err;
	struct stat st;
	//
	// Open the file
	//
	fd = open(pathname, O_RDONLY);
	if (fd == -1) {
		err = errno;
		perror(pathname);
		exit(err);
	}
	//
	// Get file size
	//
	if (fstat(fd, &st) == -1) {
		err = errno;
		perror(pathname);
		exit(err);
	}
	//
	// Map entire file into memory
	//
	data = mmap(0, st.st_size, PROT_READ, MAP_SHARED, fd, 0);
	if (data == MAP_FAILED) {
		err = errno;
		perror(pathname);
		exit(err);
	}
	//close(fd); // Not needed once mmap'd
	*fsize = st.st_size;
	return data;
}

static const char *chunk_name (int chunk_type)
{
	int i;

	for (i = 0; i < (sizeof(chunks)/sizeof(chunks[0])); ++i) {
		chunk_t	*c = &chunks[i];
		if (chunk_type == c->id)
			return c->name;
	}
	return "????????";
}

int
main (int argc, char *argv[])
{
	int		final_pass, do_extract = 0, do_repack = 0;
	void		*data, *repack_data = NULL, *repack_buf = NULL;
	unsigned int	offset, repack_offset = 4;
	__u32		overall_length, overall_crc, crc;
	char		*empeg_host, *upgrade_file, *ftp_user = NULL, *ftp_passwd = NULL;
	static char	cmd[4096];
	static char	*repack_fname, *repack_name = NULL, repack_fname_buf[4096];
	int		repack_index = -1;
	__u32		fsize, repack_fsize;
	char		*myname = argv[0];

	if (strrchr(myname,'/'))
		myname = strrchr(myname,'/');
	printf("\n%s: Empeg/RioCar Ethernet Upgrade Tool, version %s, (c)2003 by Mark Lord\n\n", myname, PROGRAM_VERSION);
	printf("    --> requires Hijack kernel on player\n");
	printf("    --> requires gunzip and ncftpput in $PATH\n\n");
	//
	// Verify args
	//
	if (argc < 3 || argc > 5 || !*argv[1] || !*argv[2]) {
		fprintf(stderr, "Bad/missing parameters\nUsage:  %s  <host_addr>  <upgrade_file>  [ftp_user]  [ftp_passwd]\n", myname);
		fprintf(stderr, "        Either '--dummy' or '--extract' can be used in place of <host_addr>\n");
		fprintf(stderr, "        There is also a '--repack=<index>,<fname>' flag for experts\n\n");
		exit(EINVAL);
	}
	empeg_host   = argv[1];
	if (!strcmp(empeg_host, "--extract")) {
		do_extract = 1;
	} else if (0 == strncmp(empeg_host, "--repack", 8)) {
		repack_fname = repack_fname_buf;
		if (2 != sscanf(empeg_host, "--repack=%u,%s", &repack_index, repack_fname)) {
			char *comma;
			repack_index = -1;
			if (1 != sscanf(empeg_host, "--repack=%s", repack_fname)) {
				fprintf(stderr, "bad parameter: %s\n", empeg_host);
				exit(EINVAL);
			}
			comma = strchr(repack_fname,',');
			if (!comma || !comma[1] || comma == repack_fname) {
				fprintf(stderr, "bad parameter: %s\n", empeg_host);
				exit(EINVAL);
			}
			repack_name = repack_fname;
			repack_fname = comma + 1;
			*comma = '\0';
		}
		do_repack = 1;
	}
	upgrade_file = argv[2];

	if (argc >= 4 && *argv[3])
		ftp_user = argv[3];
	if (argc >= 5 && *argv[4])
		ftp_passwd = argv[4];
	
	data = mmap_file(upgrade_file, &fsize);
	//
	// Do a minimum length check
	//
	if (fsize < 24) {
		fprintf(stderr, "Error, upgrade file too small\n");
		exit(EINVAL);
	}
	//
	// Verify the overall_length field.
	// This includes only the overall data, not itself or the final overall_crc field.
	//
	overall_length = htole(*(__u32 *)data);
	if ((overall_length + 8) != fsize) {
		fprintf(stderr, "Error, size mismatch: %u vs %u\n", overall_length + 8, fsize);
		exit(EINVAL);
	}
	//
	// Adjust "data" to point at the actual data, rather than at the overall_length field.
	// This makes everything after here just so much simpler to deal with.
	//
	data += 4;
	//
	// Verify the overall_crc field.
	// This includes only the overall data, not itself or the overall_length field.
	//
	overall_crc = *(__u32 *)(data + overall_length);
	crc = crc32(data, overall_length);
	if (crc != overall_crc) {
		fprintf(stderr, "Error, CRC mismatch: %08x vs %08x\n", overall_crc, crc);
		exit(EINVAL);
	}
	if (do_repack) {
		repack_data = mmap_file(repack_fname, &repack_fsize);
		repack_buf = malloc(overall_length + 8 + repack_fsize);
		repack_offset = 4;
		if (repack_buf == NULL) {
			int err = errno;
			perror("malloc() failed");
			exit(err);
		}
	}
	//
	// Now process the Chunks in two passes:
	//	-- one pass to verify correct file structure, and
	//	-- a final pass to actually perform the upgrade operation
	//
	for (final_pass = 0; final_pass < 2; ++final_pass) {
		int chunk_index = 0;
		if (final_pass && !do_extract && !do_repack) {
			//
			// Try and force player into stand-by so that the upgrade will run faster
			// and also so that the player won't crash while we modify things underneath it.
			//
			make_ftp_cmd(cmd, ftp_user, ftp_passwd, "-Y \"site button=top.L\"", empeg_host, "/dev/null");
			strcat(cmd, " </dev/null");
			printf("Placing player into Stand-By for the upgrade:  %s\n\n", cmd);
			fflush(stdout);
			(void) system(cmd);
		}
		//
		// Loop over all Chunks
		//
		for (offset = 0; offset < (overall_length - 8);) {
			__u32	chunk_type   = htole(*(__u32 *)(data + offset));
			__u32	chunk_length = htole(*(__u32 *)(data + offset + 4));
			__u8	*chunk_data  =        (__u8  *)(data + offset + 8);

			if ((offset + chunk_length) > overall_length) {
				fprintf(stderr, "Error, chunk_length-%u too large: (%u + %u) vs (%u)\n",
					chunk_index, offset, chunk_length, overall_length);
				exit(EINVAL);
			}
			offset += 8 + chunk_length;	// for next iteration
			if (final_pass && do_repack) {
				if (chunk_index == repack_index || 0 == strcmp(chunk_name(chunk_type),repack_name)) {
					chunk_length = repack_fsize;
					if (chunk_type == CHUNK_FLASHLOADER || chunk_type == CHUNK_FLASHKERNEL || chunk_type == CHUNK_FLASHRAMDISK) {
						chunk_length += 4;
					}
				}
				*(__u32 *)(repack_buf + repack_offset) = htole(chunk_type);
				repack_offset += 4;
				*(__u32 *)(repack_buf + repack_offset) = htole(chunk_length);
				repack_offset += 4;
				if (chunk_index == repack_index || 0 == strcmp(chunk_name(chunk_type),repack_name)) {
					printf("Replacing chunk index=%d(%s) with contents of file '%s'\n",
						chunk_index, chunk_name(chunk_type), repack_fname);
					if (chunk_type == CHUNK_FLASHLOADER || chunk_type == CHUNK_FLASHKERNEL || chunk_type == CHUNK_FLASHRAMDISK) {
						*(__u32 *)(repack_buf + repack_offset) = *(__u32 *)chunk_data;
						repack_offset += 4;
						chunk_length -= 4;
					}
					chunk_data = repack_data;
				}
				if (chunk_length)
					memcpy(repack_buf + repack_offset, chunk_data, chunk_length);
				repack_offset += chunk_length;
			} else {
				int rc = process_chunk(empeg_host, ftp_user, ftp_passwd, final_pass, chunk_index, chunk_type, chunk_length, chunk_data);
				if (rc)
					exit(rc);
			}
			++chunk_index;			// for next iteration
		}
		//
		// Ensure we ended without anything leftover (other than the CRC)
		//
		if (offset != overall_length) {
			fprintf(stderr, "Error, excess data after final chunk:  %u vs %u\n", offset, overall_length);
			exit(EINVAL);
		}
		if (final_pass && do_repack) {
			int fd;
			*(__u32 *) repack_buf                  = htole(repack_offset - 4);
			*(__u32 *)(repack_buf + repack_offset) = htole(crc32(repack_buf + 4, repack_offset - 4));
			repack_offset += 4;

			//FIXME
			printf("Writing repacked file as 'new.upgrade'\n");
			fd = open("new.upgrade", O_WRONLY|O_TRUNC|O_CREAT, 0644);
			write(fd, repack_buf, repack_offset);
			close(fd);
		}
	}

	if (!do_extract && !do_repack) {
		//
		// Reboot the player
		//
		make_ftp_cmd(cmd, ftp_user, ftp_passwd, "-Y \"site reboot\"", empeg_host, "/dev/null");
		strcat(cmd, " </dev/null");
		sleep(2);	// give a little time for writing to complete
		printf("Upgrade complete, rebooting:  %s\n\n", cmd);
		fflush(stdout);
		(void) system(cmd);
	}
	exit(0);
}
