===========================================================
                        EmpegFace
  A network remote control for the empeg/Rio car player.

                (c) 2003 by Tony Fabris
              http://www.oro.net/~tfabris

         Special thanks to Mark Lord, whose
         Hijack kernel makes this all possible,
         and to Charles Pogue for testing v1.0.
         And of course to the entire Empeg team!
===========================================================


Introduction
------------

EmpegFace is a utility for remotely controlling an empeg
car digital music player (www.empeg.com) across an ethernet
network.

It allows you to see a real-time updated display of the
player's screen, and to send commands to the player as if
you had pressed buttons on the faceplate or the remote.

EmpegFace has been tested on Windows 95/98 and Windows
2000. It should work on NT 4, ME and XP, too, but I haven't
tested it there.


Requirements
------------

- An empeg Car Mark 2 or Rio Car player.

- A working ethernet connection to the player.

- The Hijack replacement kernel from 
  empeg-hijack.sourceforge.net.

- Microsoft Internet Explorer 5 or later must be installed.
  This is not actually "used", but EmpegFace calls out to
  some of its DLL files.

- Microsoft Visual Basic 6.0 runtime files from
  support.microsoft.com/support/kb/articles/Q235/4/20.asp
  (you probably already have this installed).

- Microsoft winsock control MSWINSCK.OCX (included).


Starting EmpegFace
------------------

EmpegFace can be run from anywhere on the system. Unzip
these files to any directory you like and run FACE.EXE.
Make sure to unzip all of the files into the same folder.
There should be subdirectories for the included skin
files so make sure to use the "directories" option when
unzipping.

If you get an error message saying that a DLL file is
missing or out-of-date, download and install the VB6
runtime files from Microsoft, as listed above. Either
that, or you need to install IE 5 or later.

If you get an error message about MSWINSCK.OCX, the file
is included in this distribution, in an obviously-named
sub folder. Copy the file to the WINDOWS\SYSTEM folder on
Win 95/98, or copy it to the WINNT\SYSTEM32 folder on
Windows 2000 or XP. If you've already got the file, don't
overwrite it with this version, use the one you've got.


Using EmpegFace
---------------

- Make sure the address of your player is correctly
  entered into the configuration screen. The address can
  also be a name, such as "empeg", if it carries this
  name on your network. Put only the address into the
  configuration screen, without any "http://" at the
  beginning, and no slashes or directories at the end.
  If your player is on a dynamic address, you can use
  the FindEmpeg utility to add it to your hosts file.
  Please search the empeg FAQ for information on how
  to do this.

- Double-click on the main window or on the system tray
  icon to minimize and restore the program. The Esc key
  also minimizes.

- Drag anywhere on the program to move it on the screen.

- If you click and hold on one of the buttons, it will be
  the same as if you'd pressed and held one of the buttons
  on the player. For instance, if you hold down on the
  bottom faceplate button, it will toggle between visuals
  mode and text mode.

- If you drag on one of the buttons, it will still move
  the program around on the screen and it will also send
  the "button down" command to the player. But to prevent
  "stuck" buttons, it will send the "button up" command
  to the player as soon as you start moving the window.
  In other words, dragging a button is the same as clicking
  a button.

- When clicking on the volume knob, use the left edge of
  the knob for volume down, and the right edge for volume
  up. Click on the center of the volume knob for a press on
  the middle of the volume "button". Note that the volume
  up and down clicks don't have a "long press" feature;
  each click of the mouse corresponds to one turn/click of
  the knob itself. If you wish to have a hold-down feature
  for the volume, use the volume buttons on the remote.

- You can't turn off both the remote and the face. If you
  turn them both off, then one of them will reappear. If
  you want to make them both hidden, minimize it to the
  system tray.

- If you are lucky enough to own more than one empeg, you
  can run multiple instances of EmpegFace on the same
  computer. However, this only works if you create a new
  program folders for each one and put a separate copy of
  the EmpegFace program into each folder. You can also have
  different systray icons for each one by choosing a
  different screen color for each instance.


Keyboard Shortcuts
------------------

One of the windows must be focused for these to work.

  Alt+F4 .................. Exit program
  Esc ..................... Minimize program
  Space or Backspace ...... Play/Pause/Cancel (top button)
  Enter ................... OK (bottom button)
  Arrow Keys .............. Four directional face buttons
  Plus and Minus .......... Volume knob Up and Down
  . or * on keypad ........ Press on center of knob
  
  0 through 9 ............. 0 through 9 on the remote
  C ....................... Cancel/Mark on the remote
  I ....................... Info button on the remote
  V ....................... Visual button on the remote
  S ....................... Search button on the remote
  M ....................... Select Mode on the remote
  T or B .................. Tuner/Bank on the remote
  P ....................... Source/Power on the remote
  E ....................... Sound/Equalizer on the remote


A Word About CPU Cycles
-----------------------

To control the number of CPU cycles that the program
consumes, adjust the time between screen refreshes in
the configuration screen. This also controls how much
network bandwidth is used. The less time between screen
refreshes, the more CPU cycles will be consumed.

The program should only consume CPU cycles when it is
actively grabbing screen images from the player and
displaying them. To consume as few CPU cycles as possible,
minimize it to the system tray, or show only the remote
and leave the face hidden.


Known Problems with EmpegFace
-----------------------------

- Side effect of skin support: Button clicks do not work
  unless EmpegFace has been run with the system in 24-bit
  color mode. Not even 16-bit color will work. If you
  can't run your system in high color, use the keyboard
  shortcuts for the buttons.

- Sometimes there will be pauses when the screen graphics
  on EmpegFace will seem to freeze and the player won't
  respond to your mouse clicks. This is when the player
  is taking over its CPU for whatever reason (usually
  loading music into the cache), and during this time the
  Hijack web interface does not respond to communications.
  If this happens between a "Button Down" and a "Button Up"
  event, then the player will interpret this as a "long"
  press on the button. For instance, if you're changing to
  the next track, if the player pauses for a moment between
  the time you press the button and the time you release
  it, then it will briefly fast-forward instead of change
  tracks. This should not happen very often.

- If you can't see the graphics of the empeg screen, make
  sure that you are entering the correct address for the
  player, and that the player can be reached from Internet
  Explorer. For instance, if you have entered "empeg" as
  the location of the player in the configuration screen,
  make sure that Internet Explorer can successfully connect
  to "http://empeg". If IE doesn't work, EmpegFace won't
  work either.

- I haven't implemented long-presses for the keyboard
  shortcuts. Not certain if this is a good idea or not.

- Alpha transparency only works on Windows 2000 and later.
  This is a limitation of the operating system.


Wish List
---------

- Add a panel for special commands that you can't normally
  get by clicking buttons. Start maybe with something
  similar to the "Now Playing" window on CharcoalGray99's
  XML interface and expand it from there.

- Auto-locate the empeg on the LAN, similar to the
  FindEmpeg utility. Anyone know how to implement a
  broadcast packet and listen for returns in VB? Or wants
  to write me a DLL that I can call?

- Use proc/empeg_power to determine when the player is in
  sleep mode. No complaining if the pulse rate isn't in
  exact synch with the real standby light on the player,
  capice?

- Feature ideas, anyone?


Revision History
----------------

   Version 1.0, 06-24-2003:
   ------------------------

First release. Includes keyboard shortcuts for both the
remote and the face. ImageGrabber is a separate process.
Screen updates seem to work well even on slow systems.

   Version 1.1, 06-28-2003:
   ------------------------

- Skins! Skins! Skins! Please see Skins.txt for details.

- Bugfix: Screen picture, upon restore from minimize, was a
  stale image. It is now blanked upon restore from minimize
  and the next timed update is the current screen.

- Internal to code: removed need for additional second
  bitmap for the main form.

- Bugfix: Keyup code from another program no longer passes
  back to face.exe. (Alt+F4 on a window atop face no longer
  exits face, for example.)

- Alternate method of button hit testing (bitmaps). Thanks,
  Roger!

- Added by request: Dual monitor support. Experimental, let
  me know how it works.

- Added: Draw outline around button when you click on it.
  Not sure if my edge-finding algorithm is any good. I
  would be interested if any skins break it.

   Version 1.2, 08-05-2003:
   ------------------------

- Bugfix: Dragging the windows around the screen should no 
  longer have a strange repaint problem on some systems, 
  unless the system is dog-slow.

- Better graphics for Doublesize skin, courtesy 
  CharcoalGray99 and Rob Voisey.

- Bugfix: Double-click-and-hold no longer behaves strangely.

- Bugfix: When -minimized is on the command line or when 
  Start Minimized is in the configuration, changing the
  skin no longer causes the program to re-minimize.

- Side Effect: When the application is minimized, changing 
  the skin makes it un-minimize. This is good, it lets you 
  see the skin you changed to.

- Fix Deferred: Switching to an incorrect skin or "blank" 
  might (depending on what the hard disk looks like at the
  time) leave the current skin as-is instead of reloading 
  the default skin. Not easy to fix... and rather a minor 
  issue anyway. I could theoretically put up an error box
  if you get the skin wrong, but I hate modal error boxes.
  I'd rather just have the lack-of-a-skin-change be your
  clue that you got it wrong. A commercial product would
  have an error box or a CommonDialog for selecting a skin,
  but I'm not ready to invest that kind of time in this yet.

- Dual Monitor support seemed to work, so it's no longer 
  labeled as 'Experimental' in the configuration screen. 
  Note that this will allow the application to be placed 
  completely off-screen and its position 'saved' that way.
  So if you can't see the application, right-click on the 
  systray icon and deactivate dual monitor support.

- Fix Deferred: Less-than-24-bit screens, RGB hit tests for
  skinned buttons don't work. Can't easily support this 
  without rewriting the way I make skins. If you really 
  *need* this application to work for you on a 16-bit
  screen, contact me and I'll see what I can do.

- Bugfix: ImageGrabber no longer consumes 99 percent CPU 
  time in Task Manager when idling (when the app is 
  minimized to the system tray).

- Bugfix: Screen image updates no longer freeze when you 
  hold down a command button. In theory, this lets you see
  the results of a long-press as it's happening rather
  than having to guess. However, I've got notes in my code
  that it might screw up the responsiveness of the
  right-click menu. The image updates are supposed to
  freeze when the right-click menu is up. If you can
  reproduce a situation where the right-click menu is up
  and the image updates are continuing and you can't get
  the menu to respond, let me know.

- Feature Addition: Always on Top.

- Feature Addition: Alpha transparency. Only works on 
  Windows 2000 or later. 

   Version 1.2.1, 08-06-2003:
   --------------------------

- Fixed bug which caused transparency not to work on some
  supported systems. Note that transparency still only
  works on Windows 2000 and later.

   Version 1.5, 12-05-2003:
   ------------------------

- Removed the ImageGrabber code. Now uses the Winsock
  control and loads the images directly into memory without
  making a trip to the hard disk first. Hopefully making it
  more reliable in more environments. Thanks to Trevor Man
  and Bitt Faulk (and others) on the empeg BBS who offered
  help and advice, and who kept needling me until I finally
  did this. :-)

- You may delete the file IMAGEGRABBER.DLL from your hard
  disk if you wish.

- MSWINSCK.OCX is now required. See the notes above for
  installation instructions.

- Fixed a bug where sometimes the VFD-refresh timer would
  get reset to 1000.

- Added the "resolves to" box to the configuration screen.

   Version 1.6, 12-11-2003:
   ------------------------

- Windows can snap to each other and to the screen edge.
  "Snap" option is in the right-click menu. Skin authors:
  If you want your skins to snap exactly to the edge with
  no gap, please change your skins as described in the next
  entry, below.

- Fixed the bug in the RegionWindow code that required the
  skins to have one purple pixel all the way around the
  edge. Now your skins can go all the way up to the edge
  of the bitmap if you like. In fact, all skins should be
  edited now so that they are cropped exactly to the edge
  of the picture (so that they work with snap). Make sure
  to perform the exact same crop on your button hit test
  skins, too. And don't forget to edit the INI file to
  reposition your VFD after the crop.

- The "transparent" color in the skin file can no longer be
  arbitrary. It now *must* be 255,0,255.

- Edited the default skins that ship with EmpegFace so that
  they all go up to the edge of the picture exactly.

- Network name and IP Address are now shown in the Tooltip
  for the system tray icon.

- Systray icon changes color depending on the Screen Color
  selection.

- When changing colors, screen repaints with the existing
  screenshot instead of a blank rectangle (if there *is* a
  current screenshot to paint).

- Better handling of locked up connections, blank screen
  will paint instead of garbage screen.

- Tooltip and config screen will display (Connection Error)
  if the winsock control returns an error or if it takes
  longer than a few seconds to retrieve a screen shot.

- Window no longer blinks funny at program startup.

- Fixed a bug that caused button outlines to be drawn in
  semi-random places whenever you used a shortcut key.

- Fixed some more bugs with the -minimized startup option.

- Mouse pointer changes shape depending on whether you're
  over a clickable button.

- Reworked the configuration dialog box a little bit.

   Version 1.7, 12-13-2003:
   ------------------------

- True multiple monitor support. Snaps to edge of all
  screens when multiple monitors are used.

- Snap to screen edge now honors the taskbar if the taskbar
  has been set to "Always on Top" mode. It no longer snaps
  to the edge of the *screen* per se, it snaps to the edge
  of the *work area*, which is defined as the part of the
  screen that would be taken up by a maximized window. This
  means that the taskbar *must* be set to Always on Top
  mode if you want to snap to it. Note that other programs
  such as WinAmp and Trillian have the exact same behavior,
  probably for the same reason.

- Program now has a different mode for offscreen rescues.
  If the center point of the face or the remote is off
  screen, then it centers the window on the primary
  display the next time that window gets the focus.

- Side effect of multiple monitor support: Windows 95 and
  Windows NT 4 are no longer supported for snaps. Those
  operating systems do not have the capability for multiple
  monitors. The functions I'm calling to support multiple
  monitors don't exist on Windows 95 or Windows NT 4. You
  might get a snap to the left/top edge of the screen
  but that's about it.

- Removed the "Dual Monitor Support" checkbox. No longer
  needed with the new mode for offscreen rescues and the
  program's new awareness of multiple monitors.

- Forms no longer blink on screen when starting minimized.

- Fixed newly-induced bug where the skin for the remote
  would not get loaded at startup.

   Version 1.8, 12-15-2003:
   ------------------------

- Fixed bug that prevented snaps from working properly on
  systems with Large Fonts enabled. I had only tested it
  with Large Fonts back in the days before I was using
  the dual-monitor function calls. Forgot to test it after
  changing the way it detected the screen edges. Sigh.
  Remind me to locate and administer a dope slap to the
  man who invented "twips".

   Version 1.9 12-17-2003:
   ------------------------

- Added dropdown list for skin selection. Thanks to
  Meatballman for the kick in the pants. Note that you are
  now required to have Face.bmp, Remote.bmp, and Skin.ini
  in a skin folder before it will appear in this list.

- Added ability to show in taskbar. Thanks to Customsex
  for the example code.

- Configuration screen is set to always on top now, so that
  it doesn't get lost behind other windows when open.

