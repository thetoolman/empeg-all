
This file, OUT_CW.DLL, is a plug in for the WinAmp audio
player software. It was written by Justin Frankel, the
creator of WinAmp.

Its purpose is to allow continuous playback of audio
tracks that flow seamlessly into one another.

This file is not shipped with current versions of WinAmp.
I'm pretty sure that it shipped with older versions of
WinAmp (which is why I have it), and was removed because
it was experimental.

To use it, place it in your Winamp/Plugins folder, and
configure it via WinAmp's options menu.
