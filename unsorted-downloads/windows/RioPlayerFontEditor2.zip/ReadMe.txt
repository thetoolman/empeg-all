Font Editor for Empeg Rio Player
--------------------------------

written by Mourgoyiannis Spiros,
cypher@otenet.gr


  This utility provides you a friendly user interface that will help you create or alter any of the for basic font files (small.bf, medium.bf, large.bf, fontfile.raw) of the Empeg Rio Player device. I have test it under Windows 2000, and it works fine. I suppose that it will not have any problems at other windows platforms. If you experience any, then most propably you will solve them by upgrading the system's common controls DLL's. It was written in VC++ 6.0, with Win32 SDK, no MFC.

DETAILS:

  To start with you have either to create a new font file (using the menu commands at File->New), or to open an existing file. For details on how to retrieve a font file from the player refer to the FAQ section of the empeg BBS. The application will display all ASCII characters from code 32 to 255. Under each code number there are two boxes; one with the character in the way that Windows display it(left), and one with the character defined in the Rio font file(right). If you want to change the Window font paramters select the menu command File->Select GDI Font. Single clicking a box containing a rio character you select it. By double clicking it, a new dialog opens(EDIT DIALOG) which allows you to edit it. When a character is selected, you can view it enlarged at the bottom of the application window, and you can edit it, by either clicking the enlarged image or by selecting the menu command Edit->Define.
  
  When you select a character for editing, the EDIT DIALOG appears. Most of the dialog's area is being covered by a maximized display of the character(DRAW AREA). Above it, there is a slider bar with which you may easily define the width of the character. On the same way (by using the vertical slider) you can alter the height of the character, where permited (only in fontfile raw). Next to the slider bar there is a preview image, and under it two buttons with the selected color for the mouse left click action. When you are inside the DRAW AREA, you can erase a pixel by right clicking it, and you can give a full tone (black) or half tone (gray) by left clicking it. To switch between full and half tone, just click at the appropriate button beneath the "Left Click:" label. You can erase all the DRAW AREA through the "Clear" button. The "Revert" button re-loads the character definition from the file. The "Undo All" button rewinds the DRAW AREA back to the state it was when you began editing it (same as "Cancel" and re-edit). The "Copy" button places the character description in the clipboard. Using the "Paste" button you can paste bitmap images in the DRAW AREA. Note that in order to paste a bitmap you have placed in the clipboard, it has to be in 24bpp format. To cancel a paste operation, just right click inside the draw area. The caption of the dialog reports some extra details about the character. 
  
  Tip: medium and large characters can easily be defined by using any windows font, if you draw some text in an image editing application and then just copy paste each of the characters from the image editor to the Font Editor. Note that during that process, the bitmap colors are automatically decreased down to 3 states (white, gray, black) so you can also use AntiAlias when drawing the text at the image editor!

  I believe that's all you will need to edit or define a Rio font, Though, if you have any suggestions or comments to make, they are welcomed! Just send me a mail. The above application is a FREEWARE, so you can distribute it freely. One reason I created this is because I had to alter the fonts so as to support the Greek alphabet (while half of my songs are Greek). The other one, is just for fun :).
  
  I would be glad to hear that some people found my application usefull, while this is the only reward for me!

  I hope that the guys at Empeg will soon support extended character codes in the Rio search engine (customized by a text file), so as the to consist the player friendly to any international user.

CHANGE LOG:
-----------

04/11/2002 - version 2.0
- Added fontfile.raw file format support. The specific file is used for the TexInfo visuals.
- Altered the functionality of 'paste' command, inside the edit window so as to increase functionality. The image in the clipboard can now have any width or height. It floats above the draw area while you move the cursor and it becomes permanent as soon as you left click on the desired final position, inside the draw area. To cancel the paste operation, just right click inside the draw area.

13/05/2002 - Version 1.0
- Initial Release
