emRAWerter 1.01
(C) Lars Karlslund 2002

For everyone at the Unofficial empeg BBS to play with.


Wotisit??
---------

This program will read and write RLE-encoded .RAW files found in the /empeg/lib/visuals directory on your empegCar unit. In this directory there are several .RAW files, but only one can be read and decoded by this software at the moment: escher.raw

This file contains the bitmap for the "Image Pan" visual.

The software will also allow you to cut and paste via the Windows clipboard, and is the only way to import and export bitmaps from the program.

To customize your empegCar Image Pan visual, you'll replace this file with another file (same filename, different contents).

No warranties at all, nor is will I accept any responsibility for damage incurred to people, vehicles, animals or any animate object through the use of this visualisation customizer. :)


Recommendations
---------------

Download and install latest Hijack kernel (developed and maintained by Mark Lord)
from http://empeg-hijack.sourceforge.net

This will ease filetransfers a lot, as you can access your empeg via FTP.


Instructions
------------

Start emRAWerter.

If you wish to edit an existing .RAW file, choose "Load" and select already downloaded escher.raw type file.

Then choose "Copy" to put the bitmap on the clipboard.

Fire up your favourite bitmap editing software, and edit away. 

When you're satisfied switch back to emRAWerter and choose paste.

Finally press "Save", and the file is saved.

Upload the new escher.raw to your empegCar! Magik!


Version changes
---------------
1.01 Now reads and writes uncompressed .RAW files. AutoGuesses at load time, asks user about
     format at save time.
     Files with less than 4 colors will retain their intended colors better.
1.00 Initial release. Read/write RLE files