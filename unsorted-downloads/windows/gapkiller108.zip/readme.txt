
                          GapKiller
                        by Tony Fabris
                  http://www.jps.net/tfabris

What This Program Does
----------------------

This program is designed to edit the small amounts of 
silence that sometimes appear at the beginning and end of 
MP3 audio files. It is intended to edit the "seam" between 
two songs that are normally supposed to flow seamlessly
into one another.

You can also use this program to split a large MP3 file
into smaller ones, specifying time index markers to
determine where to split the file.


Copyright Information
---------------------

This program is Copyright 1999 by Tony Fabris. All rights 
reserved. This program is freeware and may be copied, 
provided that the distribution archive (".ZIP") file is not 
modified in any way. You may not add other files to this 
program's distribution archive.


Special Thanks
--------------

To the author of MP3Trim (http://www.jps.net/kyunghi/), who 
answered my questions and pointed me in the right direction, 
to Predrag Supurovic (http://www.dv.co.yu/broker/) who 
published the specs for the MP3 frame headers, and to my 
friend Chris, who showed me how simple the data format was 
to decipher.


Why This Program Was Written
----------------------------

Some record albums are written in such a way that the songs 
flow seamlessly into one another. Examples of this might be 
live concert albums, or studio albums by Pink Floyd.

When you encode these albums into MP3 format, sometimes the 
encoder software has a problem. Sometimes it can't make the 
beginning and/or end of a given song fall on the exact 
boundaries of the first and last compressed MP3 frames.

Let's say, for example, you just got done encoding your copy 
of Pink Floyd's "Wish You Were Here". You've made sure that 
your source .WAV files are seamless, without any silence 
recorded at the beginning or end of the .WAV files. You 
encoded the .WAV files into .MP3 format. You load up the 
playlist into your playback software, check to make sure 
that your "Gapless Playback" plugin is enabled, turn off 
shuffle play, hit the "play" button, and... There's still a 
gap between the songs. It's a very brief gap, just a split 
second, but it's annoying.


Why Does This Happen?
---------------------

MP3 files are made up of small chunks of data called 
"frames". Each frame represents a fixed amount of music, 
usually equal to about .026 seconds (although this varies 
depending on sample rate).

The problem is that each frame must be "whole". It can't 
contain less than .026 seconds of music. So the last frame 
of an MP3 file is usually padded with silence. Also, some 
encoders might artificially insert silence into the first 
frame as part of its encoding algorithm.

Usually, you don't notice it because most songs start and 
end with silence anyway. But for albums where the audio data 
flows nonstop from track to track, it becomes noticeable.

There are some things that an encoder program might be able 
to do to prevent these problems, but the encoder would have 
to be written specifically with this problem in mind. And 
besides, what if you've already got the MP3 files made and 
you don't feel like re-encoding them?


How Does GapKiller Fix This Problem? 
------------------------------------

GapKiller allows you to trim whole frames off of the 
beginning and end of MP3 files. Although this isn't a novel 
idea (there are other MP3 trimming utilities that do this, 
and they do it much better than GapKiller), GapKiller is 
unique because it allows you to preview the seam between 
two songs. You can adjust the number of frames
interactively, and preview your changes as you adjust them.

This is necessary because there is some trial-and-error 
involved in trimming the gaps. Since you're cutting whole 
frames, you're cutting away both the silence as well as some 
of the real audio data. It's important to listen carefully 
to your edits before committing them to disk.

Theoretically, one could write a utility that would 
decompress the audio data in the frames, and perform some 
kind of tricky adjusting that would make the gaps perfect 
without trimming away valid audio data. But to do so would 
cause additional loss to the audio quality because it would 
have to compress the data a second time. GapKiller doesn't 
decompress or recompress the data, so the quality remains 
unchanged.


New Feature: Splitting Large MP3 Files
--------------------------------------

Version 1.07 of GapKiller added the ability to cleanly
split a large MP3 file into smaller MP3 files. So now there
are two ways to produce gapless MP3s: 

1) If you already have the MP3s made as separate tracks,
   then use the trimming and preview features on the main
   screen.

2) If you can create a single large MP3 that represents the
   entire album (for instance, if you can edit the start
   ending track times in your ripping software), then do it,
   and use the new "Split a Large MP3" feature to split the
   large file up into smaller files.

The second method, although it gives you cleaner files, it
is still not perfect. The playback software depends on
something called a "bit reservoir" that is preserved
between frames. This can still cause slight glitches at the
transition points.

NOTE: The splitting software goes by time-index markers to
perform the splits. For the best transitions, make sure the
times match exactly between tracks. For example:

     00:00:00 - 00:05:35    First Track
     00:05:35 - 00:09:22    Second Track
     00:09:22 - 00:14:04    Third Track

Note how there is no space between each track time, the end
of one track has the exact same time as the start of the
next track.


Usage Notes
-----------

- This program does not support files with ID3v2 tags. Only
  v1 tags are supported. If your files have v2 tags, you
  may see an error message or the tags may get stripped from
  the file.

- This program cannot help you remove gaps from between
  songs when burning an audio CD. That's a completely
  different issue. This software only works with MP3 files,
  and is only useful if you intend to listen to them
  natively on a gapless-capable MP3 player.

- Your player software must have a "Gapless Playback" 
  feature in order for this to be useful. It doesn't matter 
  how carefully you trim the files, if your player software 
  doesn't play them gapless, then no amount of editing will 
  help. In WinAmp, this feature is available via a plug-in. I 
  think this plug-in was shipped with older versions of 
  WinAmp, but it is not in their current distribution. You 
  might have to poke around the internet to find it. You might
  already have it if you've installed older versions of
  WinAmp. Check WinAmp's Options/Preferences/Plug-ins/Output
  menu for the "Nullsoft Gapless Output" entry, and enable it. 

- When trimming, remember that you're cutting audio data 
  along with the silence. It may actually induce "pops" as a 
  result of the waveform jumping at the edit point. Keep 
  trying different amounts of trim (to both the beginning and 
  end points) until the gap is the least noticeable to your 
  ear. Remember, you're not trying to be perfectly faithful to 
  the original, you're just trying to make the gaps less 
  noticeable when you're playing the album seamlessly. It's
  kind of an art- you have to decide how much of each song
  that you're willing to lose to make the seams sound good.
  Sometimes you can't make the gap perfectly seamless, and
  you have to settle for a less-than-perfect gap.

- Sometimes you need to trim the audio up to the first note of
  a song. For example, if you are trimming the gap on a live
  concert album, you might have to trim away some of the
  cheering before the beginning of a song, so that the track
  actually starts on the first part of the attack of the first
  note of the song. That way, if the trim induces a pop, it
  will be less noticeable against the attack of the first note.

- There must be enough free space in the directory with 
  GapKiller to hold TWO copies of each of the files you are 
  editing. I don't know what it will do if you run out of disk 
  space. Be careful! This is especially important if you are
  using the Splitting feature, since the source file for the
  split is likely to be very large.

- GapKiller is hard-coded to work with files that contain 44.1
  khz stereo song data. If there's a big need, I might
  consider working on expanding its capability. Let me know if
  you need this.

- GapKiller will call out to a third-party MP3 player to do 
  its previews. It has only been tested with WinAmp at this 
  time. If you can get it working with another player program, 
  let me know how well it works.

- GapKiller sends two commands to the player program to play 
  the two halves of its preview. The second command must 
  include the command-line parameter that allows the player to 
  "enqueue" the second file. In WinAmp, this parameter is 
  "/ADD", but I don't know what the parameter is for other 
  programs.

- WinAmp needs to be configured a certain way in order for 
  the previews to work right: "Enqueue as default action" 
  should be turned off, shuffle play should be off, and 
  loop-repeat should be off. I'm not sure how to configure 
  other players. Let me know how it works with them.

- The box where you enter the path to the preview .EXE 
  expects a short path and file name. 

- You can select files with long file names, but the 
  directory list box shows short file names.


Release Notes
-------------

1.08 - Thursday, November 16, 2000.
     - Fixed bug where certain buttons weren't getting
       disabled when a file was loading. If you clicked
       on certain buttons during a file load, you'd get
       an error. Now the buttons are disabled during that
       period.
     - On the suggestion of Dionysus from the Unofficial
       Empeg BBS, added a button to the Splitter window
       allowing you to split a file into evenly-spaced
       sections.

1.07 - Monday, November 13, 2000.
     - Major new feature! Added the ability to split a big
       MP3 file at specified time index markers. As always,
       necessity is the mother of invention: I tried
       "MP3Splitter", which was supposed to get this job
       done, and it didn't work. (To be fair, the authors
       of that program were aware of its bug and will fix
       it on the next revision.)

1.06 - Tuesday, June 27, 2000.
     - Added preliminary support for CRC-Checked files.
       It appears to work, but I am unable to test it
       carefully at this time. As always, run GapKiller
       only on copies of your files, then  check them to
       make sure they have not been damaged.

1.05 - Friday, March 31, 2000.
     - Added support for Variable Bit Rate (VBR) files.
       Necessity is the mother of invention: I started
       using AudioCatalyst in VBR mode, and discovered
       that it still left gaps between the files (I had
       been told that it wouldn't). So I knuckled down and
       did the work. Turns out that it was pretty easy.
       It still only works on 44.1khz MP3s, and it still
       won't read ID3v2 tags, but hey, it's a start.

1.04 - Saturday, Dec. 11, 1999.
     - Minor bugfix- If you opened a file that was somehow
       invalid (wrong bitrate or whatever), it would leave
       its working copy of that file opened and locked,
       causing possible errors down the road. Not the
       same as the Dec 7th bug, but similar. Still looking
       for the Dec 7th bug.
     - Message "Invalid File" reworded to something more
       helpful.

1.03 - Thursday, Dec. 9, 1999.
     - Fixed bug where the window would move if you double
       clicked on a file name when opening it.

1.02 - Tuesday, Dec. 7, 1999.
     - Added pretty background bitmaps.
     - Occasional bug where temporary files get locked open
       still exists. Unable to determine cause at this time.
     - First version released to the internet.

1.01 - Tuesday, Nov. 30, 1999.
     - Fixed so that it runs properly under NT4.
     - Released to friends for beta testing.

1.00 - Friday, Nov. 26, 1999.
     - First version.

To-Do List
----------

Features planned for future releases:

- Rewrite it in a real language.

- Properly support long file names in all places.

- Support different sample rates other than 44.1khz.

- Support for more tag types.

- Properly deal with low disk space in editing directory.
