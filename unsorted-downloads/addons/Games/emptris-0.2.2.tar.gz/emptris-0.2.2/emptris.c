/*
 * emptris - Tetris clone for empeg car.
 * 
 * 	Copyright (C) 2000 Brian Mihulka <bmihulka@hulkster.net>
 * 
 * 	This program is free software; you can redistribute it and/or modify
 * 	it under the terms of the GNU General Public License as published by
 * 	the Free Software Foundation; either version 2 of the License, or
 * 	(at your option) any later version.
 * 
 * 	This program is distributed in the hope that it will be useful,
 * 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 * 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * 	GNU General Public License for more details.
 * 
 * 	You should have received a copy of the GNU General Public License
 * 	along with this program; if not, write to the Free Software Foundation,
 * 	Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * 
 * 		History:
 * 			Thr Oct 19 2000: Initial public release
 *			Tue Jul 24 2001: Remote fix for empeg version 1.03
 *			Sat Aug 04 2001: Added support for rio remote
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <unistd.h>
#include <sys/mman.h>

#include <sys/ioctl.h>

#include <stdlib.h>
#include <sys/time.h>

#define BLIT(fd)        ioctl((fd), _IO('d', 0))
#define DISPLAY(fd, x)  ioctl((fd), _IOW('d', 1, int), (x))

#include "nrutil.h"

void draw_tile(int **d,int x,int y,int c);
void erase_tile(int **d,int x,int y);
void refresh_board(int **d,int **g);
void new_piece(int **piece,int num);
void rotate_piece(int **piece,int num,int *rot);
void update_display(int **d,caddr_t dmap);
void set_pixel(int **d,int x,int y,int level);
int get_pixel(int **d,int x,int y);
void read_display(int **d,caddr_t dmap);
void draw_box(int **d,int x1,int y1,int x2,int y2,int level);

int main(void)
{
	int	fd,fb;
	caddr_t	dmap;
	int	**display;
	int	**gameboard;
	int	**piece,**newpiece;
	int	i,j,k,loop;
	int	test,rnd,end=0,line,rot,newrot,mvtst,drop=0;
	int	delay=13000,kp,lines=0,prevline=0;
	struct	timeval	tv;
	struct	timezone	tz;
	char	c[4];
	
	gettimeofday(&tv,&tz);
	srand(tv.tv_sec);
	
	display=imatrix(0,127,0,31);
	gameboard=imatrix(1,43,1,10);
	piece=imatrix(1,4,1,2);
	newpiece=imatrix(1,4,1,2);

	for(i=1;i<44;i++){
		for(j=1;j<11;j++){
			gameboard[i][j]=0;
		}
	}	
	
	fd = open("/dev/display", O_RDWR);
	if (fd == -1)
		return 1;

	dmap = mmap(0, 2048, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (dmap == (caddr_t) -1)
		return 2;
		
	fb = open("/dev/ir", O_RDONLY|O_NDELAY);
	if (fb == -1)
		return 1;
		
	BLIT(fd);
	DISPLAY(fd, 1);

	for(i=0;i<128;i++){
		display[i][0]=3;
		display[i][31]=3;
	}
	for(i=0;i<32;i++){
		display[127][i]=3;
	}

	refresh_board(display,gameboard);
	update_display(display,dmap);
	BLIT(fd);

	rnd=(int)(7.0*rand()/(RAND_MAX));
	new_piece(piece,rnd);

	do{
		rot=test=0;
		for(i=1;i<5;i++){
			draw_tile(display,piece[i][1],piece[i][2],rnd%2+1);
		}
		update_display(display,dmap);
		BLIT(fd);
		do{
			/*for(loop=0;loop<2;loop++){*/
				if(!drop) usleep(delay);
				kp=read(fb,c,4);
				if(kp==4){
					    if( ( (c[1]==0x46 && c[2]==0xb9) || (c[1]==0xdf && c[2]==0x20) ) && !c[3]){
						switch(c[0]){
							case 0x5e:
							case 0x12:
								drop=1;
								break;
							case 0xa:
							case 0x10:
								if(!(piece[1][2]==10 || piece[2][2]==10 || piece[3][2]==10 || piece[4][2]==10)){
									mvtst=0;
									for(i=1;i<5;i++){
										if(gameboard[piece[i][1]][piece[i][2]+1]) mvtst++;
									}
									if(!mvtst){
										for(i=1;i<5;i++){
											draw_tile(display,piece[i][1],piece[i][2],0);
											piece[i][2]++;
										}
									}
								}
								break;		
							case 0xb:
							case 0x11:
								if(!(piece[1][2]==1 || piece[2][2]==1 || piece[3][2]==1 || piece[4][2]==1)){
									mvtst=0;
									for(i=1;i<5;i++){
										if(gameboard[piece[i][1]][piece[i][2]-1]) mvtst++;
									}
									if(!mvtst){
										for(i=1;i<5;i++){
											draw_tile(display,piece[i][1],piece[i][2],0);
											piece[i][2]--;
										}
									}
								}
								break;
							case 0x14:
							case 0x13:
								for(i=1;i<5;i++){
									newpiece[i][1]=piece[i][1];
									newpiece[i][2]=piece[i][2];
								}
								newrot=rot;
								rotate_piece(newpiece,rnd,&newrot);
								while(newpiece[1][2]<1 || newpiece[2][2]<1 || newpiece[3][2]<1 || newpiece[4][2]<1){
									for(i=1;i<5;i++){
										newpiece[i][2]++;
									}
								}
								while(newpiece[1][2]>10 || newpiece[2][2]>10 || newpiece[3][2]>10 || newpiece[4][2]>10){
									for(i=1;i<5;i++){
										newpiece[i][2]--;
									}
								}
								mvtst=0;
								for(i=1;i<5;i++){
									if(newpiece[i][1]<1) mvtst++;
									if(!mvtst){
										if(gameboard[newpiece[i][1]][newpiece[i][2]]) mvtst++;
									}
								}
								if(!mvtst){
									for(i=1;i<5;i++){
										draw_tile(display,piece[i][1],piece[i][2],0);
										piece[i][1]=newpiece[i][1];
										piece[i][2]=newpiece[i][2];
									}
									rot=newrot;
								}
								break;
							case 1:
							case 0:
								goto quit;
						}
					}
				}
				for(i=1;i<5;i++){
					draw_tile(display,piece[i][1],piece[i][2],rnd%2+1);
				}
				update_display(display,dmap);
				BLIT(fd);
				if(!drop) usleep(delay);
			/*}*/
			
			for(i=4;i>0;i--){
				draw_tile(display,piece[i][1],piece[i][2],0);
			}
			
			for(i=1;i<5;i++){
				if(piece[i][1]==42) test++;
				if(gameboard[piece[i][1]+1][piece[i][2]]) test++;
			}
			
			if(!test){
				for(i=1;i<5;i++){
					piece[i][1]++;
				}
			}
			
			for(i=1;i<5;i++){
				draw_tile(display,piece[i][1],piece[i][2],rnd%2+1);
			}
			update_display(display,dmap);
			BLIT(fd);
			
			if(!drop) usleep(delay);
			
		}while(!test);

		drop=0;
	
		for(i=1;i<5;i++){
			gameboard[piece[i][1]][piece[i][2]]=rnd%2+1;
		}
		
		for(i=1;i<43;i++){
			line=0;
			for(j=1;j<11;j++){
				if(gameboard[i][j]) line++;
			}
			if(line==10){
				lines++;
				for(j=i;j>1;j--){
					for(k=1;k<11;k++){
						gameboard[j][k]=gameboard[j-1][k];
					}
				}
				for(k=1;k<11;k++){
					gameboard[1][k]=0;
				}
				refresh_board(display,gameboard);
				update_display(display,dmap);
				BLIT(fd);
			}
		}
		
		if((lines-prevline)/10){
			prevline=lines;
			if(delay>5000){
				delay-=1000;
			}
		}
		
		rnd=(int)(7.0*rand()/(RAND_MAX));
		new_piece(piece,rnd);

		for(i=1;i<5;i++){
			if(gameboard[piece[i][1]+1][piece[i][2]]) end++;
		}

	}while(!end);
	
quit:

	for(i=0;i<2048;i++){
		dmap[i]=0;
	}
	
	BLIT(fd);

	free_imatrix(display,0,127,0,31);
	free_imatrix(gameboard,1,43,1,10);
	free_imatrix(piece,1,4,1,2);
	free_imatrix(newpiece,1,4,1,2);

	printf("You cleared %d lines\n",lines);

	/*printf("Delay %d\n",delay);*/

	if (munmap(dmap, 2048) == -1 || close(fd) == -1 || close(fb) == -1 )
		return 3;
		
	return 0;
}

void draw_tile(int **d,int x,int y,int c){

	switch(c){
	case 0:
		draw_box(d,(x*3)-2,(y*3)-2,x*3,y*3,0);
		set_pixel(d,(x*3)-1,(y*3)-1,0);
		break;
	case 1:
		draw_box(d,(x*3)-2,(y*3)-2,x*3,y*3,3);
		set_pixel(d,(x*3)-1,(y*3)-1,2);
		break;
	case 2:
		draw_box(d,(x*3)-2,(y*3)-2,x*3,y*3,2);
		set_pixel(d,(x*3)-1,(y*3)-1,3);
		break;
	}
}

void erase_tile(int **d,int x,int y){

	draw_box(d,(x*3)-2,(y*3)-2,x*3,y*3,0);
	set_pixel(d,(x*3)-1,(y*3)-1,0);
}

void refresh_board(int **d,int **g){

	int	i,j;

	for(i=1;i<43;i++){
		for(j=1;j<11;j++){
			draw_tile(d,i,j,g[i][j]);
		}
	}
}

void new_piece(int **piece,int num){

	switch(num){
		case 0:
			piece[1][1]=1;
			piece[1][2]=5;
			piece[2][1]=1;
			piece[2][2]=6;
			piece[3][1]=2;
			piece[3][2]=5;
			piece[4][1]=2;
			piece[4][2]=6;
			break;
		case 1:
			piece[1][1]=1;
			piece[1][2]=5;
			piece[2][1]=1;
			piece[2][2]=6;
			piece[3][1]=1;
			piece[3][2]=7;
			piece[4][1]=2;
			piece[4][2]=6;
			break;
		case 2:
			piece[1][1]=1;
			piece[1][2]=4;
			piece[2][1]=1;
			piece[2][2]=5;
			piece[3][1]=1;
			piece[3][2]=6;
			piece[4][1]=1;
			piece[4][2]=7;
			break;
		case 3:
			piece[1][1]=1;
			piece[1][2]=5;
			piece[2][1]=1;
			piece[2][2]=6;
			piece[3][1]=1;
			piece[3][2]=7;
			piece[4][1]=2;
			piece[4][2]=5;
			break;
		case 4:
			piece[1][1]=1;
			piece[1][2]=4;
			piece[2][1]=1;
			piece[2][2]=5;
			piece[3][1]=1;
			piece[3][2]=6;
			piece[4][1]=2;
			piece[4][2]=6;
			break;
		case 5:
			piece[1][1]=1;
			piece[1][2]=5;
			piece[2][1]=1;
			piece[2][2]=6;
			piece[3][1]=2;
			piece[3][2]=4;
			piece[4][1]=2;
			piece[4][2]=5;
			break;
		case 6:
			piece[1][1]=1;
			piece[1][2]=4;
			piece[2][1]=1;
			piece[2][2]=5;
			piece[3][1]=2;
			piece[3][2]=5;
			piece[4][1]=2;
			piece[4][2]=6;
			break;
	}
}

void rotate_piece(int **piece,int num,int *rot){

	switch(num){
		case 0:
			break;
		case 1:
			switch(*rot){
				case 0:
					piece[1][1]--;
					piece[1][2]++;
					piece[3][1]++;
					piece[3][2]--;
					piece[4][1]--;
					piece[4][2]--;
					*rot=1;
					break;
				case 1:
					piece[1][1]++;
					piece[1][2]++;
					piece[3][1]--;
					piece[3][2]--;
					piece[4][1]--;
					piece[4][2]++;
					*rot=2;
					break;
				case 2:
					piece[1][1]++;
					piece[1][2]--;
					piece[3][1]--;
					piece[3][2]++;
					piece[4][1]++;
					piece[4][2]++;
					*rot=3;
					break;
				case 3:
					piece[1][1]--;
					piece[1][2]--;
					piece[3][1]++;
					piece[3][2]++;
					piece[4][1]++;
					piece[4][2]--;
					*rot=0;
					break;
			}
			break;
		case 2:
			switch(*rot){
				case 0:
					piece[1][1]-=2;
					piece[1][2]+=2;
					piece[2][1]--;
					piece[2][2]++;
					piece[4][1]++;
					piece[4][2]--;
					*rot=1;
					break;
				case 1:
					piece[1][1]+=2;
					piece[1][2]-=2;
					piece[2][1]++;
					piece[2][2]--;
					piece[4][1]--;
					piece[4][2]++;
					*rot=0;
					break;
			}
			break;
		case 3:
			switch(*rot){
				case 0:
					piece[1][1]--;
					piece[1][2]++;
					piece[3][1]++;
					piece[3][2]--;
					piece[4][1]-=2;
					*rot=1;
					break;
				case 1:
					piece[1][1]++;
					piece[1][2]++;
					piece[3][1]--;
					piece[3][2]--;
					piece[4][2]+=2;
					*rot=2;
					break;
				case 2:
					piece[1][1]++;
					piece[1][2]--;
					piece[3][1]--;
					piece[3][2]++;
					piece[4][1]+=2;
					*rot=3;
					break;
				case 3:
					piece[1][1]--;
					piece[1][2]--;
					piece[3][1]++;
					piece[3][2]++;
					piece[4][2]-=2;
					*rot=0;
					break;
			}
			break;
		case 4:
			switch(*rot){
				case 0:
					piece[1][1]--;
					piece[1][2]++;
					piece[3][1]++;
					piece[3][2]--;
					piece[4][2]-=2;
					*rot=1;
					break;
				case 1:
					piece[1][1]++;
					piece[1][2]++;
					piece[3][1]--;
					piece[3][2]--;
					piece[4][1]-=2;
					*rot=2;
					break;
				case 2:
					piece[1][1]++;
					piece[1][2]--;
					piece[3][1]--;
					piece[3][2]++;
					piece[4][2]+=2;
					*rot=3;
					break;
				case 3:
					piece[1][1]--;
					piece[1][2]--;
					piece[3][1]++;
					piece[3][2]++;
					piece[4][1]+=2;
					*rot=0;
					break;
			}
			break;
		case 5:
			switch(*rot){
				case 0:
					piece[2][1]++;
					piece[2][2]--;
					piece[3][1]-=2;
					piece[4][1]--;
					piece[4][2]--;
					*rot=1;
					break;
				case 1:
					piece[2][1]--;
					piece[2][2]++;
					piece[3][1]+=2;
					piece[4][1]++;
					piece[4][2]++;
					*rot=0;
					break;
			}
			break;
		case 6:
			switch(*rot){
				case 0:
					piece[1][1]--;
					piece[1][2]++;
					piece[3][1]--;
					piece[3][2]--;
					piece[4][2]-=2;
					*rot=1;
					break;
				case 1:
					piece[1][1]++;
					piece[1][2]--;
					piece[3][1]++;
					piece[3][2]++;
					piece[4][2]+=2;
					*rot=0;
					break;
			}
			break;
	}
}

void update_display(int **d,caddr_t dmap){
	
	int	i,j;
	
	for(i=63;i>=0;i--){
		for(j=31;j>=0;j--){
			dmap[i+j*64] = d[2*i][j] + (d[2*i+1][j] << 4) ;
		}
	}
}
	
void set_pixel(int **d,int x,int y,int level){
	d[x][y]=level;
}

int get_pixel(int **d,int x,int y){
	int	i;
	
	i=d[x][y];
	return i;
}

void read_display(int **d,caddr_t dmap){

	int	i,j;

	for(i=0;i<64;i++){
                for(j=0;j<32;j++){
                        d[2*i][j]=dmap[i+64*j]&0x0f;
                        d[2*i+1][j]=(dmap[i+64*j]&0xf0)>>4;
                }
        }
}

void draw_box(int **d,int x1,int y1,int x2,int y2,int level){
	int	i;

	if(x2<x1){
		i=x2;
		x2=x1;
		x1=i;
	}
	for(i=x1;i<=x2;i++){
		set_pixel(d,i,y1,level);
		set_pixel(d,i,y2,level);
	}
	if(y2<y1){
		i=y2;
		y2=y1;
		y1=i;
	}
	for(i=y1;i<=y2;i++){
		set_pixel(d,x1,i,level);
		set_pixel(d,x2,i,level);
	}
}

