<?php

Header("Location: index.php?time=" . (time() + 2));

?>
