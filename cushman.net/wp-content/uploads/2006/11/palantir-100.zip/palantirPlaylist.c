#include <PalmOS.h>
#include <Table.h>
#include <Menu.h>
#include <ExgMgr.h>
#include <PalmChars.h>
#include "palantirResource.h"
#include "palantirGlobals.h"

//--------------------------------
// Beam the playlist to the Empeg
//--------------------------------

Boolean PlaylistBeam(void) {
	ExgSocketType exgSocket;
	UInt32 i, size = 0, sizeSent = 0;
	MemHandle tItem, plst = NULL;
	TrackRecordPacked *tRecPacked;
	Err err = errNone;
	Char *fids = NULL;
	Char fid[10];

	if(playlist != NULL) {
		for(i = 0; i < playlistCount; i++) {
			tItem = DmQueryRecord(palantirDB, playlist[i]);
			tRecPacked = (TrackRecordPacked *) MemHandleLock(tItem);
			MemHandleUnlock(tItem);

			StrIToH(fid, tRecPacked->fid);

			if(fids == NULL) {
				plst = MemHandleNew(sizeof(Char) * (StrLen(fid) + 1));
				fids = (Char *) MemHandleLock(plst);
				StrCopy(fids, fid);
			} else {
				size = StrLen(fids) + StrLen(fid) + 1;
				MemHandleUnlock(plst);
				MemHandleResize(plst, sizeof(Char) * size);
				fids = (Char *) MemHandleLock(plst);
				StrCat(fids, fid);
			}
		}

		MemSet(&exgSocket, sizeof(exgSocket), 0);
		size = StrLen(fids);

		exgSocket.description = "Palantir Playlist";
		switch(uploadMode) {
		case UPLOAD_MODE_INSERT:
			exgSocket.name = "palantir_insert.empeg";
			break;
		case UPLOAD_MODE_APPEND:
			exgSocket.name = "palantir_append.empeg";
			break;
		case UPLOAD_MODE_REPLACE:
			exgSocket.name = "palantir_replace.empeg";
			break;
		case UPLOAD_MODE_ENQUEUE:
			exgSocket.name = "palantir_enqueue.empeg";
			break;
		default:
		}
		exgSocket.length = size;

		err = ExgPut(&exgSocket);

		if (!err) {
			while (!err && sizeSent < size) {
				sizeSent += ExgSend(&exgSocket, fids, size, &err);
			}
			ExgDisconnect(&exgSocket,err);
		}

		MemHandleUnlock(plst);
		MemHandleFree(plst);
	}
	return true;
}

//-------------------------------------
// Search for an index in the playlist
//-------------------------------------

Int32 PlaylistContains(UInt32 trackNr) {
	UInt32 i;

	for(i = 0; i < playlistCount; i++)
		if(trackNr == playlist[i]) return i;
	return -1;
}

//--------------------------------
// Add an index into the playlist
//--------------------------------

void PlaylistAdd(UInt32 trackNr) {
	MemHandle plst;

	if(PlaylistContains(trackNr) == -1) {
		if(playlist == NULL) {	//we need to create a new playlist
			plst = MemHandleNew(sizeof(UInt32));
		} else {
			plst = MemPtrRecoverHandle(playlist);
			MemHandleUnlock(plst);
			MemHandleResize(plst, sizeof(UInt32) * (playlistCount + 1));
		}
		playlist = (UInt32 *)MemHandleLock(plst);

		playlist[playlistCount] = trackNr;
		playlistCount++;
	}
}

//-----------------------------------
// Move an index within the playlist
//-----------------------------------

void PlaylistItemMove(UInt32 sourceTrackNr, Int32 direction) {
	MemHandle plst;
	UInt32 oldIdx;

	plst = MemPtrRecoverHandle(playlist);
	MemHandleUnlock(plst);

	playlist = (UInt32 *)MemHandleLock(plst);
	oldIdx = PlaylistContains(sourceTrackNr);

	if(direction < 0)
		MemMove(playlist + oldIdx + direction + 1, playlist + oldIdx + direction, -1 * (direction) * sizeof(UInt32));
	else
		MemMove(playlist + oldIdx, playlist + oldIdx + 1, direction * sizeof(UInt32));
	playlist[oldIdx + direction] = sourceTrackNr;
}

//-----------------------------------
// Remove an index from the playlist
//-----------------------------------

void PlaylistRemove(UInt32 trackNr) {
	MemHandle plst, tmpListHandle;
	UInt32 i, idx, *tmpList;

	plst = MemPtrRecoverHandle(playlist);
	MemHandleUnlock(plst);
	playlist = (UInt32 *)MemHandleLock(plst);

	if(playlistCount > 1) {
		tmpListHandle = MemHandleNew(sizeof(UInt32) * (playlistCount - 1));
		tmpList = (UInt32 *)MemHandleLock(tmpListHandle);
		idx = PlaylistContains(trackNr);
		for(i = 0; i < playlistCount; i++)
			if(i != idx) tmpList[i > idx ? i - 1 : i] = playlist[i];
	} else {
		tmpList = NULL;
	}

	MemHandleUnlock(plst);
	MemHandleFree(plst);
	playlist = tmpList;
	playlistCount--;
}

//-----------------------------------
// Remove an index from the playlist
//-----------------------------------

void PlaylistRemoveAll() {
	if(playlist != NULL) {
		MemHandle plst;
		plst = MemPtrRecoverHandle(playlist);
		MemHandleUnlock(plst);
		playlist = (UInt32 *)MemHandleLock(plst);
		MemHandleUnlock(plst);
		MemHandleFree(plst);
		playlist = NULL;
		playlistCount = 0;
	}
}

//-----------------------------------------
// Initialize the Playlist Table structure
//-----------------------------------------

void InitPlaylistTable(TableType *table) {
	UInt32 i, maxVisibleRows = TblGetNumberOfRows(table);

	for(i = 0; i < maxVisibleRows; i++) {
		TblSetItemStyle(table, i, 0, checkboxTableItem);
		TblSetItemStyle(table, i, 1, customTableItem);
	}
	TblSetColumnUsable(table, 0, true);
	TblSetColumnUsable(table, 1, true);
	TblSetCustomDrawProcedure(table, 1, DrawPlaylistRow);
}

//---------------------------------------
// Populate the Playlist Table structure
//---------------------------------------

void PopulatePlaylistTable(TableType *table, UInt32 playlistPos) {
	MemHandle tItem;
	TrackRecordPacked *tRecPacked;
	UInt32 i, maxVisibleRows = TblGetNumberOfRows(table);

	for(i = 0; i < maxVisibleRows; i++) {
		if((playlistPos < playlistCount) && (i < playlistVisibleRows)) {
			tItem = DmQueryRecord(palantirDB, playlist[playlistPos]);
			tRecPacked = (TrackRecordPacked *) MemHandleLock(tItem);
			MemHandleUnlock(tItem);
			TblSetItemInt(table, i, 0, 1);
			TblSetItemPtr(table, i, 1, tRecPacked);
			TblSetItemInt(table, i, 1, playlist[playlistPos]);
			TblSetRowUsable(table, i, true);
			playlistPos++;
		} else {
			TblSetRowUsable(table, i, false);
		}
	}
	TblRedrawTable(table);
}

//---------------------------
// Scroll the Playlist Table
//---------------------------

void ScrollPlaylistTable(Int32 newValue, Boolean setBar) {
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, PlaylistTable));
	Int32 maxValue = playlistCount - playlistVisibleRows;
	if(maxValue < 0)
		maxValue = 0;
	//make sure we don't scroll above 0 or below max
	if(newValue > maxValue)
		newValue = maxValue;
	if(newValue < 0)
		newValue = 0;

	playlistTablePosition = newValue;
	TblMarkTableInvalid(table);
	PopulatePlaylistTable(table, playlistTablePosition);
	if(setBar)
		SclSetScrollBar(playlistScrollBar, playlistTablePosition, 0, maxValue, playlistVisibleRows);
}

//------------------------------------------
// Initialize the Playlist Table scrollbars
//------------------------------------------

void InitPlaylistScrollBar() {
	Int16 max;
	if(playlistVisibleRows > playlistCount)
		max = 0;
	else
		max = playlistCount - playlistVisibleRows;
	SclSetScrollBar(playlistScrollBar, playlistTablePosition, 0, max, playlistVisibleRows);
}

//--------------------------------
// Resize the Track View for DIA
//--------------------------------

void PlaylistFormResizeForm(FormType *form, RectangleType *curBounds, RectangleType *displayBounds) {
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, PlaylistTable));
	Coord columnWidth, rowHeight = TblGetRowHeight(table, 0);
	Int16 heightDelta = 0, widthDelta = 0;

	// Determine the amount of the change 
	heightDelta = displayBounds->extent.y - displayBounds->topLeft.y - curBounds->extent.y - curBounds->topLeft.y; 
	widthDelta = displayBounds->extent.x - displayBounds->topLeft.x - curBounds->extent.x - curBounds->topLeft.x;

	MyFrmMoveObject(form, FrmGetObjectIndex(form, PlaylistButtonBack), 0, heightDelta); //move the back button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, PlaylistButtonRemoveAll), 0, heightDelta); //move the remove all button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, PlaylistButtonBeam), 0, heightDelta); //move the beam button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, PlaylistModeTrigger), widthDelta, 0); //move the mode trigger
	MyFrmMoveObject(form, FrmGetObjectIndex(form, PlaylistModeList), widthDelta, 0); //move the mode list
	MyFrmMoveObject(form, FrmGetObjectIndex(form, PlaylistScrollBar), widthDelta, 0); //move the scroll bar

	//determine the visibile rows
	playlistVisibleRows = MyTblGetNumberOfRows(form, FrmGetObjectIndex(form, PlaylistTable),
												     FrmGetObjectIndex(form, PlaylistButtonBeam), rowHeight);
	
	MyFrmResizeObject(form, FrmGetObjectIndex(form, PlaylistTable), rowHeight * playlistVisibleRows, widthDelta);
	columnWidth = TblGetColumnWidth(table, 1);
	TblSetColumnWidth(table, 1, columnWidth + widthDelta);
	MyFrmResizeObject(form, FrmGetObjectIndex(form, PlaylistScrollBar), rowHeight * playlistVisibleRows, 0);
	
	InitPlaylistTable(table);
	InitPlaylistScrollBar();
	TblMarkTableInvalid(table);
	PopulatePlaylistTable(table, playlistTablePosition);
	TblRedrawTable(table);
}

//------------------------------
// Initialize the Playlist View
//------------------------------

void PlaylistFormInit(void) {
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, PlaylistTable));
	ControlType *popup = FrmGetObjectPtr(form, FrmGetObjectIndex(form, PlaylistModeTrigger));
	ListType *list = FrmGetObjectPtr(form, FrmGetObjectIndex(form, PlaylistModeList));
	Char *label = (Char *)CtlGetLabel(popup);
	Coord rowHeight = TblGetRowHeight(table, 0);
	RectangleType curBounds, displayBounds; 

	if(hasDIA) {
		FrmSetDIAPolicyAttr(form, frmDIAPolicyCustom); 		//enable DIA support
		PINSetInputTriggerState(pinInputTriggerEnabled); 	//enable DIA trigger
		PINSetInputAreaState(pinInputAreaUser);
	}

	//set up some global variables
	currentScreen = PLAYLIST_SCREEN;
	playlistVisibleRows = MyTblGetNumberOfRows(form, FrmGetObjectIndex(form, PlaylistTable),
												     FrmGetObjectIndex(form, PlaylistButtonBeam), rowHeight);

	//set the pop-up trigger
	LstSetSelection(list, uploadMode);
	StrCopy(label, LstGetSelectionText(list, uploadMode));
	CtlSetLabel(popup, label);

	//set the playlist scroll bar object
	playlistScrollBar = (ScrollBarType *) FrmGetObjectPtr(form, FrmGetObjectIndex(form, PlaylistScrollBar));

	if(playlistCount == 0) {
		//do not display anything
	} else {
		if(hasDIA) {
			WinGetBounds(FrmGetWindowHandle(form), &curBounds); 
			WinGetBounds(WinGetDisplayWindow(), &displayBounds);
			PlaylistFormResizeForm(form, &curBounds, &displayBounds);
			WinSetBounds(FrmGetWindowHandle(form), &displayBounds); 
		} else {
			InitPlaylistTable(table);
			InitPlaylistScrollBar();
			PopulatePlaylistTable(table, playlistTablePosition);
		}
	}
	
	FrmDrawForm(form);
}

//-------------------------------
// Draw the move indicator line
//-------------------------------

void DrawMovingLine(RectanglePtr r, UInt16 color) {
	switch(color){
	case 0:
		//set the background color (used to make sure we don't leave
		//"tracks" when moving an item in the Playlist
		if(os_3_5) WinSetBackColor(UIColorGetTableEntryIndex(UIFieldBackground));
		WinEraseLine(r->topLeft.x - 1,
		             r->topLeft.y + r->extent.y,
		             r->topLeft.x + r->extent.x - 2,
		             r->topLeft.y + r->extent.y);
		break;
	case 1:
		WinDrawGrayLine(r->topLeft.x - 1,
		                r->topLeft.y + r->extent.y,
		                r->topLeft.x + r->extent.x - 2,
		                r->topLeft.y + r->extent.y);
		break;
	default:
	}
}

//-------------------------------
// Invert (select) a table entry
//-------------------------------

void InvertItem(TablePtr table, Int16 row, Int16 column) {
	RectangleType r;

	TblGetItemBounds(table, row, column, &r);
	r.topLeft.x -= 2;
	r.extent.x += 1;
	WinInvertRectangle(&r, 0);
}

//----------------------
// Move a playlist Item
//----------------------

void PlaylistMove(EventType *event) {
	//FormType *form = FrmGetActiveForm();
	//UInt16 labelObjectIndex = FrmGetObjectIndex(form, PlaylistLabel);
	Int16 row, column, selectedRecord, delay = 0;
	Int32 playlistPos;
	TablePtr table;
	RectangleType r;
	Coord x, y;
	Boolean penDown = true, moving = false;
	//Char cx[4], cy[4], newtext[13];

	row = event->data.tblSelect.row;
	column = event->data.tblSelect.column;
	table = event->data.tblSelect.pTable;

	//get the bounds of the rectangle we are in
	TblGetItemBounds(table, row, column, &r);

	//select the item we pen down'ed on
	selectedRecord = row;
	playlistPos = TblGetItemInt(table, row, column);
	InvertItem(table, row, column);

	while(true) {
		PenGetPoint (&x, &y, &penDown);
		if(!penDown) break;

		//---------debug---------------------
		//---------debug---------------------
		//StrIToA(cx, row);
		//StrIToA(cy, playlistCount - 1);
		//StrPrintF(newtext, "x:%s y:%s", cx, cy);
		//FrmHideObject(form, labelObjectIndex);
		//FrmCopyLabel(form, PlaylistLabel, newtext);
		//FrmShowObject(form, labelObjectIndex);
		//---------debug---------------------
		//---------debug---------------------

		if(!moving) {
			if(!RctPtInRectangle(x, y, &r)) {			//we just started moving
				moving = true;
				TblGetItemBounds(table, row, column, &r);
				if((row != selectedRecord - 1) && (row != selectedRecord)) DrawMovingLine(&r, 1);
			}
		} else if(!RctPtInRectangle(x, y, &r)) {			//we are still on the move
			if(y <= r.topLeft.y) {					//see if our cursor is above the rectangle
				if(row < 0) {					//see if we are at the top of the table
					if(delay == 75) {
						if(playlistTablePosition > 0) {
							ScrollPlaylistTable(playlistTablePosition - 1, true);
							selectedRecord++;
							DrawMovingLine(&r, 1);
							if((0 <= selectedRecord) && (selectedRecord < playlistVisibleRows))
								InvertItem(table, selectedRecord, column);
							delay = 0;
						}
					} else {
						delay++;
					}
				} else {
					if((row != selectedRecord - 1) && (row != selectedRecord)) DrawMovingLine(&r, 0);
					row--;
					r.topLeft.y -= r.extent.y;
					if((row != selectedRecord - 1) && (row != selectedRecord)) DrawMovingLine(&r, 1);
				}
			} else if(y >= r.topLeft.y + r.extent.y) {		//see if our cursor is below the rectangle
				if(row < (Int32)playlistCount - 1) {
					if(row == playlistVisibleRows - 1) {		//we are at the bottom of the table
						if(delay == 75) {
							if(playlistTablePosition < (playlistCount - playlistVisibleRows)) {
								ScrollPlaylistTable(playlistTablePosition + 1, true);
								selectedRecord--;
								if((0 <= selectedRecord) && (selectedRecord < playlistVisibleRows))
									InvertItem(table, selectedRecord, column);
								delay = 0;
							}
						} else {
							delay++;
						}
					} else {
						if((row != selectedRecord - 1) && (row != selectedRecord)) DrawMovingLine(&r, 0);
						row++;
						r.topLeft.y += r.extent.y;
						if((row != selectedRecord - 1) && (row != selectedRecord)) DrawMovingLine(&r, 1);
					}
				}
			}
		}
	}

	if(moving) {
		DrawMovingLine(&r, 0);
	}

	//if the selected item is visible, unhighlight it
	if((0 <= selectedRecord) && (selectedRecord < playlistVisibleRows)) {
		InvertItem(table, selectedRecord, column);
	}

	if(selectedRecord > row) {
		PlaylistItemMove(playlistPos, row - selectedRecord + 1);
		TblMarkTableInvalid(table);
		PopulatePlaylistTable(table, playlistTablePosition);
	}
	if(selectedRecord < row) {
		PlaylistItemMove(playlistPos, row - selectedRecord);
		TblMarkTableInvalid(table);
		PopulatePlaylistTable(table, playlistTablePosition);
	}
}

//-----------------------------
// Handle events in BrowseForm
//-----------------------------

Boolean PlaylistFormHandleEvent(EventType *event) {
	Int16 row, column;
	Boolean handled = false;
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, PlaylistTable));
	RectangleType curBounds, displayBounds; 
	Char *selectionText;
	
	switch(event->eType) {
	case frmOpenEvent:
		PlaylistFormInit();
		handled = true;
		break;
	case ctlSelectEvent:
		switch(event->data.ctlSelect.controlID) {
		case PlaylistButtonBack:
			switch(lastScreen) {
			case ARTIST_SCREEN:
				FrmGotoForm(ArtistForm);
				break;
			case SOURCE_SCREEN:
				FrmGotoForm(SourceForm);
				break;
			case TRACK_SCREEN:
				FrmGotoForm(TrackForm);
				break;
			default:
				FrmGotoForm(TrackForm);
				break;
			}
			handled = true;
			break;
		case PlaylistButtonRemoveAll:
			switch(FrmAlert(PlaylistRemoveAllAlert)) {
			case 0:
				PlaylistRemoveAll();
				ScrollPlaylistTable(0, true);
				break;
			case 1:
			default:
			}
			handled = true;
			break;
		case PlaylistButtonBeam:
			PlaylistBeam();
			break;
		default:
			break;
		}
		break;
	case sclRepeatEvent:
		ScrollPlaylistTable(event->data.sclExit.newValue, false);
		break;
	case popSelectEvent:
		//set the new upload mode
		selectionText = LstGetSelectionText(event->data.popSelect.listP, event->data.popSelect.selection);
		CtlSetLabel(event->data.popSelect.controlP, selectionText);
		uploadMode = event->data.popSelect.selection;
		break;
	case menuCmdBarOpenEvent:
		//handled = true;
		break;
	case menuEvent:
		handled = GlobalMenuHandleEvent();		
		break;
	case menuOpenEvent:
		if(event->data.menuOpen.cause != menuCommandCause) {
			handled = GlobalMenuHandleEvent();
		} else {
			//for some reason, if we handle the menuOpenEvent
			//the menu status does not get reset.. it is still
			//active because we allowed the command bar to exist
			//this is a workaround - re-init the form
			FrmGotoForm(PlaylistForm);
		}
		break;
	case keyDownEvent:
		if(event->data.keyDown.chr == vchrPageDown) {
			ScrollPlaylistTable(playlistTablePosition + playlistVisibleRows, true);
			handled = true;
		} else if(event->data.keyDown.chr == vchrPageUp) {
			ScrollPlaylistTable(playlistTablePosition - playlistVisibleRows, true);
			handled = true;
		} else if((event->data.keyDown.chr == vchrHardRockerCenter) ||
				  (event->data.keyDown.chr == vchrRockerRight)) {
			//do nothing - allow T5 and Treos to open alert manager on long presses
		} else if(event->data.keyDown.chr == vchrRockerCenter) {
			//T5 and Treo 6xx, all devices moving forward
			handled = PlaylistBeam();
		} else if(event->data.keyDown.chr == vchrRockerLeft) {
			switch(lastScreen) {
			case ARTIST_SCREEN:
				FrmGotoForm(ArtistForm);
				break;
			case SOURCE_SCREEN:
				FrmGotoForm(SourceForm);
				break;
			case TRACK_SCREEN:
				FrmGotoForm(TrackForm);
				break;
			default:
				FrmGotoForm(TrackForm);
				break;
			}
		} else if(hasNavigator) {
			if(NavKeyPressed(event, Select))
				handled = PlaylistBeam();
			if(NavKeyPressed(event, Left)) {
				switch(lastScreen) {
				case ARTIST_SCREEN:
					FrmGotoForm(ArtistForm);
					break;
				case SOURCE_SCREEN:
					FrmGotoForm(SourceForm);
					break;
				case TRACK_SCREEN:
					FrmGotoForm(TrackForm);
					break;
				default:
					FrmGotoForm(TrackForm);
					break;
				}
			}
		}
		break;
	case tblEnterEvent:
		column = event->data.tblEnter.column;
		if(column == 1) {
			PlaylistMove(event);
			handled = true;
		}
		break;
	case tblSelectEvent:
		row = event->data.tblEnter.row;
		column = event->data.tblEnter.column;
		//table = event->data.tblEnter.pTable;
		if(column == 0) {
			//if(TblGetItemInt(table, row, 0) == 1) //checkbox was off, now it's on
			//	PlaylistAdd(TblGetItemInt(table, row, 1));
			//else //checkbox was on, now it's off
			PlaylistRemove(TblGetItemInt(table, row, 1));
			TblMarkTableInvalid(table);
			ScrollPlaylistTable(playlistTablePosition, true);
		}
		handled = true;
		break;
	case winDisplayChangedEvent:
		WinGetBounds(FrmGetWindowHandle(form), &curBounds); 
		WinGetBounds(WinGetDisplayWindow(), &displayBounds);
		PlaylistFormResizeForm(form, &curBounds, &displayBounds);
		WinSetBounds(FrmGetWindowHandle(form), &displayBounds); 
		FrmDrawForm(form); 
		handled = true;
		break;
	default:
		break;
	}
	return handled;
}
