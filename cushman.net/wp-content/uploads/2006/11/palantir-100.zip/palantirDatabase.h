//Playlist Record Structure in pdb
typedef struct {
	UInt32		fid;
	long long	duration;
	UInt32		offset[6];
	char		data[1];
} PlayListRecordPacked;

//Playlist Record Structure
typedef struct {
	UInt32		fid;
	long long	duration;
	const char	*genre;
	const char	*artist;
	const char	*year;
	const char	*source;
	const char	*track;
	const char	*title;
	const char	*bitrate;
} PlayListRecord;
