#include <PalmOS.h>
#include <Table.h>
#include <PalmChars.h>
#include "palantirResource.h"
#include "palantirGlobals.h"

//---------------------------------------
// Initialize the Source Table structure
//---------------------------------------

void InitSourceTable(TableType *table) {
	UInt32 i, maxVisibleRows = TblGetNumberOfRows(table);

	for(i = 0; i < maxVisibleRows; i++)
		TblSetItemStyle(table, i, 0, customTableItem);
	TblSetColumnUsable(table, 0, true);
	TblSetCustomDrawProcedure(table, 0, DrawSourceRow);
}

//-------------------------------------
// Populate the Source Table structure
//-------------------------------------

void PopulateSourceTable(TableType *table, UInt32 offsetIndex) {
	MemHandle tItem;
	TrackRecordPacked *tRecPacked;
	UInt32 i, *trackPos, maxVisibleRows = TblGetNumberOfRows(table);

	trackPos = (UInt32 *)artistSelected->data;

	for(i = 0; i < maxVisibleRows; i++) {
		if((offsetIndex < artistSelected->sourceCount) && (i < sourceVisibleRows)) {
			tItem = DmQueryRecord(palantirDB, trackPos[offsetIndex] + DBTrackRecordStart);
			tRecPacked = (TrackRecordPacked *) MemHandleLock(tItem);
			MemHandleUnlock(tItem);
			TblSetItemPtr(table, i, 0, tRecPacked);
			TblSetItemInt(table, i, 0, offsetIndex);
			TblSetRowUsable(table, i, true);
			offsetIndex++;
		} else {
			TblSetRowUsable(table, i, false);
		}
	}
	TblRedrawTable(table);
}

//-------------------------
// Scroll the Source Table
//-------------------------

void ScrollSourceTable(Int32 newValue, Boolean setBar) {
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, SourceTable));
	Int32 maxValue = artistSelected->sourceCount - sourceVisibleRows;
	if(maxValue < 0)
		maxValue = 0;
	//make sure we don't scroll above 0 or below max
	if(newValue > maxValue)
		newValue = maxValue;
	if(newValue < 0)
		newValue = 0;

	sourceTablePosition = newValue;
	TblMarkTableInvalid(table);
	PopulateSourceTable(table, sourceTablePosition);
	if(setBar)
		SclSetScrollBar(sourceScrollBar, sourceTablePosition, 0, maxValue, sourceVisibleRows);
}

//----------------------------------------
// Initialize the Source Table scrollbars
//----------------------------------------

void InitSourceScrollBar() {
	Int16 max;
	if(sourceVisibleRows > artistSelected->sourceCount)
		max = 0;
	else
		max = artistSelected->sourceCount - sourceVisibleRows;
	SclSetScrollBar(sourceScrollBar, sourceTablePosition, 0, max, sourceVisibleRows);
}

//--------------------------------
// Resize the Source View for DIA
//--------------------------------

void SourceFormResizeForm(FormType *form, RectangleType *curBounds, RectangleType *displayBounds) {
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, SourceTable));
	Coord columnWidth, rowHeight = TblGetRowHeight(table, 0);
	Int16 heightDelta = 0, widthDelta = 0;

	// Determine the amount of the change 
	heightDelta = displayBounds->extent.y - displayBounds->topLeft.y - curBounds->extent.y - curBounds->topLeft.y; 
	widthDelta = displayBounds->extent.x - displayBounds->topLeft.x - curBounds->extent.x - curBounds->topLeft.x;

	MyFrmMoveObject(form, FrmGetObjectIndex(form, SourceButtonBack), 0, heightDelta); //move the back button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, SourceButtonPlaylist), 0, heightDelta); //move the playlist button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, SourceLabel), widthDelta, 0); //move the source label
	MyFrmMoveObject(form, FrmGetObjectIndex(form, SourceScrollBar), widthDelta, 0); //move the scroll bar

	//determine the visibile rows
	sourceVisibleRows = MyTblGetNumberOfRows(form, FrmGetObjectIndex(form, SourceTable),
												   FrmGetObjectIndex(form, SourceButtonPlaylist), rowHeight);
	
	MyFrmResizeObject(form, FrmGetObjectIndex(form, SourceTable), rowHeight * sourceVisibleRows, widthDelta);
	columnWidth = TblGetColumnWidth(table, 0);
	TblSetColumnWidth(table, 0, columnWidth + widthDelta);
	MyFrmResizeObject(form, FrmGetObjectIndex(form, SourceScrollBar), rowHeight * sourceVisibleRows, 0);
	
	InitSourceTable(table);
	InitSourceScrollBar();
	TblMarkTableInvalid(table);
	PopulateSourceTable(table, sourceTablePosition);
	TblRedrawTable(table);
}

//----------------------------
// Initialize the Source View
//----------------------------

void SourceFormInit(void) {
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, SourceTable));
	Coord rowHeight = TblGetRowHeight(table, 0);
	RectangleType curBounds, displayBounds; 

	if(hasDIA) {
		FrmSetDIAPolicyAttr(form, frmDIAPolicyCustom); 		//enable DIA support
		PINSetInputTriggerState(pinInputTriggerEnabled); 	//enable DIA trigger
		PINSetInputAreaState(pinInputAreaUser);
	}

	//set up some global variables
	lastScreen = SOURCE_SCREEN;
	currentScreen = SOURCE_SCREEN;
	sourceVisibleRows = MyTblGetNumberOfRows(form, FrmGetObjectIndex(form, SourceTable),
												   FrmGetObjectIndex(form, SourceButtonPlaylist), rowHeight);
	//set the source scroll bar object
	sourceScrollBar = (ScrollBarType *) FrmGetObjectPtr(form, FrmGetObjectIndex(form, SourceScrollBar));
	trackTablePosition = 0;				//set the track number at the top
	
	if(hasDIA) {
		WinGetBounds(FrmGetWindowHandle(form), &curBounds); 
		WinGetBounds(WinGetDisplayWindow(), &displayBounds);
		SourceFormResizeForm(form, &curBounds, &displayBounds);
		WinSetBounds(FrmGetWindowHandle(form), &displayBounds); 
	} else {
		InitSourceTable(table);
		InitSourceScrollBar();
		PopulateSourceTable(table, sourceTablePosition);
	}
	
	FrmDrawForm(form);
}

//---------------------------
// Handle events in BrowseForm
//---------------------------

Boolean SourceFormHandleEvent(EventType *event) {
	FormType *form = FrmGetActiveForm();
	RectangleType curBounds, displayBounds; 
	Boolean handled = false;
	Int16 row;
	TableType *table;

	switch(event->eType) {
	case frmOpenEvent:
		//FrmDrawForm(form);
		SourceFormInit();
		handled = true;
		break;
	case ctlSelectEvent:
		switch(event->data.ctlSelect.controlID) {
		case SourceButtonBack:
			FrmGotoForm(ArtistForm);
			handled = true;
			break;
		case SourceButtonPlaylist:
			FrmGotoForm(PlaylistForm);
			handled = true;
			break;
		default:
			break;
		}
		break;
	case menuEvent:
		handled = GlobalMenuHandleEvent();		
		break;
	case menuOpenEvent:
		if(event->data.menuOpen.cause != menuCommandCause) {
			handled = GlobalMenuHandleEvent();
		} else {
			//for some reason, if we handle the menuOpenEvent
			//the menu status does not get reset.. it is still
			//active because we allowed the command bar to exist
			//this is a workaround - re-init the form
			FrmGotoForm(SourceForm);
		}
		break;
	case sclRepeatEvent:
		ScrollSourceTable(event->data.sclExit.newValue, false);
		break;
	case keyDownEvent:
		if(event->data.keyDown.chr == vchrPageDown) {
			ScrollSourceTable(sourceTablePosition + sourceVisibleRows, true);
			handled = true;
		} else if(event->data.keyDown.chr == vchrPageUp) {
			ScrollSourceTable(sourceTablePosition - sourceVisibleRows, true);
			handled = true;
		} else if((event->data.keyDown.chr == vchrHardRockerCenter) ||
				  (event->data.keyDown.chr == vchrRockerRight)) {
			//do nothing - allow T5 and Treos to open alert manager on long presses
		} else if(event->data.keyDown.chr == vchrRockerCenter) {
			//T5 and Treo 6xx, all devices moving forward
			FrmGotoForm(PlaylistForm);
		} else if(event->data.keyDown.chr == vchrRockerLeft) {
			FrmGotoForm(ArtistForm);
		} else if(hasNavigator) {
			if(NavKeyPressed(event, Left))
				FrmGotoForm(ArtistForm);
			if(NavKeyPressed(event, Select))
				FrmGotoForm(PlaylistForm);
		}
		break;
	case tblSelectEvent:
		row = event->data.tblEnter.row;
		table = event->data.tblEnter.pTable;
		sourceSelected = TblGetItemInt(table, row, 0);
		FrmGotoForm(TrackForm);
		handled = true;
		break;
	case winDisplayChangedEvent:
		WinGetBounds(FrmGetWindowHandle(form), &curBounds); 
		WinGetBounds(WinGetDisplayWindow(), &displayBounds);
		SourceFormResizeForm(form, &curBounds, &displayBounds);
		WinSetBounds(FrmGetWindowHandle(form), &displayBounds); 
		FrmDrawForm(form); 
		handled = true;
		break;
	default:
		break;
	}
	return handled;
}
