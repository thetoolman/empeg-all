#include <PalmOS.h>
#include <ExgMgr.h>
#include "palantirResource.h"

Err IrTest(Char *msg) {

	ExgSocketType exgSocket;
	UInt32 sizeSent = 0;
	Err err = 0;
	UInt32 size = 0;
	
	MemSet(&exgSocket, sizeof(exgSocket), 0);
	size = MemPtrSize(msg);

	//exgSocket.noStatus = 1;
	exgSocket.description = "Playlist Data";
	exgSocket.name = "control.empeg";
	
	exgSocket.length = size;

	//FrmCustomAlert(BrowseAlertDebug, "Status", "Going to ExgPut...", NULL);
	err = ExgPut(&exgSocket);
	if (!err) {
		while (!err && sizeSent < size) {
			//FrmCustomAlert(BrowseAlertDebug, "Status", "Doing ExgSend...", NULL);
			sizeSent += ExgSend(&exgSocket, msg, size, &err);
		}
		ExgDisconnect(&exgSocket,err);
	} else {
		FrmCustomAlert(GlobalAlertDebug, "ERROR", "Error during ExgPut", NULL);
	}

	return err;
}
