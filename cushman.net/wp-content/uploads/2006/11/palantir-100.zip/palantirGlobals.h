//---------------------
// Database structures
//---------------------

//Index Record Structure in pdb - always record 0 ONLY!
typedef struct {
        UInt32		artistRecordStart;
        UInt32		artistRecordLength;
        UInt32		trackRecordStart;
        UInt32		trackRecordLength;
} IndexRecord;

//Artist Record Structure in pdb
typedef struct {
        UInt32		artistID;
        UInt32		trackCount;		//how many tracks
		UInt32		sourceCount;	//how many sources   
		Char		data[1];		//int[sourceCount] array + name
} ArtistRecord;
 
//Track Record Structure in pdb
typedef struct {
	UInt32		fid;
	UInt32		artistID;
	Char		data[1];
} TrackRecordPacked;

//Track Record Structure
typedef struct {
	UInt32		fid;
	UInt32		artistID;
	const Char	*year;
	const Char	*source;
	const Char	*track;
	const Char	*title;
	const Char	*genre;
	const Char	*bitrate;
	const Char	*duration;
} TrackRecord;

//-------------------------
// Define global constants
//-------------------------
#define HDR_ARTIST_RECORD_START		1
#define HDR_ARTIST_RECORD_LENGTH	2
#define HDR_TRACK_RECORD_START		3
#define HDR_TRACK_RECORD_LENGTH		4

#define UPLOAD_MODE_INSERT			0
#define UPLOAD_MODE_APPEND			1
#define UPLOAD_MODE_REPLACE			2
#define UPLOAD_MODE_ENQUEUE			3

#define NUM_SAVE_RECORDS			10

#define ARTIST_SCREEN				1
#define SOURCE_SCREEN				2
#define TRACK_SCREEN				3
#define PLAYLIST_SCREEN				4

#define APP_ID						'EmPC'
#define MUSIC_DB					"Palantir Music Database"
#define SAVE_DB						"Palantir Save Database"

#define targetOS					sysMakeROMVersion(3, 5, 0, sysROMStageRelease, 0)

//-------------------------
// Define global variables
//-------------------------
DmOpenRef palantirDB;				//palantir music database
DmOpenRef palantirSaveDB;			//palantir save database
UInt32 musicDBDate;					//date of creation
UInt32 uploadMode;					//upload mode
Boolean os_3_5;						//os is at least 3.5?
Boolean hasNavigator;				//do we have a navigator?
Boolean hasDIA;						//do we have a DIA?
Boolean hasNotify;					//do we have Notification?
Char searchFieldText[128];			//search field text

UInt32 DBArtistRecordStart,			//indexes from record 0 in the database
       DBArtistRecordLength,
       DBTrackRecordStart,
       DBTrackRecordLength;

ArtistRecord *artistSelected;		//pointer to the current artist
UInt32 artistSelectedIndex;			//index of the current artist
UInt32 artistVisibleRows;			//number of rows that are visible in artist form
UInt32 artistTablePosition;			//position of the list in the Artist Table
ScrollBarType *artistScrollBar; 	//scroll bar on the artist form

UInt32 sourceSelected;				//int value of the first record index of this album
UInt32 sourceVisibleRows;			//number of rows that are visible in source form
UInt32 sourceTablePosition;			//position of the list in the Source Table
ScrollBarType *sourceScrollBar; 	//scroll bar on the source form

UInt32 trackVisibleRows;			//number of rows that are visible in track form
UInt32 trackTablePosition;			//position of the list in the Track Table
UInt32 trackTotalCount;				//number of tracks in this view
ScrollBarType *trackScrollBar; 		//scroll bar on the track form

UInt32 playlistVisibleRows;			//number of rows that are visible in playlist form
UInt32 playlistTablePosition;		//position of the list in the Playlist Table
UInt32 playlistCount;				//number of items in playList
ScrollBarType *playlistScrollBar;	//scroll bar on the playlist form

UInt32 lastScreen;					//screen we were at last
UInt32 currentScreen;				//screen we are on now
UInt32 *playlist;					//pointer to the first array item

//----------------------
// Debug Functions/Vars
//----------------------
//FrmCustomAlert(GlobalAlertDebug, "newValue", StrIToA(charIntDebug, newValue), NULL);
Char charIntDebug[20];
Char charIntDebug2[20];

//--------------------------
// Set up outside functions
//--------------------------
extern Boolean GlobalMenuHandleEvent();														//palantirMenus.c
extern Boolean ArtistFormHandleEvent(EventType *event);										//palantirArtist.c
extern Boolean SourceFormHandleEvent(EventType *event);										//palantirSource.c
extern Boolean TrackFormHandleEvent(EventType *event);										//palantirTrack.c
extern Boolean PlaylistFormHandleEvent(EventType *event);									//palantirPlaylist.c
extern Err DatabaseOpen(DmOpenRef *refPtr, Char *name, UInt16 mode);						//palantirDatabase.c
extern UInt32 DatabaseSize(Char *name);														//palantirDatabase.c
extern Err DatabaseCreateSave();															//palantirDatabase.c
extern UInt32 DatabaseGetSaveValue(DmOpenRef db, UInt32 index);								//palantirDatabase.c
extern Err DatabasePutSaveValue(DmOpenRef db, UInt32 index, UInt32 value);					//palantirDatabase.c
extern UInt32 DatabaseGetIndexValue(DmOpenRef db, UInt32 index);							//palantirDatabase.c
extern void UnpackTrackRecord(TrackRecord *record, const TrackRecordPacked *recordPacked);	//palantirDatabase.c
extern Char *GetArtistName(UInt32 artistIndex);												//palantirDatabase.c
extern void *MyTblGetItemPtr(void *table, Int16 row, Int16 column);							//palantirUtil.c

extern void MyFrmMoveObject(FormType *form, UInt16 index, Int16 widthDelta, Int16 heightDelta);				//palantirUtil.c
extern void MyFrmResizeObject(FormType *form, UInt16 index, Int16 yExtent, Int16 widthDelta);				//palantirUtil.c
extern Int16 MyTblGetNumberOfRows(FormType *form, UInt16 tableIndex, UInt16 buttonIndex, Coord rowHeight);	//palantirUtil.c

extern void DrawArtistRow(void *table, Int16 row, Int16 column, RectangleType *bounds);		//palantirUtil.c
extern void DrawSourceRow(void *table, Int16 row, Int16 column, RectangleType *bounds);		//palantirUtil.c
extern void DrawTrackRow(void *table, Int16 row, Int16 column, RectangleType *bounds);		//palantirUtil.c
extern void DrawPlaylistRow(void *table, Int16 row, Int16 column, RectangleType *bounds);	//palantirUtil.c
extern Int32 PlaylistContains(UInt32 index);												//palantirPlaylist.c
extern void PlaylistAdd(UInt32 index);														//palantirPlaylist.c
extern void PlaylistRemove(UInt32 index);													//palantirPlaylist.c
