#include <PalmOS.h>
#include <Table.h>
#include <PalmChars.h>
#include "palantirResource.h"
#include "palantirGlobals.h"

//---------------------------------------
// Initialize the Track Table structure
//---------------------------------------

void InitTrackTable(TableType *table) {
	UInt32 i, maxVisibleRows = TblGetNumberOfRows(table);

	for(i = 0; i < maxVisibleRows; i++) {
		TblSetItemStyle(table, i, 0, checkboxTableItem);
		TblSetItemStyle(table, i, 1, customTableItem);
	}
	TblSetColumnUsable(table, 0, true);
	TblSetColumnUsable(table, 1, true);
	TblSetCustomDrawProcedure(table, 1, DrawTrackRow);
}

//-------------------------------------
// Populate the Track Table structure
//-------------------------------------

void PopulateTrackTable(TableType *table, UInt32 trackPos) {
	MemHandle tItem;
	TrackRecordPacked *tRecPacked;
	UInt32 i, index, *posArray = (UInt32 *)artistSelected->data;
	UInt32 maxVisibleRows = TblGetNumberOfRows(table);
	
	for(i = 0; i < maxVisibleRows; i++) {
		if((trackPos < trackTotalCount) && (i < trackVisibleRows)) {
			index = trackPos + posArray[sourceSelected] + DBTrackRecordStart;
			tItem = DmQueryRecord(palantirDB, index);
			tRecPacked = (TrackRecordPacked *) MemHandleLock(tItem);
			MemHandleUnlock(tItem);
			TblSetItemInt(table, i, 0, ((PlaylistContains(index) == -1) ? 0 : 1));
			TblSetItemPtr(table, i, 1, tRecPacked);
			TblSetItemInt(table, i, 1, index);
			TblSetRowUsable(table, i, true);
			trackPos++;
		} else {
			TblSetRowUsable(table, i, false);
		}
	}
	TblRedrawTable(table);
}

//-------------------------
// Scroll the Track Table
//-------------------------

void ScrollTrackTable(Int32 newValue, Boolean setBar) {
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, TrackTable));
	Int32 maxValue = trackTotalCount - trackVisibleRows;
	if(maxValue < 0)
		maxValue = 0;
	//make sure we don't scroll above 0 or below max
	if(newValue > maxValue)
		newValue = maxValue;
	if(newValue < 0)
		newValue = 0;

	trackTablePosition = newValue;
	TblMarkTableInvalid(table);
	PopulateTrackTable(table, trackTablePosition);
	if(setBar)
		SclSetScrollBar(trackScrollBar, trackTablePosition, 0, maxValue, trackVisibleRows);
}

//----------------------------------------
// Initialize the Track Table scrollbars
//----------------------------------------

void InitTrackScrollBar() {
	Int16 max;
	if(trackVisibleRows > trackTotalCount)
		max = 0;
	else
		max = trackTotalCount - trackVisibleRows;
	SclSetScrollBar(trackScrollBar, trackTablePosition, 0, max, trackVisibleRows);
}

//--------------------------------
// Resize the Track View for DIA
//--------------------------------

void TrackFormResizeForm(FormType *form, RectangleType *curBounds, RectangleType *displayBounds) {
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, TrackTable));
	Coord columnWidth, rowHeight = TblGetRowHeight(table, 0);
	Int16 heightDelta = 0, widthDelta = 0;

	// Determine the amount of the change 
	heightDelta = displayBounds->extent.y - displayBounds->topLeft.y - curBounds->extent.y - curBounds->topLeft.y; 
	widthDelta = displayBounds->extent.x - displayBounds->topLeft.x - curBounds->extent.x - curBounds->topLeft.x;

	MyFrmMoveObject(form, FrmGetObjectIndex(form, TrackButtonBack), 0, heightDelta); //move the back button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, TrackButtonAddAll), 0, heightDelta); //move the add all button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, TrackButtonPlaylist), 0, heightDelta); //move the playlist button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, TrackLabel), widthDelta, 0); //move the track label
	MyFrmMoveObject(form, FrmGetObjectIndex(form, TrackScrollBar), widthDelta, 0); //move the scroll bar

	//determine the visibile rows
	trackVisibleRows = MyTblGetNumberOfRows(form, FrmGetObjectIndex(form, TrackTable),
												  FrmGetObjectIndex(form, TrackButtonPlaylist), rowHeight);
	
	MyFrmResizeObject(form, FrmGetObjectIndex(form, TrackTable), rowHeight * trackVisibleRows, widthDelta);
	columnWidth = TblGetColumnWidth(table, 1);
	TblSetColumnWidth(table, 1, columnWidth + widthDelta);
	MyFrmResizeObject(form, FrmGetObjectIndex(form, TrackScrollBar), rowHeight * trackVisibleRows, 0);
	
	InitTrackTable(table);
	InitTrackScrollBar();
	TblMarkTableInvalid(table);
	PopulateTrackTable(table, trackTablePosition);
	TblRedrawTable(table);
}

//----------------------------
// Initialize the Track View
//----------------------------

void TrackFormInit(void) {
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, TrackTable));
	UInt32 firstTrack, lastTrack, *posArray;
	Coord rowHeight = TblGetRowHeight(table, 0);
	RectangleType curBounds, displayBounds; 

	if(hasDIA) {
		FrmSetDIAPolicyAttr(form, frmDIAPolicyCustom); 		//enable DIA support
		PINSetInputTriggerState(pinInputTriggerEnabled); 	//enable DIA trigger
		PINSetInputAreaState(pinInputAreaUser);
	}

	//set up some global variables
	lastScreen = TRACK_SCREEN;
	currentScreen = TRACK_SCREEN;
	trackVisibleRows = MyTblGetNumberOfRows(form, FrmGetObjectIndex(form, TrackTable),
												  FrmGetObjectIndex(form, TrackButtonPlaylist), rowHeight);

	//set the track scroll bar object
	trackScrollBar = (ScrollBarType *) FrmGetObjectPtr(form, FrmGetObjectIndex(form, TrackScrollBar));

	posArray = (UInt32 *)artistSelected->data;
	firstTrack = posArray[sourceSelected];
	lastTrack = (sourceSelected + 1) == artistSelected->sourceCount ?
	            posArray[0] + artistSelected->trackCount :
	            posArray[sourceSelected + 1];
	trackTotalCount = lastTrack - firstTrack;

	if(hasDIA) {
		WinGetBounds(FrmGetWindowHandle(form), &curBounds); 
		WinGetBounds(WinGetDisplayWindow(), &displayBounds);
		TrackFormResizeForm(form, &curBounds, &displayBounds);
		WinSetBounds(FrmGetWindowHandle(form), &displayBounds); 
	} else {
		InitTrackTable(table);
		InitTrackScrollBar();
		PopulateTrackTable(table, trackTablePosition);
	}
	
	FrmDrawForm(form);
}

//---------------------------
// Handle events in BrowseForm
//---------------------------

Boolean TrackFormHandleEvent(EventType *event) {
	Int16 row, column, i;
	UInt32 *posArray = (UInt32 *)artistSelected->data;
	UInt32 firstTrack = posArray[sourceSelected] + DBTrackRecordStart;
	FormType *form = FrmGetActiveForm();
	RectangleType curBounds, displayBounds; 
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, TrackTable));
	Boolean handled = false;

	switch(event->eType) {
	case frmOpenEvent:
		//FrmDrawForm(form);
		TrackFormInit();
		handled = true;
		break;
	case ctlSelectEvent:
		switch(event->data.ctlSelect.controlID) {
		case TrackButtonBack:
			FrmGotoForm(SourceForm);
			handled = true;
			break;
		case TrackButtonAddAll:
			for(i = 0; i < trackTotalCount; i++) {
				PlaylistAdd(firstTrack + i);
			}
			TblMarkTableInvalid(table);
			PopulateTrackTable(table,  trackTablePosition);
			handled = true;
			break;
		case TrackButtonPlaylist:
			FrmGotoForm(PlaylistForm);
			handled = true;
			break;
		default:
			break;
		}
		break;
	case menuEvent:
		handled = GlobalMenuHandleEvent();		
		break;
	case menuOpenEvent:
		if(event->data.menuOpen.cause != menuCommandCause) {
			handled = GlobalMenuHandleEvent();
		} else {
			//for some reason, if we handle the menuOpenEvent
			//the menu status does not get reset.. it is still
			//active because we allowed the command bar to exist
			//this is a workaround - re-init the form
			FrmGotoForm(TrackForm);
		}
		break;
	case sclRepeatEvent:
		ScrollTrackTable(event->data.sclExit.newValue, false);
		break;
	case keyDownEvent:
		if(event->data.keyDown.chr == vchrPageDown) {
			ScrollTrackTable(trackTablePosition + trackVisibleRows, true);
			handled = true;
		} else if(event->data.keyDown.chr == vchrPageUp) {
			ScrollTrackTable(trackTablePosition - trackVisibleRows, true);
			handled = true;
		} else if((event->data.keyDown.chr == vchrHardRockerCenter) ||
				  (event->data.keyDown.chr == vchrRockerRight)) {
			//do nothing - allow T5 and Treos to open alert manager on long presses
		} else if(event->data.keyDown.chr == vchrRockerCenter) {
			//T5 and Treo 6xx, all devices moving forward
			FrmGotoForm(PlaylistForm);
		} else if(event->data.keyDown.chr == vchrRockerLeft) {
			FrmGotoForm(SourceForm);
		} else if(hasNavigator) {
			if(NavKeyPressed(event, Left))
				FrmGotoForm(SourceForm);
			if(NavKeyPressed(event, Select))
				FrmGotoForm(PlaylistForm);
		}
		break;
	case tblSelectEvent:
		row = event->data.tblEnter.row;
		column = event->data.tblEnter.column;
		table = event->data.tblEnter.pTable;
		switch(column) {
		case 0:
			if(TblGetItemInt(table, row, 0) == 1) //checkbox was off, now it's on
				PlaylistAdd(TblGetItemInt(table, row, 1));
			else //checkbox was on, now it's off
				PlaylistRemove(TblGetItemInt(table, row, 1));
			break;
		default:
			break;
		}
		handled = true;
		break;
	case winDisplayChangedEvent:
		WinGetBounds(FrmGetWindowHandle(form), &curBounds); 
		WinGetBounds(WinGetDisplayWindow(), &displayBounds);
		TrackFormResizeForm(form, &curBounds, &displayBounds);
		WinSetBounds(FrmGetWindowHandle(form), &displayBounds); 
		FrmDrawForm(form); 
		handled = true;
		break;
	default:
		break;
	}
	return handled;
}
