#include <PalmOS.h>
#include <Table.h>
#include <Window.h>
#include <PalmChars.h>
#include "palantirResource.h"
#include "palantirGlobals.h"

//---------------------------------------
// Initialize the Artist Table structure
//---------------------------------------

void InitArtistTable(TableType *table) {
	UInt32 i, maxVisibleRows = TblGetNumberOfRows(table);

	for(i = 0; i < maxVisibleRows; i++)
		TblSetItemStyle(table, i, 0, customTableItem);
	TblSetColumnUsable(table, 0, true);
	TblSetCustomDrawProcedure(table, 0, DrawArtistRow);
}

//-------------------------------------
// Populate the Artist Table structure
//-------------------------------------

void PopulateArtistTable(TableType *table, UInt32 artistIndex) {
	MemHandle aItem;
	ArtistRecord *aRec;
	UInt32 i, maxVisibleRows = TblGetNumberOfRows(table);

	artistIndex += DBArtistRecordStart;

	for(i = 0; i < maxVisibleRows; i++) {
		if((artistIndex <= DBArtistRecordLength) && (i < artistVisibleRows)) {
			aItem = DmQueryRecord(palantirDB, artistIndex);
			aRec = (ArtistRecord *) MemHandleLock(aItem);
			MemHandleUnlock(aItem);
			TblSetItemPtr(table, i, 0, aRec);
			TblSetItemInt(table, i, 0, artistIndex);
			TblSetRowUsable(table, i, true);
			artistIndex++;
		} else {
			TblSetRowUsable(table, i, false);
		}
	}
	TblRedrawTable(table);
}

//-------------------------
// Scroll the Artist Table
//-------------------------

void ScrollArtistTable(Int32 newValue, Boolean setBar) {
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, ArtistTable));
	Int32 maxValue = DBArtistRecordLength - artistVisibleRows;
	if(maxValue < 0)
		maxValue = 0;
	//make sure we don't scroll above 0 or below max
	if(newValue > maxValue)
		newValue = maxValue;
	if(newValue < 0)
		newValue = 0;

	artistTablePosition = newValue;
	TblMarkTableInvalid(table);
	PopulateArtistTable(table, artistTablePosition);
	if(setBar)
		SclSetScrollBar(artistScrollBar, artistTablePosition, 0, maxValue, artistVisibleRows);
}

//----------------------------------------
// Initialize the Artist Table scrollbars
//----------------------------------------

void InitArtistScrollBar() {
	Int16 max;
	if(artistVisibleRows > DBArtistRecordLength)
		max = 0;
	else
		max = DBArtistRecordLength - artistVisibleRows;
	SclSetScrollBar(artistScrollBar, artistTablePosition, 0, max, artistVisibleRows);
}

//------------------------------
// Generate text without spaces
//------------------------------

void GenerateFixedText(Char *outputText, Char *inputText) {
	UInt16 i;
	StrCopy(outputText, inputText);
	for(i=0; i<StrLen(outputText); i++) {
		if((UInt32)outputText[i] == 32)  //remove the space
			MemMove(outputText + i, outputText + i + 1, (StrLen(outputText) - i));
	}
}

//------------------------------
// Generate text without spaces
//------------------------------

Int32 StrArtistCompare(Char *searchFieldFixed, UInt32 artistIndex) {
	Int32 comp;
	MemHandle artistNameH;
	Char *artistNameText, *artistNameFixed;

	artistNameText = GetArtistName(artistIndex);
	//replace all instances of space with ! in artistNameText
	artistNameH = MemHandleNew(sizeof(Char) * (StrLen(artistNameText) + 1));
	artistNameFixed = (Char *) MemHandleLock(artistNameH);
	GenerateFixedText(artistNameFixed, artistNameText);

	//FrmCustomAlert(GlobalAlertDebug, "Comparing:", searchFieldFixed, artistNameFixed);
	comp = StrNCaselessCompare(searchFieldFixed, artistNameFixed, StrLen(searchFieldFixed));

	MemHandleUnlock(artistNameH);
	MemHandleFree(artistNameH);

	return comp;
}

//-------------------------------------------------------------
// Does a binary search for artist entered in the search field
//-------------------------------------------------------------

void ArtistFormSearch(EventType *event) {
	FormType *form = FrmGetActiveForm();
	MemHandle searchFieldH;
	FieldPtr searchField = NULL;
	Char *searchFieldText, *searchFieldFixed;
	Int32 low = 0, foundRecord = -1, high, middle, comp;

	searchField = FrmGetObjectPtr(form, FrmGetObjectIndex(form, ArtistSearchField));
	FldHandleEvent(searchField, event);
	searchFieldText = FldGetTextPtr(searchField);

	if(searchFieldText != NULL) {	
		if(StrLen(searchFieldText) > 0) {
			searchFieldH = MemHandleNew(sizeof(Char) * (StrLen(searchFieldText) + 1));
			searchFieldFixed = (Char *) MemHandleLock(searchFieldH);
			GenerateFixedText(searchFieldFixed, searchFieldText);

			//binary search for the string
			high = DBArtistRecordLength - 1;
			while((foundRecord == -1) && (low <= high)) {
				middle = (low + high) / 2;

				comp = StrArtistCompare(searchFieldFixed, middle);
				if(comp < 0) {
					high = middle - 1;		//we are too high - search low end of array
				} else if (comp > 0) {
					low = middle + 1;		//we are too low - search high end of array
				} else {
					//we matched, now check the previous record
					if(middle == 0) {
						foundRecord = middle;
					} else {
						comp = StrArtistCompare(searchFieldFixed, middle - 1);
						if(comp == 0) {
							high = middle - 1;	//we are still too high
						} else {
							foundRecord = middle;
						}
					}
				}
			}
			if(foundRecord != -1)
				ScrollArtistTable(foundRecord, true);

			MemHandleUnlock(searchFieldH);
			MemHandleFree(searchFieldH);
		} else {
			ScrollArtistTable(0, true);
		}
	}
}

//--------------------------------
// Resize the Artist View for DIA
//--------------------------------

void ArtistFormResizeForm(FormType *form, RectangleType *curBounds, RectangleType *displayBounds) {
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, ArtistTable));
	Coord columnWidth, rowHeight = TblGetRowHeight(table, 0);
	Int16 heightDelta = 0, widthDelta = 0;
	RectangleType bounds;
	
	// Determine the amount of the change 
	heightDelta = displayBounds->extent.y - displayBounds->topLeft.y - curBounds->extent.y - curBounds->topLeft.y; 
	widthDelta = displayBounds->extent.x - displayBounds->topLeft.x - curBounds->extent.x - curBounds->topLeft.x;

		//FrmCustomAlert(GlobalAlertDebug, "heightDelta", StrIToA(charIntDebug, heightDelta), " ");
		//FrmCustomAlert(GlobalAlertDebug, "widthDelta", StrIToA(charIntDebug, widthDelta), " ");
	
	MyFrmMoveObject(form, FrmGetObjectIndex(form, ArtistSearchLabel), 0, heightDelta); //move the search label
	MyFrmMoveObject(form, FrmGetObjectIndex(form, ArtistSearchField), 0, heightDelta); //move the search field
	//resize the search field
	FrmGetObjectBounds(form, FrmGetObjectIndex(form, ArtistSearchField), &bounds);
	bounds.extent.x += widthDelta;
	FrmSetObjectBounds(form, FrmGetObjectIndex(form, ArtistSearchField), &bounds);
	
	MyFrmMoveObject(form, FrmGetObjectIndex(form, ArtistButtonPlaylist), widthDelta, heightDelta); //move the playlist button
	MyFrmMoveObject(form, FrmGetObjectIndex(form, ArtistLabel), widthDelta, 0); //move the artist label
	MyFrmMoveObject(form, FrmGetObjectIndex(form, ArtistScrollBar), widthDelta, 0); //move the scroll bar

	//determine the visibile rows
	artistVisibleRows = MyTblGetNumberOfRows(form, FrmGetObjectIndex(form, ArtistTable),
												   FrmGetObjectIndex(form, ArtistButtonPlaylist), rowHeight);

	MyFrmResizeObject(form, FrmGetObjectIndex(form, ArtistTable), rowHeight * artistVisibleRows, widthDelta);
	columnWidth = TblGetColumnWidth(table, 0);
	TblSetColumnWidth(table, 0, columnWidth + widthDelta);
	MyFrmResizeObject(form, FrmGetObjectIndex(form, ArtistScrollBar), rowHeight * artistVisibleRows, 0);
	
	InitArtistTable(table);
	InitArtistScrollBar();
	TblMarkTableInvalid(table);
	PopulateArtistTable(table, artistTablePosition);
	TblRedrawTable(table);
}

//----------------------------
// Initialize the Artist View
//----------------------------

void ArtistFormInit(void) {
	FormType *form = FrmGetActiveForm();
	TableType *table = FrmGetObjectPtr(form, FrmGetObjectIndex(form, ArtistTable));
	Coord rowHeight = TblGetRowHeight(table, 0);
	RectangleType curBounds, displayBounds; 
	
	if(hasDIA) {
		FrmSetDIAPolicyAttr(form, frmDIAPolicyCustom); 		//enable DIA support
		PINSetInputTriggerState(pinInputTriggerEnabled); 	//enable DIA trigger
		PINSetInputAreaState(pinInputAreaUser);
	}
		
	//set up some global variables
	lastScreen = ARTIST_SCREEN;
	currentScreen = ARTIST_SCREEN;
	artistVisibleRows = MyTblGetNumberOfRows(form, FrmGetObjectIndex(form, ArtistTable),
												   FrmGetObjectIndex(form, ArtistButtonPlaylist), rowHeight);

	//set the artist scroll bar object
	artistScrollBar = (ScrollBarType *) FrmGetObjectPtr(form, FrmGetObjectIndex(form, ArtistScrollBar));
	sourceTablePosition = 0;			//when we select an artist, first set the source at the top

	if(hasDIA) {
		WinGetBounds(FrmGetWindowHandle(form), &curBounds);	
		WinGetBounds(WinGetDisplayWindow(), &displayBounds);
		ArtistFormResizeForm(form, &curBounds, &displayBounds);
		WinSetBounds(FrmGetWindowHandle(form), &displayBounds); 
	} else {
		InitArtistTable(table);
		InitArtistScrollBar();
		PopulateArtistTable(table, artistTablePosition);
	}
	
	FrmDrawForm(form);
	FrmSetFocus(form, FrmGetObjectIndex(form, ArtistSearchField));
}

//---------------------------
// Handle events in ArtistForm
//---------------------------

Boolean ArtistFormHandleEvent(EventType *event) {
	FormType *form = FrmGetActiveForm();
	RectangleType curBounds, displayBounds; 
	Boolean handled = false;
	ArtistRecord *aRec;
	TableType *table;
	Int16 row;

	switch(event->eType) {
	case frmOpenEvent:
		ArtistFormInit();
		handled = true;
		break;
	case ctlSelectEvent:
		switch(event->data.ctlSelect.controlID) {
		case ArtistButtonPlaylist:
			FrmGotoForm(PlaylistForm);
			handled = true;
			break;
		default:
			break;
		}
		break;
	case menuEvent:
		handled = GlobalMenuHandleEvent();		
		break;
	case menuOpenEvent:
		if(event->data.menuOpen.cause != menuCommandCause) {
			handled = GlobalMenuHandleEvent();
		} else {
			//for some reason, if we handle the menuOpenEvent
			//the menu status does not get reset.. it is still
			//active because we allowed the command bar to exist
			//this is a workaround - re-init the form
			FrmGotoForm(ArtistForm);
		}
		break;
	case sclRepeatEvent:
		ScrollArtistTable(event->data.sclExit.newValue, false);
		break;
	case keyDownEvent:
		if(event->data.keyDown.chr == vchrPageDown) {
			ScrollArtistTable(artistTablePosition + artistVisibleRows, true);
			handled = true;
		} else if(event->data.keyDown.chr == vchrPageUp) {
			ScrollArtistTable(artistTablePosition - artistVisibleRows, true);
			handled = true;
		} else if(event->data.keyDown.chr == vchrRockerCenter) {
			//T5 and Treo 6xx, all devices moving forward
			FrmGotoForm(PlaylistForm);
		} else if((event->data.keyDown.chr == vchrHardRockerCenter) ||
				  (event->data.keyDown.chr == vchrRockerLeft) ||
				  (event->data.keyDown.chr == vchrRockerRight)) {
			//do nothing - allow T5 and Treos to open alert manager on long presses
		} else if(hasNavigator) {			
			if(NavKeyPressed(event, Select)) {
				FrmGotoForm(PlaylistForm);
			} else if (!IsFiveWayNavEvent(event)) {
				ArtistFormSearch(event);
			        handled = true;
			}
		} else {
			ArtistFormSearch(event);
			handled = true;
		}
		break;
	case fldChangedEvent:
		ArtistFormSearch(event);
		handled = true;
		break;
	case tblSelectEvent:
		row = event->data.tblEnter.row;
		table = event->data.tblEnter.pTable;
		aRec = MyTblGetItemPtr(table, row, 0);
		//make palm os 3.0 happy
		//aRec = (ArtistRecord *)table->items[row * table->numColumns + 0].ptr;
		artistSelected = aRec;
		artistSelectedIndex = TblGetItemInt(table, row, 0);
		FrmGotoForm(SourceForm);
		handled = true;
		break;
	case winDisplayChangedEvent:
		WinGetBounds(FrmGetWindowHandle(form), &curBounds); 
		WinGetBounds(WinGetDisplayWindow(), &displayBounds);
		ArtistFormResizeForm(form, &curBounds, &displayBounds);
		WinSetBounds(FrmGetWindowHandle(form), &displayBounds); 
		FrmDrawForm(form); 
		handled = true;
		break;
	default:
		break;
	}
	return handled;
}
