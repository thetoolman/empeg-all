#include <PalmOS.h>
#include "palantirResource.h"
#include "palantirGlobals.h"

//-------------------------------
// Draw the move indicator line
//-------------------------------

void DrawMovingLine(RectanglePtr r, Boolean draw) {
	if(draw) {
		WinDrawGrayLine(r->topLeft.x - 1,
		                r->topLeft.y + r->extent.y,
		                r->topLeft.x + r->extent.x - 2,
		                r->topLeft.y + r->extent.y);
	} else {
		WinEraseLine(r->topLeft.x - 1,
		             r->topLeft.y + r->extent.y,
		             r->topLeft.x + r->extent.x - 2,
		             r->topLeft.y + r->extent.y);
	}
}

//-------------------------------
// Invert (select) a table entry
//-------------------------------

void InvertItem(TablePtr table, Int16 row, Int16 column) {
	RectangleType r;
	
	TblGetItemBounds(table, row, column, &r);
	r.topLeft.x -= 2;
	r.extent.x += 1;
	WinInvertRectangle(&r, 0);
}

//----------------------
// Move a playlist Item
//----------------------

void PlaylistMove(EventType *event) {
	FormType *form = FrmGetActiveForm();
	UInt16 labelObjectIndex = FrmGetObjectIndex(form, PlaylistLabel);
	Int16 row, column, selectedRecord;
	TablePtr table;
	RectangleType r;
	Coord x, y;
	Boolean penDown = true, moving = false;
	Char cx[4], cy[4], newtext[13];

	row = event->data.tblSelect.row;
	column = event->data.tblSelect.column;
	table = event->data.tblSelect.pTable;

	//get the bounds of the rectangle we are in
	TblGetItemBounds(table, row, column, &r);

	//select the item we pen down'ed on
	selectedRecord = TblGetRowID(table, row);
	InvertItem(table, row, column);

	while(true) {
		PenGetPoint (&x, &y, &penDown);
		if(!penDown) break;

		//---------debug---------------------
		//---------debug---------------------
		StrIToA(cx, x); StrIToA(cy, y);
		StrPrintF(newtext, "x:%s y:%s", cx, cy);
		FrmHideObject(form, labelObjectIndex);
		FrmCopyLabel(form, PlaylistLabel, newtext);
		FrmShowObject(form, labelObjectIndex);
		//---------debug---------------------
		//---------debug---------------------

		if(!moving) {
			if(!RctPtInRectangle(x, y, &r)) {			//we just started moving
				moving = true;
				TblGetItemBounds(table, row, column, &r);
				DrawMovingLine(&r, true);
			}
		} else if(!RctPtInRectangle(x, y, &r)) {			//we are still on the move
			if(y < r.topLeft.y) {					//see if our cursor is above the rectangle
				if(row < 0) {					//see if we are at the top of the table
					
				} else {
					row--;
					DrawMovingLine(&r, false);
					r.topLeft.y -= r.extent.y;
					DrawMovingLine(&r, true);
				}
			} else if(y >= r.topLeft.y + r.extent.y) {		//see if our cursor is below the rectangle
				if(row > TblGetNumberOfRows(table) - 2) {	//we are at the bottom of the table
					
				} else {
					row++;
					DrawMovingLine(&r, false);
					r.topLeft.y += r.extent.y;
					DrawMovingLine(&r, true);
				}
			}
		}
		
		if(moving) {
			if(row >= 0)
				TblGetItemBounds(table, row, column, &r);
		}
	}
}