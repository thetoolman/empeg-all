#include <PalmOS.h>
#include "palantirGlobals.h"
#include "palantirResource.h"

//--------------------------------
// Handle events in the Main Menu
//--------------------------------

Boolean GlobalMenuHandleEvent() {
	FormType *form;
	DateTimeType datetime;
	TimeFormatType timeFormat;
	DateFormatType dateFormat;
	Char newtext[130], artists[6], tracks[6];
	Char date[longDateStrLength], time[timeStringLength];

	//MenuEraseStatus(0);
	form = FrmInitForm(AboutForm);

	//get the user's preference for date/time display
	timeFormat = PrefGetPreference(prefTimeFormat);
	dateFormat = PrefGetPreference(prefLongDateFormat);
	//now get the date it was updated
	TimSecondsToDateTime(musicDBDate, &datetime);
	//convert these to strings
	DateToAscii(datetime.month, datetime.day, datetime.year, dateFormat, date);
	TimeToAscii(datetime.hour, datetime.minute, timeFormat, time);

	StrPrintF(newtext, "Your music database contains\015%s artists and %s tracks.\015The database was last created\015on %s at %s.", StrIToA(artists, DBArtistRecordLength), StrIToA(tracks, DBTrackRecordLength), date, time);
	FrmCopyLabel(form, AboutLabel, newtext);

	FrmDoDialog(form);
	FrmDeleteForm(form);
	return true;
}
