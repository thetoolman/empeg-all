#include <PalmOS.h>
#include <PalmChars.h>
#include <NotifyMgr.h>
#include "palantirResource.h"
#include "palantirGlobals.h"

//-------------------------------
// Handle the application events
//-------------------------------

static Boolean AppHandleEvent(EventType *event) {
	FormType *form;
	UInt16 formID;
	Boolean	handled = false;

	if(event->eType == frmLoadEvent) {
		formID = event->data.frmLoad.formID;
		form = FrmInitForm(formID);
		FrmSetActiveForm(form);

		if(hasDIA) {
			WindowType *formWin = FrmGetWindowHandle(form);
			WinSetConstraintsSize(formWin, 160, 160, 225, 160, 160, 160); 	
		}

		switch(formID) {
		case ArtistForm:
			FrmSetEventHandler(form, ArtistFormHandleEvent);
			break;
		case SourceForm:
			FrmSetEventHandler(form, SourceFormHandleEvent);
			break;
		case TrackForm:
			FrmSetEventHandler(form, TrackFormHandleEvent);
			break;
		case PlaylistForm:
			FrmSetEventHandler(form, PlaylistFormHandleEvent);
			break;
		default:
			break;
		}
		handled = true;
	}
	return handled;
}

//------------
// Event Loop
//------------

static void AppEventLoop(void) {
	EventType event;
	Err error;

	do {
		EvtGetEvent(&event, evtWaitForever);
		if(!SysHandleEvent(&event))
			if(!MenuHandleEvent(0, &event, &error))
				if(!AppHandleEvent(&event))
					FrmDispatchEvent(&event);
	} while(event.eType != appStopEvent);
}

//---------------------
// Application Startup
//---------------------

static Err AppStart(void) {
	LocalID dbID;
	Err err = errNone;
	MemHandle aItem;
	UInt32 i, version, tmpCount, saveDBDate = 0;
	UInt16 cardNo;
	
	//find out what palmos version
	err = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &version); 
	if(err == errNone) {
		os_3_5 = (version < targetOS) ? false : true;
	} else {
		return err;
	}
	
	//find out if device has DIA
	err = FtrGet(pinCreator, pinFtrAPIVersion, &version); 
	hasDIA = ((err == errNone) && version) ? true : false;
	
	err = FtrGet(sysFtrCreator, sysFtrNumNotifyMgrVersion, &version); 
	hasNotify = (err == errNone) ? true : false;
	
	//find out if device has the PalmOne 5-way Navigator
	err = FtrGet(navFtrCreator, navFtrVersion, &version);
	hasNavigator = (err == errNone) ? true : false;
	
	//first open up the music database
	err = DatabaseOpen(&palantirDB, MUSIC_DB, dmModeReadOnly);
	if(err == errNone) {
		//get the date of the database
		musicDBDate = 0;
		dbID = DmFindDatabase(0, MUSIC_DB);
		DmDatabaseInfo(0, dbID, NULL, NULL, NULL, &musicDBDate, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
		//set up some global variables
		DBArtistRecordStart = DatabaseGetIndexValue(palantirDB, HDR_ARTIST_RECORD_START);
		DBArtistRecordLength = DatabaseGetIndexValue(palantirDB, HDR_ARTIST_RECORD_LENGTH);
		DBTrackRecordStart = DatabaseGetIndexValue(palantirDB, HDR_TRACK_RECORD_START);
		DBTrackRecordLength = DatabaseGetIndexValue(palantirDB, HDR_TRACK_RECORD_LENGTH);
	} else {
		return err;
	}

	//now open up the save database
	err = DatabaseOpen(&palantirSaveDB, SAVE_DB, dmModeReadWrite);
	if (err == errNone) {
		//get the date value so we can see if we need to create a new save db
		saveDBDate = DatabaseGetSaveValue(palantirSaveDB, 8);
		if(musicDBDate != saveDBDate) {
			//we have a different music database - delete old db and make new one
			//we have to close and delete the database first before writing over it
			DmCloseDatabase(palantirSaveDB);
			dbID = DmFindDatabase(0, SAVE_DB);
			DmDeleteDatabase(0, dbID);
			//FrmCustomAlert(GlobalAlertDebug, "creating new save db", "reason: new music", NULL);
			DatabaseCreateSave();
		}
	} else if (err == dmErrCantFind) {
		//we can't find a Palantir Save Database - create a new save database
		//FrmCustomAlert(GlobalAlertDebug, "creating new save db", "reason: can't find", NULL);
		DatabaseCreateSave();
	} else {
		//an error occurred
		return err;
	}

	//set up our initial variables
	artistSelectedIndex = DatabaseGetSaveValue(palantirSaveDB, 0);
	artistTablePosition = DatabaseGetSaveValue(palantirSaveDB, 1);
	sourceSelected = DatabaseGetSaveValue(palantirSaveDB, 2);
	sourceTablePosition = DatabaseGetSaveValue(palantirSaveDB, 3);
	trackTablePosition = DatabaseGetSaveValue(palantirSaveDB, 4);
	playlistTablePosition = DatabaseGetSaveValue(palantirSaveDB, 5);
	currentScreen = DatabaseGetSaveValue(palantirSaveDB, 6);
	lastScreen = DatabaseGetSaveValue(palantirSaveDB, 7);
	//save record 8 is for the date of the DB
	uploadMode = DatabaseGetSaveValue(palantirSaveDB, 9);

	//set up a pointer to the selected artist
	aItem = DmQueryRecord(palantirDB, artistSelectedIndex);
	artistSelected = (ArtistRecord *) MemHandleLock(aItem);
	MemHandleUnlock(aItem);
	
	//initialize the playlist
	tmpCount = DatabaseSize(SAVE_DB) - NUM_SAVE_RECORDS;
	playlistCount = 0;
	playlist = NULL;
		
	for(i = 0; i < tmpCount; i++) {		
		PlaylistAdd(DatabaseGetSaveValue(palantirSaveDB, NUM_SAVE_RECORDS));
		DmRemoveRecord(palantirSaveDB, NUM_SAVE_RECORDS);
	}

	//register for screen change notifications
	if(hasNotify) {
      	SysCurAppDatabase(&cardNo, &dbID);
		SysNotifyRegister(cardNo, dbID, sysNotifyDisplayResizedEvent, NULL, sysNotifyNormalPriority, NULL);
	}
	
	switch(currentScreen) {
		case ARTIST_SCREEN:
			FrmGotoForm(ArtistForm);
			break;
		case SOURCE_SCREEN:
			FrmGotoForm(SourceForm);
			break;
		case TRACK_SCREEN:
			FrmGotoForm(TrackForm);
			break;
		case PLAYLIST_SCREEN:
			FrmGotoForm(PlaylistForm);
			break;
		default:
			FrmGotoForm(ArtistForm);
	}
	
	return errNone;
}

//------------------
// Application Stop
//------------------

static void AppStop(void) {
	MemHandle newRecordH;
	UInt32 *newRecordP, i;
	UInt16 index;
	
	//set all the variables in the database
	DatabasePutSaveValue(palantirSaveDB, 0, artistSelectedIndex);
	DatabasePutSaveValue(palantirSaveDB, 1, artistTablePosition);
	DatabasePutSaveValue(palantirSaveDB, 2, sourceSelected);
	DatabasePutSaveValue(palantirSaveDB, 3, sourceTablePosition);
	DatabasePutSaveValue(palantirSaveDB, 4, trackTablePosition);
	DatabasePutSaveValue(palantirSaveDB, 5, playlistTablePosition);
	DatabasePutSaveValue(palantirSaveDB, 6, currentScreen);
	DatabasePutSaveValue(palantirSaveDB, 7, lastScreen);
	DatabasePutSaveValue(palantirSaveDB, 8, musicDBDate);
	DatabasePutSaveValue(palantirSaveDB, 9, uploadMode);
	
	//cycle through the playlist and write to the save db
	for(i = 0; i < playlistCount; i++) {
		index = dmMaxRecordIndex;
		newRecordH = DmNewRecord(palantirSaveDB, &index, sizeof(UInt32));
		newRecordP = MemHandleLock(newRecordH);
		DmWrite(newRecordP, 0, &playlist[i], sizeof(UInt32));
		MemHandleUnlock(newRecordH);
		DmReleaseRecord(palantirSaveDB, index, true);
	}

	//unlock the playlist if we have one
	if(playlistCount > 0) {
		MemHandle plst = MemPtrRecoverHandle(playlist);
		MemHandleUnlock(plst);
		MemHandleFree(plst);
	}
	
	//close down our dbs
	DmCloseDatabase(palantirDB);
	DmCloseDatabase(palantirSaveDB);
	FrmCloseAllForms();
}

//------------------------
// Main Function for Palm
//------------------------

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags) {
	Err error;

	switch(cmd) {
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();     	// Application Startup
			if(error) {
				return error;
			} else {
				AppEventLoop();         // Event loop
			}
			AppStop();              	// Application Stop
			break;
		case sysAppLaunchCmdNotify:
			//check to see if it is a display change - DIA
			if(((SysNotifyParamType*)cmdPBP)->notifyType == sysNotifyDisplayResizedEvent) { 
				EventType resizedEvent;
				MemSet(&resizedEvent, sizeof(EventType), 0); 
				resizedEvent.eType = winDisplayChangedEvent;	//add winDisplayChangedEvent to event queue 
				EvtAddUniqueEventToQueue(&resizedEvent, 0, true); 
			} 
			break;
		default:
			break;
	}
	return errNone;
}