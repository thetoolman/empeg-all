//#define ALLOW_ACCESS_TO_INTERNALS_OF_TABLES
 
#include <PalmOS.h>
#include <Table.h>
#include <WinGlue.h>
#include <TxtGlue.h>
#include <TblGlue.h>
#include "palantirResource.h"
#include "palantirGlobals.h"

void *MyTblGetItemPtr(void *table, Int16 row, Int16 column) {
	return TblGlueGetItemPtr(table, row, column);
}

void MyFrmMoveObject(FormType *form, UInt16 index, Int16 widthDelta, Int16 heightDelta) {
	Coord x, y;
	
	FrmGetObjectPosition(form, index, &x, &y);
	FrmSetObjectPosition(form, index, x + widthDelta, y + heightDelta);
}

void MyFrmResizeObject(FormType *form, UInt16 index, Int16 yExtent, Int16 widthDelta) {
	RectangleType bounds;
	
	FrmGetObjectBounds(form, index, &bounds);
	bounds.extent.y = yExtent;
	bounds.extent.x += widthDelta;
	FrmSetObjectBounds(form, index, &bounds);
}

Int16 MyTblGetNumberOfRows(FormType *form, UInt16 tableIndex, UInt16 buttonIndex, Coord rowHeight) {
	RectangleType tableBounds, buttonBounds;

	FrmGetObjectBounds(form, tableIndex, &tableBounds);
	FrmGetObjectBounds(form, buttonIndex, &buttonBounds);
	return (buttonBounds.topLeft.y - tableBounds.topLeft.y) / rowHeight;
}

void MyWinDrawTruncChars(const char * str, UInt16 length, Int16 x, Int16 y, Int16 maxWidth) {
	Boolean fitInWidth;
	Int16 len, width;
	width = maxWidth;
	len = length;
	fitInWidth = false;
	
	FntCharsInWidth(str, &width, &len, &fitInWidth);
	if (fitInWidth) {
		WinDrawChars(str, length, x, y);
	} else {
		WChar ch;

		/* Retrieve the ellipsis character. */
		ch = TxtGlueGetHorizEllipsisChar();

		/* Figure out how many characters can be shown with the ellipsis. */
		width = maxWidth - TxtGlueCharWidth(ch);
		len = length;
		fitInWidth = false;
		FntCharsInWidth(str, &width, &len, &fitInWidth);

		/* Draw the string and the ellipsis. */
		WinDrawChars(str, len, x, y);
		WinGlueDrawChar(ch, x + width, y);
	}
}

void DrawArtistRow(void *table, Int16 row, Int16 column, RectangleType *bounds) {
	ArtistRecord *aRec = MyTblGetItemPtr(table, row, column);
	Char *name = aRec->data + (4 * aRec->sourceCount);
	Char charNumSongs[5];
	FontID oldFont;
	
	StrIToA(charNumSongs, aRec->trackCount);

	oldFont = FntSetFont(stdFont);
	MyWinDrawTruncChars(name, StrLen(name),
	                      bounds->topLeft.x,
	                      bounds->topLeft.y,
	                      (bounds->extent.x - 10 - FntCharsWidth(charNumSongs, StrLen(charNumSongs))));
	FntSetFont(boldFont);
	MyWinDrawTruncChars(charNumSongs, StrLen(charNumSongs),
	                      bounds->topLeft.x + (bounds->extent.x - 2 - FntCharsWidth(charNumSongs, StrLen(charNumSongs))),
	                      bounds->topLeft.y,
	                      FntCharsWidth(charNumSongs, StrLen(charNumSongs)));
	FntSetFont(oldFont);
}

void DrawSourceRow(void *table, Int16 row, Int16 column, RectangleType *bounds) {
	TrackRecordPacked *tRecPacked = MyTblGetItemPtr(table, row, column);
	TrackRecord tRec;
	FontID oldFont;
	Char charNumSongs[5];
	UInt32 *posArray = (UInt32 *)artistSelected->data;
	UInt32 offsetIndex = TblGetItemInt(table, row, column);
	UInt32 nextPos, thisPos = posArray[offsetIndex];

	nextPos = (offsetIndex + 1) == artistSelected->sourceCount ?
	          posArray[0] + artistSelected->trackCount :
	          posArray[offsetIndex + 1];

	StrIToA(charNumSongs, nextPos - thisPos);
	UnpackTrackRecord(&tRec, tRecPacked);

	oldFont = FntSetFont(stdFont);
	WinSetUnderlineMode(noUnderline);
	MyWinDrawTruncChars(tRec.source, StrLen(tRec.source),
	                      bounds->topLeft.x,
	                      bounds->topLeft.y,
	                      (bounds->extent.x - 10 - FntCharsWidth(charNumSongs, StrLen(charNumSongs))));
	FntSetFont(boldFont);
	MyWinDrawTruncChars(charNumSongs, StrLen(charNumSongs),
	                      bounds->topLeft.x + (bounds->extent.x - 2 - FntCharsWidth(charNumSongs, StrLen(charNumSongs))),
	                      bounds->topLeft.y,
	                      FntCharsWidth(charNumSongs, StrLen(charNumSongs)));
	FntSetFont(oldFont);
}

void DrawTrackRow(void *table, Int16 row, Int16 column, RectangleType *bounds) {
	TrackRecordPacked *tRecPacked = MyTblGetItemPtr(table, row, column);
	TrackRecord tRec;
	FontID oldFont;

	UnpackTrackRecord(&tRec, tRecPacked);

	oldFont = FntSetFont(stdFont);
	WinSetUnderlineMode(noUnderline);
	MyWinDrawTruncChars(tRec.title, StrLen(tRec.title),
	                      bounds->topLeft.x,
	                      bounds->topLeft.y,
	                      (bounds->extent.x - 10 - FntCharsWidth(tRec.duration, StrLen(tRec.duration))));
	FntSetFont(boldFont);
	MyWinDrawTruncChars(tRec.duration, StrLen(tRec.duration),
	                      bounds->topLeft.x + (bounds->extent.x - 2 - FntCharsWidth(tRec.duration, StrLen(tRec.duration))),
	                      bounds->topLeft.y,
	                      FntCharsWidth(tRec.duration, StrLen(tRec.duration)));
	FntSetFont(oldFont);
}

void DrawPlaylistRow(void *table, Int16 row, Int16 column, RectangleType *bounds) {
	TrackRecordPacked *tRecPacked = MyTblGetItemPtr(table, row, column);
	TrackRecord tRec;
	FontID oldFont;

	UnpackTrackRecord(&tRec, tRecPacked);

	oldFont = FntSetFont(stdFont);
	WinSetUnderlineMode(noUnderline);
	MyWinDrawTruncChars(tRec.title, StrLen(tRec.title),
	                      bounds->topLeft.x,
	                      bounds->topLeft.y,
	                      (bounds->extent.x - 10 - FntCharsWidth(tRec.duration, StrLen(tRec.duration))));
	FntSetFont(boldFont);
	MyWinDrawTruncChars(tRec.duration, StrLen(tRec.duration),
	                      bounds->topLeft.x + (bounds->extent.x - 2 - FntCharsWidth(tRec.duration, StrLen(tRec.duration))),
	                      bounds->topLeft.y,
	                      FntCharsWidth(tRec.duration, StrLen(tRec.duration)));
	FntSetFont(oldFont);
}
