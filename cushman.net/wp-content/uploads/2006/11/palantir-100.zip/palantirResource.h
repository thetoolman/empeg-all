//------------------------------
// Define application resources
//------------------------------
#define AppID					1000
#define PalantirIcon			1000
#define AppIconID				1000
#define AppVersionID			1000

//forms
#define ArtistForm				1000
#define SourceForm				2000
#define TrackForm				3000
#define PlaylistForm			4000
#define AboutForm				5000

//buttons
#define ArtistButtonPlaylist	1100
#define SourceButtonBack		2100
#define SourceButtonPlaylist	2101
#define TrackButtonBack			3100
#define TrackButtonPlaylist		3101
#define TrackButtonAddAll		3102
#define PlaylistButtonBack		4100
#define PlaylistButtonBeam		4101
#define PlaylistButtonRemoveAll 4102
#define AboutButtonClose		5100

//tables
#define ArtistTable				1200
#define SourceTable				2200
#define TrackTable				3200
#define PlaylistTable			4200

//labels
#define ArtistLabel				1300
#define ArtistSearchLabel		1301
#define SourceLabel				2300
#define TrackLabel				3300
//#define PlaylistLabel			4300
#define AboutLabel				5300

//scroll bars
#define ArtistScrollBar			1600
#define SourceScrollBar			2600
#define TrackScrollBar			3600
#define PlaylistScrollBar		4600

//fields
#define ArtistSearchField		1700

//triggers
#define PlaylistModeTrigger		4700

//lists
#define PlaylistModeList		4800

//menus
#define GlobalMenuBar			1000

//alerts
#define GlobalAlertDebug		1000
#define PlaylistRemoveAllAlert	1001