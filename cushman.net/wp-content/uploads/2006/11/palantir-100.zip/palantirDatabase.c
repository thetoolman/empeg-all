#include <PalmOS.h>
#include "palantirResource.h"
#include "palantirGlobals.h"

//------------------------
// Unpack the TrackRecord
//------------------------
void UnpackTrackRecord(TrackRecord *record, const TrackRecordPacked *recordPacked) {
	const char *data = recordPacked->data;

	//assign the constant length vars here
	record->fid = recordPacked->fid;
	record->artistID = recordPacked->artistID;

	//now unpack the string data
	record->year = data;
	data += StrLen(data) + 1; record->source = data;
	data += StrLen(data) + 1; record->track = data;
	data += StrLen(data) + 1; record->title = data;
	//data += StrLen(data) + 1; record->genre = data;
	//data += StrLen(data) + 1; record->bitrate = data;
	data += StrLen(data) + 1; record->duration = data;
}

//------------------------------------------
// Get the Artist Name from an artist index
//------------------------------------------

Char *GetArtistName(UInt32 artistIndex) {
	MemHandle aItem = DmQueryRecord(palantirDB, artistIndex + DBArtistRecordStart);
	ArtistRecord *aRec = (ArtistRecord *) MemHandleLock(aItem);
	MemHandleUnlock(aItem);
	return aRec->data + (4 * aRec->sourceCount);
}

//----------------------
// Get the index record
//----------------------

UInt32 DatabaseGetIndexValue(DmOpenRef db, UInt32 index) {
	IndexRecord *rec;
	UInt32 returnValue = -1;
	MemHandle indexItem = DmQueryRecord(db, 0);

	if(indexItem) {
		rec = (IndexRecord *) MemHandleLock(indexItem);
		switch(index) {
		case HDR_ARTIST_RECORD_START:
			returnValue = rec->artistRecordStart;
			break;
		case HDR_ARTIST_RECORD_LENGTH:
			returnValue = rec->artistRecordLength;
			break;
		case HDR_TRACK_RECORD_START:
			returnValue = rec->trackRecordStart;
			break;
		case HDR_TRACK_RECORD_LENGTH:
			returnValue = rec->trackRecordLength;
			break;
		default:
		}
		MemHandleUnlock(indexItem);
	}
	return returnValue;
}

//----------------------
// Get a save value
//----------------------

UInt32 DatabaseGetSaveValue(DmOpenRef db, UInt32 index) {
	MemHandle saveItem = DmQueryRecord(db, index);
	UInt32 *rec = (UInt32 *) MemHandleLock(saveItem);
	MemHandleUnlock(saveItem);
	return *rec;
}

//----------------------
// Modify a save value
//----------------------

Err DatabasePutSaveValue(DmOpenRef db, UInt32 index, UInt32 value) {
	Err err = errNone;
	MemHandle saveItem = DmGetRecord(db, index);
	UInt32 *rec = (UInt32 *) MemHandleLock(saveItem);

	err = DmWrite(rec, 0, &value, sizeof(UInt32));

	MemHandleUnlock(saveItem);
	DmReleaseRecord(db, index, true);
	return err;
}

//----------------------
// Size of the Database
//----------------------

UInt32 DatabaseSize(Char *name) {
	Err err = errNone;
	LocalID dbID;
	UInt32 size;

	dbID = DmFindDatabase(0, name);
	err = DmGetLastErr();
	if(err != errNone) ErrAlert(err);
	err = DmDatabaseSize(0, dbID, &size, NULL, NULL);
	if(err != errNone) ErrAlert(err);

	return size;
}

//------------------------
// Create a blank Save DB
//------------------------

Err DatabaseCreateSave() {
	MemHandle newRecordH;
	UInt16 recordIndex = 0;
	Err err = errNone;
	UInt32 *newRecordP, newRecordValue = 0;
	UInt16 i;
	
	err = DmCreateDatabase(0, SAVE_DB, APP_ID, 'DATA', false);
	if(err != errNone) return err;
	err = DatabaseOpen(&palantirSaveDB, SAVE_DB, dmModeReadWrite);
	if(err != errNone) return err;

	//now let's initialize it with nine 0 values
	for(i = 0; i < NUM_SAVE_RECORDS; i++) {
		newRecordH = DmNewRecord(palantirSaveDB, &recordIndex, sizeof(UInt32));
		newRecordP = MemHandleLock(newRecordH);
		DmWrite(newRecordP, 0, &newRecordValue, sizeof(UInt32));
		MemHandleUnlock(newRecordH);
		DmReleaseRecord(palantirSaveDB, 0, true);
	}
	
	return err;
}

//----------------------
// Open up our database
//----------------------

Err DatabaseOpen(DmOpenRef *refPtr, Char *name, UInt16 mode) {
	Err err = errNone;
	DmOpenRef ref = NULL;
	LocalID dbID;

	dbID = DmFindDatabase(0, name);
	err = DmGetLastErr();
	if(err == errNone) {
		ref = DmOpenDatabase(0, dbID, mode);
		err = DmGetLastErr();
	} else {
		return err;
	}

	*refPtr = ref;
	return err;
}
