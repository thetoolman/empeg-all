#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <openobex/obex.h>
#include <sys/wait.h>

#define HEADER_CREATOR_ID 0xcf
#define HEADER_DESCRIPTION 0x05

obex_t *handle = NULL;
volatile int finished = 0;
int threshold = 50;		//how many fids to wait for before pausing
int t_wait = 3;			//how many seconds to wait when pausing

void fid_command(const uint8_t *fid, int notify_fd) {
	char *serial_cmd;
	serial_cmd = malloc(strlen(fid) + 9);
	snprintf(serial_cmd, strlen(fid) + 9, "SERIAL=%s\n", fid);
	write(notify_fd, serial_cmd, strlen(serial_cmd));
	free(serial_cmd);
}

void msg_popup(int count, int notify_fd, char *action, int *done) {
	char serial_cmd[39];
	char prefix[9] = "";
	
	if(count < 100)
		strcpy(prefix, "Empire: ");
	else
		strcpy(prefix, "   ");
	
	if(*done != 1) {
		if(count >= 10)
			sprintf(serial_cmd, "popup 5 %s%d songs %s", prefix, count, action);
		else if(count > 1)
			sprintf(serial_cmd, "popup 5 %s%d songs %s", prefix, count, action);
		else
			sprintf(serial_cmd, "popup 5 %s%d song %s", prefix, count, action);
		write(notify_fd, serial_cmd, strlen(serial_cmd));
	}
	*done = 1;
}

void empeg_action(char *name, int body_len, const uint8_t *uint8_t_body) {
	int i, notify_fd;
	int popup_done = 0;
	char fid[14], action[12];
	char serial_cmd[39];
	
	if(strncmp(name, "palantir_", 9) == 0) {
		if((notify_fd = open("/proc/empeg_notify", O_WRONLY)) != -1) {
			if(strcmp(name, "palantir_insert.empeg") == 0) {
				//insert mode
				strcpy(action, "inserted");
				strcpy(fid, "#XXXXXXXX0!");
				for(i = body_len - 8; i >= 0; i -= 8) {
					memcpy(fid + 1, (uint8_t_body + i), 8);
					fid_command(fid, notify_fd);
					if((((((body_len - 8) - i) / 8) % threshold) == 0) & (((body_len - 8) - i) > 1)) {
						//fprintf(stderr, "Empire: insert reached modulus of %d songs: %d %% %d = %d\n", threshold, (((body_len - 8) - i) / 2), threshold, ((((body_len - 8) - i) / 2) % threshold));
						sprintf(serial_cmd, "popup 180 Empire: inserting songs...");
						write(notify_fd, serial_cmd, strlen(serial_cmd));
						//msg_popup(body_len / 8, notify_fd, action, &popup_done);
						sleep(t_wait);	
					}
				}
			} else if(strcmp(name, "palantir_append.empeg") == 0) {
				//append mode
				strcpy(action, "appended");
				strcpy(fid, "#XXXXXXXX0%2B");
				for(i = 0; i <= body_len - 8; i += 8) {
					//hijack interprets plus signs - convert to url-ecoded plus %2B
					strcpy(fid, "#XXXXXXXX0%2B");
					memcpy(fid + 1, (uint8_t_body + i), 8);
					fid_command(fid, notify_fd);
					if((((i / 8) % threshold) == 0) & (i > 1)) {
						//fprintf(stderr, "Empire: append reached modulus of %d songs: %d %% %d = %d\n", threshold, (i / 8), threshold, ((i / 8) % threshold));
						msg_popup(body_len / 8, notify_fd, action, &popup_done);
						sleep(t_wait);	
					}
				}
			} else if(strcmp(name, "palantir_replace.empeg") == 0) {
				//replace mode
				strcpy(action, "in playlist");
				//play the first fid, then append to the rest
				strcpy(fid, "#XXXXXXXX0 ");
				memcpy(fid + 1, (uint8_t_body), 8);
				fid_command(fid, notify_fd);
				strcpy(fid, "#XXXXXXXX0%2B");
				for(i = 8; i <= body_len - 8; i += 8) {
					memcpy(fid + 1, (uint8_t_body + i), 8);
					fid_command(fid, notify_fd);
					if((((i / 8) % threshold) == 0) & (i > 1)) {
						//fprintf(stderr, "Empire: replace reached modulus of %d songs: %d %% %d = %d\n", threshold, (i / 8), threshold, ((i / 8) % threshold));
						msg_popup(body_len / 8, notify_fd, action, &popup_done);
						sleep(t_wait);	
					}
				}
			} else if(strcmp(name, "palantir_enqueue.empeg") == 0) {
				//enqueue mode
				strcpy(action, "enqueued");
				strcpy(fid, "#XXXXXXXX0-");
				for(i = 0; i <= body_len - 8; i += 8) {
					memcpy(fid + 1, (uint8_t_body + i), 8);
					fid_command(fid, notify_fd);
					if((((i / 8) % threshold) == 0) & (i > 1)) {
						//fprintf(stderr, "Empire: enqueue reached modulus of %d songs: %d %% %d = %d\n", threshold, (i / 8), threshold, ((i / 8) % threshold));
						msg_popup(body_len / 8, notify_fd, action, &popup_done);
						sleep(t_wait);	
					}
				}
			}

			msg_popup(body_len / 8, notify_fd, action, &popup_done);
			//close the file handle
			close(notify_fd);
		}
	}
}

void put_done(obex_object_t *object) {
	obex_headerdata_t header_data;
	uint8_t header_ident;
	int hlen, body_len = 0;
	const uint8_t *uint8_t_body = NULL;
	char *name = NULL, *namebuf = NULL;

	while(OBEX_ObjectGetNextHeader(handle, object, &header_ident, &header_data, &hlen)) {
		switch(header_ident) {

		case OBEX_HDR_BODY:
			uint8_t_body = header_data.bs;
			body_len = hlen;
			break;

		case OBEX_HDR_NAME:
			if((namebuf = malloc(hlen / 2))) {
				OBEX_UnicodeToChar(namebuf, header_data.bs, hlen);
				name = namebuf;
			}
			break;

		case HEADER_DESCRIPTION:	//recieved a part of the description
		case OBEX_HDR_LENGTH:		//recieved the length of the header
		case HEADER_CREATOR_ID:		//recieved the creator id
		default:			//other header we don't care about
		}
	}

	if (fork() == 0) {
		empeg_action(name, body_len, uint8_t_body);
		exit(0);
	}
	
	free(namebuf);
}

void server_request(obex_object_t *object, int event, int cmd) {
	switch(cmd) {
	case OBEX_CMD_SETPATH:
		OBEX_ObjectSetRsp(object, OBEX_RSP_CONTINUE, OBEX_RSP_SUCCESS);
		break;
	case OBEX_CMD_PUT:
		OBEX_ObjectSetRsp(object, OBEX_RSP_CONTINUE, OBEX_RSP_SUCCESS);
		put_done(object);
		break;
	case OBEX_CMD_CONNECT:
	case OBEX_CMD_DISCONNECT:
		OBEX_ObjectSetRsp(object, OBEX_RSP_SUCCESS, OBEX_RSP_SUCCESS);
		break;
	default:
		OBEX_ObjectSetRsp(object, OBEX_RSP_NOT_IMPLEMENTED, OBEX_RSP_NOT_IMPLEMENTED);
		break;
	}
	return;
}

void obex_event_handler(obex_t *handle, obex_object_t *object, int mode, int event, int obex_cmd, int obex_rsp) {
	switch (event)	{
	case OBEX_EV_PROGRESS:	// a piece has been recieved
		break;
	case OBEX_EV_REQDONE:
		if(obex_cmd == OBEX_CMD_DISCONNECT) {
			finished = 1;
			OBEX_TransportDisconnect(handle);
		}
		break;
	case OBEX_EV_REQHINT:
		switch(obex_cmd) {
		case OBEX_CMD_PUT:		//Getting object
		case OBEX_CMD_CONNECT:
		case OBEX_CMD_DISCONNECT:
			OBEX_ObjectSetRsp(object, OBEX_RSP_CONTINUE, OBEX_RSP_SUCCESS);
			break;
		default:
			OBEX_ObjectSetRsp(object, OBEX_RSP_NOT_IMPLEMENTED, OBEX_RSP_NOT_IMPLEMENTED);
			break;
		}
		break;
	case OBEX_EV_REQ:
		// Comes when a server-request has been completed
		server_request(object, event, obex_cmd);
		break;
	case OBEX_EV_LINKERR:
		finished = 1;
		break;
	default:
	}
}

int main(int argc, char **argv) {
	char linkname[128];
	char pathname[128];
	char irattachCommand[128];
	int pid_status, c, ilen = -1;
	int seconds = 12;  //default to 12 second wait
		
	fprintf(stderr, "Empire: Version 0.40 starting...\n");
	// empire -w <startup wait> -f <fid threshold> -p <seconds to pause>

	while((c = getopt(argc, argv, "w:f:p:")) != -1)
		switch(c) {
			case 'w':
				seconds = atoi(optarg);
				break;
			case 'f':
				threshold = atoi(optarg);
				break;
			case 'p':
				t_wait = atoi(optarg);
				break;
			case '?':
				fprintf(stderr, "Unknown option `-%c'.\n", optopt);
				exit(1);
			default:
				abort();
        }
			
	//background
	if (fork() != 0)
		return 0;																																	 

	//get the "working directory"
	snprintf(linkname, sizeof(linkname), "/proc/%d/exe", getpid());
	ilen = readlink(linkname, pathname, 128);
	pathname[ilen - 7] = '\0';

	//first we have to start irattach AFTER the player starts
	sleep(seconds);
	snprintf(irattachCommand, sizeof(irattachCommand), "%s/irattach /dev/ttyS2", pathname);
	system(irattachCommand);

	//now begin the IrDA stuff
	handle = OBEX_Init(OBEX_TRANS_IRDA, obex_event_handler, 0);
	while(1) {
		IrOBEX_ServerRegister(handle, "OBEX");
		while (!finished) {
			OBEX_HandleInput(handle, 1);
			//clean up any children
			waitpid(0, &pid_status, WNOHANG);
		}
		finished = 0;
	}
	return 0;
}
