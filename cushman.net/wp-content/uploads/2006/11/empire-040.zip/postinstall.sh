#!/bin/bash
DESTDIR=$1
LAUNCH=$2

cp /empeg/var/config.ini /empeg/var/config.ini.pre-empire

cp /empeg/var/config.ini /empeg/var/config.ini.work
grep -i  "\[output\]" /empeg/var/config.ini.work > /dev/null
if [ $? == 0 ]; then
echo "adding notify to [output] block"
sed -e "/^notify=/I d
/^\[output\]/I a\\
notify=1" /empeg/var/config.ini.work > /empeg/var/config.ini
else 
echo "creating [output] block"
cat >> /empeg/var/config.ini <<EOF
[output]
notify=1
EOF
fi

cp /empeg/var/config.ini /empeg/var/config.ini.work
grep -i  "\[hijack\]" /empeg/var/config.ini.work > /dev/null
if [ $? == 0 ]; then
echo "adding suppress_notify to [hijack] block"
sed -e "/^suppress_notify=/I d
/^\[hijack\]/I a\\
suppress_notify=1" /empeg/var/config.ini.work > /empeg/var/config.ini
else
echo "creating [hijack] block"
cat >> /empeg/var/config.ini <<EOF
[hijack]
suppress_notify=1
EOF
fi

if [ $LAUNCH == 1 ]; then
cp /empeg/var/config.ini /empeg/var/config.ini.work
    grep -i  "\[hijack\]" /empeg/var/config.ini.work > /dev/null
    if [ $? = 0 ]; then
    echo "adding EXEC_ONCE to [hijack] block"
sed -e "/^;@EXEC_ONCE .*empire/I d
/^\[hijack\]/I a\\
;@EXEC_ONCE $DESTDIR/empire" /empeg/var/config.ini.work > /empeg/var/config.ini
    else
    cat >> /empeg/var/config.ini <<EOF
[hijack]
;@EXEC_ONCE $DESTDIR/empire
EOF
    fi
fi 

rm -f /empeg/var/config.ini.work

