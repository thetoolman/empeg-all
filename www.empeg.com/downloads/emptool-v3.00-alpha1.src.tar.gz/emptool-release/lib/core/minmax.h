/* minmax.h
 *
 * Some versions of C++ STL don't contain these standard functions
 *
 * (C) 2000 empeg ltd, http://www.empeg.com
 *
 * This software is licensed under the GNU General Public Licence (see file
 * COPYING), unless you possess an alternative written licence from empeg ltd.
 *
 * (:Empeg Source Release 1.8 13-Mar-2003 18:15 rob:)
 */

#ifndef MINMAX_H
#define MINMAX_H

#define EMPEG_NEED_MINMAX

#ifdef __GNUC__
//#if (__GNUC__ > 2) || ( (__GNUC__ == 2) && (__GNUC_MINOR__ > 94) )
#include <algorithm>

// Trouble is that Windows doesn't like min and max in the std
// namespace and Linux wants them to be. :(
using std::min;
using std::max;
#undef EMPEG_NEED_MINMAX
//#endif
#endif

#ifdef WIN32
#ifdef min
#undef EMPEG_NEED_MINMAX
#endif //min
#endif // WIN32

#ifdef EMPEG_NEED_MINMAX

template<class T>
const T &min(const T &a, const T &b)
{
    return (a < b) ? a : b;
}

template<class T>
const T &max(const T &a, const T &b)
{
    return (a < b) ? b : a;
}

#endif

#endif

