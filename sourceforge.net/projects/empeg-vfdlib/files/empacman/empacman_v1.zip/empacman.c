/*

empacman
Copyright (C) 2002  Richard Kirkby

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Send comments, suggestions, bug reports to rkirkby (at) cs.waikato.ac.nz

*/

#include <stdlib.h>
#include <sys/ioctl.h>
#include <asm/arch/hijack.h>
#include <time.h>
#include <sys/time.h>
#include <linux/errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include "vfdlib.h"

/* GAME CONSTANTS ************************************************************/

#define GAME_VERSION               1

#define GAME_FPS                   25
#define GAME_FRAME_TIME_uSEC       (1000000 / GAME_FPS)

#define HALF_BOARD_WIDTH           15
#define BOARD_WIDTH                (HALF_BOARD_WIDTH * 2)
#define BOARD_HEIGHT               33

#define SUB_PIXEL_BITS             8
#define PACMAN_FREE_SPEED          300
#define PACMAN_EATING_SPEED        256

#define DIR_NONE                   0
#define DIR_UP                     1
#define DIR_DOWN                   2
#define DIR_LEFT                   3
#define DIR_RIGHT                  4

#define GAMESTATE_SPLASHSCREEN     0
#define GAMESTATE_BOARDSTART       1
#define GAMESTATE_PLAYING          2
#define GAMESTATE_SCOREPAUSE       3
#define GAMESTATE_BOARDCOMPLETE    4
#define GAMESTATE_DYING            5
#define GAMESTATE_GAMEOVER         6

#define PACSTATE_WAITING           0
#define PACSTATE_ALIVE             1
#define PACSTATE_DYING             2

#define GHOSTSTATE_ROAMING         0
#define GHOSTSTATE_SCATTERING      1
#define GHOSTSTATE_FLEEING         2
#define GHOSTSTATE_EATEN           3
#define GHOSTSTATE_ENTERING_PEN    4
#define GHOSTSTATE_WAITING_PEN     5
#define GHOSTSTATE_EXITING_PEN     6

#define GHOST_ANIM_CYCLE           6
#define DYING_ANIM_DELAY           3
#define GHOST_BLINK_DURATION       20

#define SPLASHSCREEN_DURATION      50
#define BOARD_START_DURATION       30
#define BOARD_COMPLETE_DURATION    40
#define BOARD_COMPLETE_BLINK_CYCLE 10

#define SCORE_PAUSE_DURATION       10

#define GAMEOVER_SCREEN_DURATION   200

#define SQR_PIXEL_TOUCH_DISTANCE   (3 * 3)

#define POINTS_EAT_BALL            10
#define POINTS_EAT_POWERBALL       50

#define MAX_SCORE_PLACES           15


/* GAME DATATYPES ************************************************************/

struct {
  int facingDirection;
  int offsetDirection;
  int intendedDirection;
  int state;
  int animStage;
  int tilePosX;
  int tilePosY;
  int offsetAmount;
  int speed; // goes slower when eating dots
  int spriteNum;
} g_pacmanStatus;

typedef struct {
  int id;
  int offsetDirection;
  int intendedDirection;
  int state;
  int animStage;
  int tilePosX;
  int tilePosY;
  int offsetAmount;
  int speed;
  int normalBodyColour;
  int bodyColour;
  int eyesSpriteNum;
  int waitTime;
} Ghost_status;


/* GAME BOARD DATA ***********************************************************/

char board1[] = {
  0, 0,10,10,10,10,10,10,10,10,10,10,10,10,10, 
  0,11, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,24, 
  6, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 
  6, 4, 1,15, 9, 9,16, 1,15, 9, 9, 9,16, 1, 5, 
  6, 4, 2, 5, 0, 0, 4, 1, 5, 0, 0, 0, 4, 1, 5, 
  6, 4, 1,17, 8, 8,18, 1,17, 8, 8, 8,18, 1,21, 
  6, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
  6, 4, 1,19, 9, 9,20, 1,19,20, 1,19, 9, 9, 9, 
  6, 4, 1,21, 8, 8,22, 1, 5, 4, 1,21, 8, 8,28, 
  6, 4, 1, 1, 1, 1, 1, 1, 5, 4, 1, 1, 1, 1, 5, 
  0,13, 9, 9, 9,31,48, 1, 5,29, 9, 9,20, 0, 5, 
  0, 0, 7, 7, 7,32,33, 1, 5,27, 8, 8,22, 0,21, 
  0, 0, 0, 0, 0, 6, 4, 1, 5, 4, 0, 0, 0, 0, 0, 
  0,10,10,10,10,35,36, 1, 5, 4, 0,23, 9, 9,47, 
 48, 8, 8, 8, 8,34,48, 1,21,22, 0, 5,43, 7, 0, 
  0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 5, 3, 0, 0, 
 48, 9, 9, 9, 9,31,48, 1,19,20, 0, 5,45,10,10, 
  0, 7, 7, 7, 7,32,33, 1, 5, 4, 0,25, 8, 8, 8, 
  0, 0, 0, 0, 0, 6, 4, 1, 5, 4, 0, 0, 0, 0, 0, 
  0, 0,10,10,10,35,36, 1, 5, 4, 0,19, 9, 9, 9, 
  0,11, 8, 8, 8,34,48, 1,21,22, 0,21, 8, 8,28, 
  6, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 
  6, 4, 1,19, 9, 9,20, 1,19, 9, 9, 9,20, 1, 5, 
  6, 4, 1,21, 8,28, 4, 1,21, 8, 8, 8,22, 1,21, 
  6, 4, 2, 1, 1, 5, 4, 1, 1, 1, 1, 1, 1, 1, 0, 
  6,25, 9,20, 1, 5, 4, 1,19,20, 1,19, 9, 9, 9, 
  6,23, 8,22, 1,21,22, 1, 5, 4, 1,21, 8, 8,28, 
  6, 4, 1, 1, 1, 1, 1, 1, 5, 4, 1, 1, 1, 1, 5, 
  6, 4, 1,19, 9, 9, 9, 9,30,29, 9, 9,20, 1, 5, 
  6, 4, 1,21, 8, 8, 8, 8, 8, 8, 8, 8,22, 1,21, 
  6, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
  0,13, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 
  0, 0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,  
};


/* GAME BITMAP DATA **********************************************************/

unsigned char splashScreenBitmap[] = {
  BITMAP_2BPP, 0, 94, 0, 23,
  0x00, 0x00, 0xF4, 0x7F, 0x40, 0xFF, 0x07, 0xF4, 0x7F, 0x40, 0xFF,
  0x07, 0xF4, 0x3F, 0xD0, 0xFF, 0x01, 0xFD, 0x1F, 0x10, 0xC0, 0x01,
  0x00, 0x00, 0x00, 0x00, 0xFD, 0xF0, 0xD1, 0xFF, 0x1F, 0x3D, 0xF0,
  0xD1, 0x03, 0x1F, 0xFD, 0x1F, 0xF4, 0xFF, 0x47, 0x0F, 0x7C, 0xF4,
  0xC1, 0x07, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xF0, 0xF3, 0xFF, 0x3F,
  0x3F, 0xF0, 0xF3, 0x03, 0x3F, 0xFF, 0x07, 0xFC, 0xFF, 0xCF, 0x0F,
  0xFC, 0xFC, 0xC7, 0x0F, 0x00, 0x00, 0x0B, 0x0B, 0xFF, 0xFF, 0xF3,
  0xFF, 0x3F, 0xFF, 0xFF, 0xF3, 0xFF, 0x3F, 0xFF, 0x01, 0xFC, 0xFF,
  0xCF, 0xFF, 0xFF, 0xFC, 0xDF, 0x0F, 0x0B, 0x0B, 0x06, 0x06, 0xFF,
  0x00, 0xF0, 0xFF, 0x3F, 0xFF, 0xFF, 0xF3, 0xFF, 0x3F, 0x7F, 0x00,
  0xFC, 0xFF, 0xCF, 0xFF, 0xFF, 0xFC, 0xFF, 0x0F, 0x06, 0x06, 0x00,
  0x00, 0xFF, 0x00, 0xF0, 0xFD, 0x3D, 0xFF, 0x00, 0xF0, 0x03, 0x3F,
  0xFF, 0x01, 0x7C, 0x7F, 0xCF, 0x0F, 0xFC, 0x7C, 0xFF, 0x0F, 0x00,
  0x00, 0x00, 0x00, 0xFF, 0xFF, 0xF3, 0xFC, 0x3C, 0xFF, 0x00, 0xF0,
  0x03, 0x3F, 0xFF, 0x07, 0x3C, 0x3F, 0xCF, 0x0F, 0xFC, 0x3C, 0xFD,
  0x0F, 0x00, 0x00, 0x00, 0x00, 0xFD, 0xFF, 0xD1, 0xFC, 0x1C, 0xFD,
  0x00, 0xD0, 0x03, 0x1F, 0xFD, 0x1F, 0x34, 0x3F, 0x47, 0x0F, 0x7C,
  0x34, 0xF4, 0x07, 0x00, 0x00, 0x00, 0x00, 0xF4, 0x7F, 0x40, 0x74,
  0x04, 0xF4, 0x00, 0x40, 0x03, 0x07, 0xF4, 0x3F, 0x10, 0x1D, 0x01,
  0x0D, 0x1C, 0x10, 0xD0, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x11, 0x54, 0x50, 0x40, 0x11, 0x14, 0x14, 0x04, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x11, 0x15, 0x04, 0x10, 0x10, 0x41, 0x44, 0x04,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x54, 0x04, 0x05, 0x10, 0x14,
  0x04, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x0C, 0x00, 0xC0, 0x07, 0x00, 0x03, 0x00, 0x00, 0x0C, 0xCC, 0x00,
  0x30, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x0C, 0x00, 0xC0, 0xCC, 0x00, 0x03, 0x00, 0x00, 0x0C,
  0xCC, 0x0C, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x7C, 0xCC, 0xC0, 0x0C, 0x34, 0x1F, 0x3D,
  0x4D, 0x0F, 0x7C, 0x40, 0x33, 0xF3, 0x31, 0x03, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xCC, 0xCC, 0xC0, 0xC7, 0x0C,
  0x33, 0x33, 0xC3, 0x0C, 0xCC, 0xCC, 0xF0, 0x30, 0x33, 0x03, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xCC, 0xCC, 0xC0,
  0xCC, 0x0C, 0x33, 0x33, 0xC3, 0x0C, 0xCC, 0xCC, 0x30, 0x33, 0x33,
  0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7C,
  0xF4, 0xC0, 0xCC, 0x34, 0x33, 0x3D, 0x43, 0x0F, 0xCC, 0xCC, 0x30,
  0xF3, 0xD1, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x70, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC0, 0x01, 0x00, 0x00,
  0x00, 0x00
};

unsigned char boardTilesBitmap[] = {
  BITMAP_2BPP, 0, 192, 0, 4,
  0x00, 0x3C, 0x02, 0x08, 0x20, 0x80, 0xAA, 0x00, 0x00, 0x00, 0xA0,
  0x0A, 0x22, 0x88, 0x00, 0x00, 0x80, 0x02, 0x00, 0x00, 0x20, 0x08,
  0x00, 0x00, 0x20, 0x08, 0x00, 0x00, 0x08, 0x20, 0x00, 0x82, 0x00,
  0x28, 0x80, 0x08, 0x20, 0x02, 0x28, 0x00, 0x82, 0x00, 0xAA, 0xAA,
  0x02, 0x80, 0x00, 0x00, 0x2C, 0xFF, 0x02, 0x08, 0x20, 0x80, 0x00,
  0xAA, 0x00, 0x00, 0x08, 0x20, 0xA2, 0x8A, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x80, 0x02, 0x00, 0x00, 0xA0, 0x0A, 0xA0, 0x0A, 0x08,
  0x20, 0x00, 0x28, 0x02, 0x02, 0x20, 0x02, 0x80, 0x08, 0x80, 0x80,
  0x28, 0x00, 0x02, 0x80, 0x02, 0x80, 0x00, 0x00, 0x18, 0xFF, 0x02,
  0x08, 0x20, 0x80, 0x00, 0x00, 0xAA, 0x00, 0xA2, 0x8A, 0x08, 0x20,
  0x00, 0x00, 0x00, 0x00, 0x80, 0x02, 0x00, 0x00, 0xA0, 0x0A, 0x00,
  0x00, 0x08, 0x20, 0xA0, 0x0A, 0x02, 0x20, 0x02, 0x00, 0x28, 0x02,
  0x80, 0x28, 0x00, 0x80, 0x08, 0x80, 0x02, 0x80, 0x02, 0x80, 0x00,
  0x00, 0x00, 0x3C, 0x02, 0x08, 0x20, 0x80, 0x00, 0x00, 0x00, 0xAA,
  0x22, 0x88, 0xA0, 0x0A, 0x80, 0x02, 0x00, 0x00, 0x20, 0x08, 0x00,
  0x00, 0x20, 0x08, 0x00, 0x00, 0x08, 0x20, 0x00, 0x00, 0x28, 0x80,
  0x08, 0x00, 0x82, 0x00, 0x00, 0x82, 0x00, 0x20, 0x02, 0x28, 0x02,
  0x80, 0xAA, 0xAA, 0xFF, 0x00
};

unsigned char pacmanBitmap[] = {
  BITMAP_1BPP, 0, 84, 0, 6,
  0x30, 0xC3, 0x0C, 0x30, 0xC3, 0x00, 0x00, 0x00, 0x08, 0x79, 0xE0,
  0x79, 0xE7, 0x1E, 0x79, 0xE3, 0x92, 0x00, 0x00, 0x0A, 0xFF, 0xF0,
  0xFF, 0x8E, 0x3F, 0xFC, 0x71, 0xF3, 0xCC, 0x00, 0x30, 0xFF, 0xF0,
  0xFF, 0x8E, 0x33, 0xCC, 0x71, 0xFF, 0xFF, 0xF3, 0x03, 0xFF, 0xF0,
  0x79, 0xE7, 0x12, 0x01, 0xE3, 0x9E, 0x79, 0xE7, 0x94, 0xFF, 0xF0,
  0x30, 0xC3, 0x00, 0x00, 0xC3, 0x0C, 0x30, 0xC3, 0x04, 0xB7, 0x30,
};

unsigned char ghostEyesBitmap[] = {
  BITMAP_1BPP, 0, 20, 0, 3,
  0xFF, 0xFA, 0x50, 0xAF, 0x5A, 0x00, 0xAA, 0x5F, 0x60
};

unsigned char scoreNumbersBitmap[] = {
  BITMAP_1BPP, 0, 30, 0, 3,
  0xEB, 0x6A, 0xE7, 0x7C, 0xA9, 0x3E, 0xB9, 0xFC, 0xE9, 0xE3, 0xB9,
  0xE4
};

unsigned char getReadyBitmap[] = {
  BITMAP_2BPP, 0, 38, 0, 5,
  0x3D, 0x3D, 0x3F, 0xF0, 0x47, 0x4F, 0x1F, 0x7F, 0xCC, 0x0C, 0x03,
  0x03, 0x0C, 0x30, 0xCC, 0xC0, 0x30, 0xC3, 0xCC, 0x0C, 0x03, 0x0F,
  0x0C, 0xF0, 0xC7, 0xC3, 0x3F, 0xC3, 0x74, 0x0C, 0x33, 0x03, 0x0C,
  0x30, 0xCC, 0xC0, 0x30, 0xC3, 0x30, 0x00, 0x3D, 0x3D, 0x0C, 0x30,
  0x4C, 0xCF, 0x30, 0x7F, 0x30, 0x0C
};

unsigned char eatScoresBitmap[] = {
  BITMAP_2BPP, 0, 19, 0, 5,
  0xDF, 0xDC, 0xDD, 0x77, 0x1D, 0xF0, 0x3C, 0x3F, 0xCC, 0x33, 0xFD,
  0xDF, 0xFD, 0xCD, 0x33, 0x07, 0x3C, 0x3F, 0xCF, 0x33, 0x3F, 0xDC,
  0xDD, 0x75, 0x1D
};

unsigned char finalScoreBitmap[] = {
  BITMAP_2BPP, 0, 30, 0, 6,
  0x1D, 0xF3, 0x7D, 0xF3, 0xDF, 0xFF, 0x5D, 0x07, 0xF3, 0x03, 0xC3,
  0xF3, 0x30, 0xD0, 0xF3, 0x0C, 0x33, 0xD3, 0x71, 0xFD, 0xF7, 0x75,
  0x5D, 0x0F, 0x33, 0x73, 0xC0, 0x30, 0x3C, 0x1F, 0x33, 0x0C, 0x33,
  0x33, 0xC0, 0x30, 0x3C, 0x0F, 0x33, 0x0C, 0xDD, 0xFF, 0x7F, 0xF0,
  0xD7, 0x0D, 0x1D, 0x07
};

unsigned char gameOverBitmap[] = {
  BITMAP_2BPP, 0, 83, 0, 16,
  0xF4, 0x7F, 0x40, 0xFF, 0x07, 0xF4, 0x7F, 0x40, 0xFF, 0x07, 0x00,
  0xF4, 0x7F, 0x00, 0x00, 0x00, 0xF4, 0x7F, 0x40, 0xFF, 0x07, 0x3D,
  0xF0, 0xD1, 0x03, 0x1F, 0xFD, 0xFF, 0xD1, 0x0F, 0x1F, 0x00, 0x3D,
  0xF0, 0x11, 0x00, 0x10, 0xFD, 0xF0, 0xD1, 0x03, 0x1F, 0x3F, 0x00,
  0xF0, 0x03, 0x3F, 0xFF, 0xFF, 0xF3, 0x0F, 0x3F, 0x00, 0x3F, 0xF0,
  0x73, 0x00, 0x34, 0xFF, 0xF0, 0xF3, 0x03, 0x3F, 0x3F, 0x00, 0xF0,
  0xFF, 0x3F, 0xFF, 0xFF, 0xF3, 0xFF, 0x3F, 0x00, 0x3F, 0xF0, 0xF3,
  0x01, 0x3D, 0xFF, 0xFF, 0xF3, 0xFF, 0x3F, 0x3F, 0xFC, 0xF3, 0xFF,
  0x3F, 0xFF, 0xFF, 0xF3, 0x0F, 0x00, 0x00, 0x3F, 0xF0, 0xF3, 0x47,
  0x3F, 0xFF, 0x00, 0xF0, 0xFF, 0x3F, 0x3F, 0xF0, 0xF3, 0x03, 0x3F,
  0xDF, 0xDF, 0xF3, 0x0F, 0x00, 0x00, 0x3F, 0xF0, 0xF3, 0xDF, 0x3F,
  0xFF, 0x00, 0xF0, 0xFF, 0x01, 0x3F, 0xF0, 0xF3, 0x03, 0x3F, 0xCF,
  0xCF, 0xF3, 0xFF, 0x3F, 0x00, 0xFF, 0xFF, 0xF3, 0xFF, 0x3F, 0xFF,
  0xFF, 0xF3, 0xDF, 0x07, 0xFD, 0xFF, 0xD1, 0x03, 0x1F, 0xCD, 0xCF,
  0xD1, 0xFF, 0x1F, 0x00, 0xFD, 0xFF, 0xD1, 0xFF, 0x1F, 0xFD, 0xFF,
  0xD1, 0x4F, 0x0F, 0xF4, 0x7F, 0x40, 0x03, 0x07, 0x44, 0x47, 0x40,
  0xFF, 0x07, 0x00, 0xF4, 0x7F, 0x40, 0xFF, 0x07, 0xF4, 0x7F, 0x40,
  0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0xD0, 0xCF, 0x0C, 0xD3, 0xCF, 0x00, 0xD0,
  0xD3, 0xD3, 0x4F, 0x3F, 0x3D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x30, 0xC0, 0x3C, 0x33, 0xCC, 0x00, 0x30, 0x30,
  0x30, 0xCC, 0x30, 0x03, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0xF0, 0xC3, 0xCC, 0xF3, 0xCF, 0x00, 0xF0, 0x33, 0x30,
  0xCC, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x30, 0xC0, 0x0C, 0x33, 0xCC, 0x00, 0x00, 0x33, 0x30, 0xCC,
  0x30, 0x03, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x30, 0xC0, 0x0C, 0x33, 0xCC, 0x0F, 0xF0, 0xF3, 0xF3, 0xCF, 0x30,
  0x3F, 0x00, 0x00, 0x00, 0x00, 0x00
};

unsigned char minimapBitmap[] = {
  BITMAP_1BPP, 0, 17, 0, 22,
  0xFF, 0xFF, 0x80, 0x00, 0x80, 0x00, 0x6E, 0xBB, 0x00, 0x6E, 0xBB,
  0x00, 0x00, 0x00, 0x00, 0x6B, 0xEB, 0x00, 0x08, 0x88, 0x00, 0xEE,
  0xBB, 0x80, 0x28, 0x0A, 0x00, 0xEB, 0x6B, 0x80, 0x02, 0x20, 0x00,
  0xEB, 0xEB, 0x80, 0x28, 0x0A, 0x00, 0xEB, 0xEB, 0x80, 0x00, 0x80,
  0x00, 0x6E, 0xBB, 0x00, 0x20, 0x02, 0x00, 0xAB, 0xEA, 0x80, 0x08,
  0x88, 0x00, 0x7E, 0xBF, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x80
};


/* GLOBAL VARIABLES **********************************************************/

static int g_fd;
static struct timeval g_frameTime;
static int g_terminateApp;
static int g_lastButton;

static char g_gameBoard[BOARD_WIDTH * BOARD_HEIGHT];
static Ghost_status g_ghosts[4];
static int g_oppDirection[5] = {DIR_NONE, DIR_DOWN, DIR_UP,
				DIR_RIGHT, DIR_LEFT};
static int g_yScroll = 0;
static int g_score;
static int g_livesLeft;
static int g_timer;
static int g_blinkTimer;
static int g_blink;
static int g_gameStatus;
static int g_powerBallTimer;
static int g_powerBallDuration;
static int g_ballsRemaining;
static int g_ghostWaitPenTime;
static int g_penExitFree;
static int g_ghostIDJustEaten;
static int g_ghostsEaten;
static int g_timeTillScatter;
static int g_roamDuration;
static int g_mapsCompleted;
static int g_ghostBaseSpeed;
static int g_ballsHurryGhost;
static int g_lastDirectionRequested;


/* FUNCTION PROTOTYPES *******************************************************/

void updateButtonState();
void terminateApp();

void empacman_init();
void empacman_update(void *display, int lastbutton);
void empacman_shutdown();
void resetBoard();
void resetPlayers();
void playingUpdate(void *display);
void dyingUpdate(void *display);
void pacmanTouched();
void powerballEaten();
void boardComplete();
void gameOver();
void drawBoard(char *display, int yOffset, int shade);
void drawPacman(char *display);
void drawGhost(char *display, Ghost_status *status);
void drawGetready(char *display);
void drawInfo(char *display);
void drawScore(char *display);
void drawLivesLeft(char *display);
void drawMinimap(char *display);
void drawFinalScore(char *display);
void focusViewOnPlayer();
void initPacman();
void updatePacman();
void movePacman();
void initGhost(Ghost_status *status);
void updateGhost(Ghost_status *status);
void moveGhost(Ghost_status *status);
int pickDirection(int *directionChoices, int numChoices, Ghost_status *status);
int followTarget(int tileTargetX, int tileTargetY,
		 int *directionChoices, int numChoices, Ghost_status *status);
int fleeTarget(int tileTargetX, int tileTargetY,
	       int *directionChoices, int numChoices, Ghost_status *status);
int findNextChoicePoint(int *x, int *y, int startX, int startY,
			int direction, int targetX, int targetY);
int getEatingSprite(int stage, int direction);
int getEyesSprite(int lookingDirection);
int touchingPacman(Ghost_status *status);
void convertToPixel(int tilePosX, int tilePosY, int offsetDirection,
		    int offsetAmount, int *x, int *y);


/* FUNCTION DEFINITIONS ******************************************************/

int main(int argc, char *argv[])
{

  int rc;
  unsigned char screenbuf[EMPEG_SCREEN_BYTES] = {0,};
  struct timeval lastTime, currentTime, deltaTime;
  unsigned long buttons[22] = {22,
			       IR_TOP_BUTTON_PRESSED,
			       IR_RIGHT_BUTTON_PRESSED,
			       IR_LEFT_BUTTON_PRESSED,
			       IR_BOTTOM_BUTTON_PRESSED,
			       IR_RIO_1_PRESSED,
			       IR_RIO_2_PRESSED,
			       IR_RIO_3_PRESSED,
			       IR_RIO_4_PRESSED,
			       IR_RIO_5_PRESSED,
			       IR_RIO_6_PRESSED,
			       IR_RIO_8_PRESSED,
			       IR_KW_1_PRESSED,
			       IR_KW_2_PRESSED,
			       IR_KW_3_PRESSED,
			       IR_KW_4_PRESSED,
			       IR_KW_5_PRESSED,
			       IR_KW_6_PRESSED,
			       IR_KW_8_PRESSED,
			       IR_KNOB_PRESSED,
			       IR_RIO_CANCEL_PRESSED,
			       IR_KW_STAR_PRESSED};

  hijack_geom_t geom = {0,EMPEG_SCREEN_ROWS-1,0,EMPEG_SCREEN_COLS-1};

  if(fork() != 0) {
    return 0;
  }
  else {
    int pid = getpid();
    
    printf("empacman running as pid %d\n",  pid);

    /* open display */
    g_fd = open("/dev/display", O_RDWR);
    
    while (1) {
      char *menulabels[] = {"empacman", NULL};
      rc = ioctl(g_fd, EMPEG_HIJACK_WAITMENU, menulabels);
      if (rc < 0) {
	perror("failed EMPEG_HIJACK_WAITMENU");
	exit(1);
      }
      rc = ioctl(g_fd, EMPEG_HIJACK_BINDBUTTONS, buttons);
      if (rc < 0) {
	perror("failed EMPEG_HIJACK_BINDBUTTONS");
	exit(1);
      }

      /* app uses full screen */
      rc = ioctl(g_fd, EMPEG_HIJACK_SETGEOM, &geom);

      g_terminateApp = 0;
      vfdlib_fastclear(screenbuf);

      /* initialize the application */
      empacman_init();

      while (!g_terminateApp) {
	gettimeofday(&lastTime, NULL);

	/* show last display change */
	rc = ioctl(g_fd, EMPEG_HIJACK_DISPWRITE, screenbuf);

	/* update state of buttons */
	updateButtonState();

	/* update the application */
	empacman_update(screenbuf, g_lastButton);
	
	/* calculate sleep time to required maintain desired FPS */
	deltaTime.tv_usec = 0;
	while (deltaTime.tv_usec < GAME_FRAME_TIME_uSEC) {
	  gettimeofday(&currentTime, NULL);
	  timersub(&currentTime, &lastTime, &deltaTime);
	}
      }
    }
    /* clean up the application */
    empacman_shutdown();
  }
}

void updateButtonState() {

  int rc;
  unsigned long buttoncode;

  g_lastButton = DIR_NONE;
  
  /* read any newly pressed buttons */
  while ((rc = ioctl(g_fd, EMPEG_HIJACK_POLLBUTTONS, &buttoncode)) >= 0) {

    switch (buttoncode) {
    case IR_TOP_BUTTON_PRESSED:
    case IR_RIO_2_PRESSED:
    case IR_KW_2_PRESSED:
      g_lastButton = DIR_UP;
      break;
    case IR_RIGHT_BUTTON_PRESSED:
    case IR_RIO_3_PRESSED:
    case IR_RIO_6_PRESSED:
    case IR_KW_3_PRESSED:
    case IR_KW_6_PRESSED:
      g_lastButton = DIR_RIGHT;
      break;
    case IR_LEFT_BUTTON_PRESSED:
    case IR_RIO_1_PRESSED:
    case IR_RIO_4_PRESSED:
    case IR_KW_1_PRESSED:
    case IR_KW_4_PRESSED:
      g_lastButton = DIR_LEFT;
      break;
    case IR_BOTTOM_BUTTON_PRESSED:
    case IR_RIO_5_PRESSED:
    case IR_RIO_8_PRESSED:
    case IR_KW_5_PRESSED:
    case IR_KW_8_PRESSED:
      g_lastButton = DIR_DOWN;
      break;
    case IR_KNOB_PRESSED:
    case IR_RIO_CANCEL_PRESSED:
    case IR_KW_STAR_PRESSED:
      terminateApp();
      break;
    }
  }
}

void terminateApp() {

  g_terminateApp = 1;
}

void empacman_init() {

  g_mapsCompleted = 0;
  resetBoard();
  resetPlayers();
  g_gameStatus = GAMESTATE_SPLASHSCREEN;
  g_timer = SPLASHSCREEN_DURATION;
  g_score = 0;
  g_livesLeft = 2;
}

void empacman_update(void *display, int lastbutton) {

  int shade, i;

  if (lastbutton != DIR_NONE) g_lastDirectionRequested = lastbutton;

  switch (g_gameStatus) {
  case GAMESTATE_SPLASHSCREEN:
    g_timer--;
    vfdlib_fastclear(display);
    vfdlib_drawBitmap(display, splashScreenBitmap,
		      17, 5,
		      0, 0,
		      -1, -1, -1, 0);
    vfdlib_drawBitmap(display, finalScoreBitmap,
		      105, 14, GAME_VERSION*3, 0, 3, -1, VFDSHADE_DIM, 0);
    if (g_timer<=0) {
      g_gameStatus = GAMESTATE_BOARDSTART;
      g_timer = BOARD_START_DURATION;
    }
    break;
  case GAMESTATE_BOARDSTART:
    g_timer--;
    vfdlib_fastclear(display);
    focusViewOnPlayer();
    g_yScroll -= g_timer << 1;
    drawBoard(display, g_yScroll, -1);
    g_pacmanStatus.spriteNum = 0;
    drawPacman(display);
    for (i=0;i<4;i++) {
      if (++g_ghosts[i].animStage > (GHOST_ANIM_CYCLE<<1))
	g_ghosts[i].animStage = 0;
      drawGhost(display, &g_ghosts[i]);
    }
    drawInfo(display);
    drawGetready(display);
    if (g_timer<=0) {
      g_gameStatus = GAMESTATE_PLAYING;
    }
    break;
  case GAMESTATE_PLAYING:
    playingUpdate(display);
    break;
  case GAMESTATE_SCOREPAUSE:
    g_timer--;
    focusViewOnPlayer();
    vfdlib_fastclear(display);
    drawBoard(display, g_yScroll, -1);
    drawPacman(display);
    for (i=0;i<4;i++) {
      if (i != g_ghostIDJustEaten) drawGhost(display, &g_ghosts[i]);
      else {
	int posX, posY;

	convertToPixel(g_ghosts[i].tilePosX, g_ghosts[i].tilePosY,
		       g_ghosts[i].offsetDirection, g_ghosts[i].offsetAmount,
		       &posX, &posY);

	// centre score display
	posX -= 4;
	posY -= 2 + g_yScroll;
	// display score
	if (g_ghostsEaten < 4) {
	  vfdlib_drawBitmap(display, eatScoresBitmap,
			    posX, posY,
			    (g_ghostsEaten-1)*3, 0,
			    3, -1, -1, 0);
	  vfdlib_drawBitmap(display, eatScoresBitmap,
			    posX+3, posY,
			    13, 0,
			    6, -1, -1, 0);
	} else {
	  vfdlib_drawBitmap(display, eatScoresBitmap,
			    posX, posY,
			    9, 0,
			    10, -1, -1, 0);
	}
      }
    }
    drawInfo(display);
    if (g_timer<=0) {
      g_gameStatus = GAMESTATE_PLAYING;
    }    
    break;
  case GAMESTATE_BOARDCOMPLETE:
    g_timer--;
    vfdlib_fastclear(display);
    shade = -1;
    if (g_timer % BOARD_COMPLETE_BLINK_CYCLE <
	(BOARD_COMPLETE_BLINK_CYCLE >> 1))
      shade = VFDSHADE_BRIGHT;
    drawBoard(display, g_yScroll, shade);
    g_pacmanStatus.spriteNum = 0;
    drawPacman(display);
    drawInfo(display);
    if (g_timer<=0) {
      resetBoard();
      resetPlayers();
      g_gameStatus = GAMESTATE_BOARDSTART;
      g_timer = BOARD_START_DURATION;
    }
    break;
  case GAMESTATE_DYING:
    dyingUpdate(display);
    break;
  case GAMESTATE_GAMEOVER:
    g_timer--;
    vfdlib_fastclear(display);
    vfdlib_drawBitmap(display, gameOverBitmap,
		      22, 3,
		      0, 0,
		      -1, -1, -1, 0);
    drawFinalScore(display);
    if (g_timer<=0) terminateApp();
    break;
  }
}

void empacman_shutdown() {

  vfdlib_unregisterAllFonts();
}

void resetBoard() {

  int x, y;
  char tileIndex;
  char flippedTiles[] = { 0, 1, 2, 6, 5, 4, 3, 7, 8, 9,
			 10,12,11,14,13,16,15,18,17,20,
			 19,22,21,24,23,26,25,28,27,30,
			 29,42,41,40,39,38,37,36,35,34,
			 33,32,31,44,43,46,45,47,48};
  unsigned char bitmask;
  unsigned char *g_minimapBitmapPtr;
  int tileCount, xOffs, yOffs;

  g_ballsRemaining = 0;

  for (y=0; y<BOARD_HEIGHT; y++) {
    for (x=0; x<HALF_BOARD_WIDTH; x++) {
      tileIndex = board1[y*HALF_BOARD_WIDTH+x];
      g_gameBoard[y*BOARD_WIDTH+x] = tileIndex;
      g_gameBoard[(y+1)*BOARD_WIDTH-x-1] = flippedTiles[tileIndex];
      if (tileIndex == 1 || tileIndex == 2) g_ballsRemaining += 2;
    }
  }

  g_blinkTimer = 0;
  g_powerBallTimer = 0;

  // increase difficulty depending on level
  g_powerBallDuration = 200 - (g_mapsCompleted * 10);
  if (g_powerBallDuration < 0) g_powerBallDuration = 0;
  g_ghostWaitPenTime = 100 - (g_mapsCompleted * 10);
  if (g_ghostWaitPenTime < 0) g_ghostWaitPenTime = 0;
  g_roamDuration = 500 + (g_mapsCompleted * 300);
  g_ghostBaseSpeed = PACMAN_EATING_SPEED + (g_mapsCompleted << 1);
  g_ballsHurryGhost = 10 + (g_mapsCompleted * 5);
}

void resetPlayers() {

  initPacman();
  g_ghosts[0].id = 0;
  initGhost(&g_ghosts[0]);
  g_ghosts[1].id = 1;
  initGhost(&g_ghosts[1]);
  g_ghosts[2].id = 2;
  initGhost(&g_ghosts[2]);
  g_ghosts[3].id = 3;
  initGhost(&g_ghosts[3]);
  g_penExitFree = 1;
  g_timeTillScatter = g_roamDuration;
}

void playingUpdate(void *display) {

  int i;

  if (--g_blinkTimer < 0) g_blinkTimer = 5;
  g_blink = g_blinkTimer < 3;

  if (--g_timeTillScatter < 0) {
    g_timeTillScatter = g_roamDuration;
    for (i=0;i<4;i++)
      if (g_ghosts[i].state == GHOSTSTATE_ROAMING)
	g_ghosts[i].state = GHOSTSTATE_SCATTERING;
  }

  if (g_powerBallTimer > 0) g_powerBallTimer--;

  updatePacman();
  for (i=0;i<4;i++) updateGhost(&g_ghosts[i]);

  focusViewOnPlayer();

  vfdlib_fastclear(display);
  drawBoard(display, g_yScroll, -1);
  drawPacman(display);
  for (i=0;i<4;i++) drawGhost(display, &g_ghosts[i]);
  drawInfo(display);
}

void dyingUpdate(void *display) {

  updatePacman(DIR_NONE);
  focusViewOnPlayer();
  g_blink = 0;
  vfdlib_fastclear(display);
  if (g_gameStatus != GAMESTATE_DYING) return;
  drawBoard(display, g_yScroll, -1);
  drawPacman(display);
  drawInfo(display);
}

void pacmanTouched() {

  g_gameStatus = GAMESTATE_DYING;
  g_pacmanStatus.state = PACSTATE_DYING;
  g_pacmanStatus.animStage = 0;
  g_pacmanStatus.spriteNum = 0;  
}

void powerballEaten() {

  int i;
  g_score += POINTS_EAT_POWERBALL;
  g_powerBallTimer = g_powerBallDuration;
  for (i=0;i<4;i++) {
    if (g_ghosts[i].state == GHOSTSTATE_ROAMING ||
	g_ghosts[i].state == GHOSTSTATE_SCATTERING) {
      int directionChoices[4], numChoices = 0;
 
      g_ghosts[i].state = GHOSTSTATE_FLEEING;

      if (g_ghosts[i].tilePosX < 1 || g_ghosts[i].tilePosX > 28) {
	directionChoices[numChoices++] = DIR_LEFT;
	directionChoices[numChoices++] = DIR_RIGHT;
      } else {
	if (g_gameBoard[(g_ghosts[i].tilePosY-1)*BOARD_WIDTH
		       +g_ghosts[i].tilePosX] < 3)
	  directionChoices[numChoices++] = DIR_UP;
	if (g_gameBoard[(g_ghosts[i].tilePosY+1)*BOARD_WIDTH
		       +g_ghosts[i].tilePosX] < 3)
	  directionChoices[numChoices++] = DIR_DOWN;
	if (g_gameBoard[g_ghosts[i].tilePosY*BOARD_WIDTH
		       +(g_ghosts[i].tilePosX-1)] < 3)
	  directionChoices[numChoices++] = DIR_LEFT;
	if (g_gameBoard[g_ghosts[i].tilePosY*BOARD_WIDTH
		       +(g_ghosts[i].tilePosX+1)] < 3)
	  directionChoices[numChoices++] = DIR_RIGHT;
      }
      g_ghosts[i].intendedDirection =
	fleeTarget(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
		   directionChoices, numChoices, &g_ghosts[i]);
    }
  }
  g_ghostsEaten = 0;
}

void boardComplete() {

  g_gameStatus = GAMESTATE_BOARDCOMPLETE;
  g_timer = BOARD_COMPLETE_DURATION;
  g_mapsCompleted++;
}

void gameOver() {

  g_gameStatus = GAMESTATE_GAMEOVER;
  g_timer = GAMEOVER_SCREEN_DURATION;
}

void drawBoard(char *display, int yOffset, int shade) {

  int x, y, tileIndex, yTileOffset, yPixelOffset;
  
  yOffset += 3;
  yTileOffset = yOffset >> 2;
  yPixelOffset = yOffset & 0x03;

  for (y=0; y<9; y++) {
    for (x=0; x<BOARD_WIDTH; x++) {
      tileIndex = (int) g_gameBoard[(y+yTileOffset)*BOARD_WIDTH+x];
      if (tileIndex > 0 && ((tileIndex != 2) || g_blink)) {
	vfdlib_drawBitmap(display, boardTilesBitmap,
			  (x << 2) - 3, (y << 2) - yPixelOffset,
			  (tileIndex-1) << 2, 0,
			  4, 4, shade, 0);
      }
    }
  }
}

void drawPacman(char *display) {

  int posX, posY;
  
  convertToPixel(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
		 g_pacmanStatus.offsetDirection, g_pacmanStatus.offsetAmount,
		 &posX, &posY);

  // clip pacman
  vfdlib_setClipArea(1, 0, 113, VFD_HEIGHT);  
  vfdlib_drawBitmap(display, pacmanBitmap,
		    posX - 4, posY - g_yScroll - 4,
		    g_pacmanStatus.spriteNum * 6, 0,
		    6, 6, -1, 1); 
  vfdlib_setClipArea(0, 0, VFD_WIDTH, VFD_HEIGHT);
}

void drawGhost(char *display, Ghost_status *status) {

  int posX, posY;

  convertToPixel(status->tilePosX, status->tilePosY, status->offsetDirection,
		 status->offsetAmount, &posX, &posY);

  // clip ghost
  vfdlib_setClipArea(1, 0, 113, VFD_HEIGHT);
  // draw body
  if (status->bodyColour > 0) {
    vfdlib_drawBitmap(display, pacmanBitmap,
		      posX - 4, posY - g_yScroll - 4,
		      status->animStage < GHOST_ANIM_CYCLE ? 12*6 : 13*6, 0,
		      6, 6, status->bodyColour, 1);
  } 
  // draw eyes
  if (status->eyesSpriteNum == 5) { // draw stunned eyes 
    vfdlib_drawBitmap(display, ghostEyesBitmap,
		      posX - 3, posY - g_yScroll - 3,
		      4 * 4, 0,
		      4, -1, VFDSHADE_BLACK, 1);
  } else if (status->eyesSpriteNum > 0) {
    vfdlib_drawBitmap(display, ghostEyesBitmap,
		      posX - 3, posY - g_yScroll - 3,
		      (status->eyesSpriteNum-1) * 4, 0,
		      4, -1, VFDSHADE_BRIGHT, 0);
  } 
  vfdlib_setClipArea(0, 0, VFD_WIDTH, VFD_HEIGHT);
}

void drawGetready(char *display) {

  vfdlib_drawBitmap(display, getReadyBitmap, 38, 68 - g_yScroll,
		    0, 0, -1, -1, -1, 0);
}

void drawInfo(char *display) {

  drawMinimap(display);
  drawScore(display);
  drawLivesLeft(display);
}

void drawScore(char *display) {

  int i;
  int score = g_score;
  int place = 0;
  signed char scorechars[MAX_SCORE_PLACES];

  for (i=0; i<MAX_SCORE_PLACES; i++) scorechars[i] = -1;
  while (score > 0 && place < MAX_SCORE_PLACES) {
    scorechars[place] = score % 10;
    score /= 10;
    place++;
  }

  for (i=0; i<MAX_SCORE_PLACES; i++) {
    char text[2];
    int c = scorechars[MAX_SCORE_PLACES-1-i];
    if (c >= 0) {
      vfdlib_drawBitmap(display, scoreNumbersBitmap,
			i<<2, 0, c*3, 0, 3, 3, VFDSHADE_DIM, 1);
    }
  }
}

void drawLivesLeft(char *display) {

  int x, y, lives = g_livesLeft;

  x = 113;
  y = 26;

  while (lives > 0 && x < 128) {
    vfdlib_drawBitmap(display, pacmanBitmap,
		      x, y, 6, 0, 6, 6, VFDSHADE_BRIGHT, 1);
    x += 5;
    lives--;
  }
}

void drawMinimap(char *display) {

  int shift, i;

  vfdlib_drawBitmap(display, minimapBitmap,
		    111, 4,
		    0, 0,
		    -1, -1, VFDSHADE_DIM, 0);
  if (g_blink) {
    vfdlib_drawPointClipped(display,
			    110 + (((g_pacmanStatus.tilePosX * 2) - 1) / 3),
			    ((g_pacmanStatus.tilePosY * 2) / 3)+4,
			    VFDSHADE_BRIGHT);
    for (i=0;i<4;i++)
      vfdlib_drawPointClipped(display,
			      110 + (((g_ghosts[i].tilePosX * 2) - 1) / 3),
			      ((g_ghosts[i].tilePosY * 2) / 3)+4,
			      VFDSHADE_MEDIUM); 
  }
}

void drawFinalScore(char *display) {

  int i;
  int score = g_score;
  int place = 0;
  signed char scorechars[MAX_SCORE_PLACES];

  for (i=0; i<MAX_SCORE_PLACES; i++) scorechars[i] = -1;
  while (score > 0 && place < MAX_SCORE_PLACES) {
    scorechars[place] = score % 10;
    score /= 10;
    place++;
  }

  for (i=0; i<MAX_SCORE_PLACES; i++) {
    char text[2];
    int c = scorechars[MAX_SCORE_PLACES-1-i];
    if (c >= 0) {
      vfdlib_drawBitmap(display, finalScoreBitmap,
			(i<<2)+10, 22, c*3, 0, 3, -1, -1, 0);
    }
  }
}

void focusViewOnPlayer() {

  int temp;

  convertToPixel(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
		 g_pacmanStatus.offsetDirection, g_pacmanStatus.offsetAmount,
		 &temp, &g_yScroll);

  g_yScroll -= 16;
  if (g_yScroll < 0) g_yScroll = 0;
  if (g_yScroll > 94) g_yScroll = 94;
}

void initPacman() {

  g_lastDirectionRequested = DIR_NONE;
  g_pacmanStatus.intendedDirection = DIR_LEFT;
  g_pacmanStatus.facingDirection = DIR_LEFT;
  g_pacmanStatus.state = PACSTATE_ALIVE;
  g_pacmanStatus.animStage = 0;
  g_pacmanStatus.tilePosX = 14;
  g_pacmanStatus.tilePosY = 24;
  g_pacmanStatus.offsetDirection = DIR_RIGHT;
  g_pacmanStatus.offsetAmount = 2 << SUB_PIXEL_BITS;
  g_pacmanStatus.speed = PACMAN_FREE_SPEED;
  g_pacmanStatus.spriteNum = 0;
}

void updatePacman() {

  switch (g_pacmanStatus.state) {
  case PACSTATE_WAITING:
    break;
  case PACSTATE_ALIVE:
    movePacman();
    if (g_pacmanStatus.animStage > 3) g_pacmanStatus.animStage = 0;
    g_pacmanStatus.spriteNum = getEatingSprite(g_pacmanStatus.animStage,
					       g_pacmanStatus.facingDirection);
    break;
  case PACSTATE_DYING:
    g_pacmanStatus.animStage++;
    if (g_pacmanStatus.animStage > DYING_ANIM_DELAY) {
      g_pacmanStatus.animStage = 0;
      if (g_pacmanStatus.spriteNum < 7) g_pacmanStatus.spriteNum = 7;
      else {
	g_pacmanStatus.spriteNum++;
	if (g_pacmanStatus.spriteNum > 11) {
	  resetPlayers();
	  g_gameStatus = GAMESTATE_BOARDSTART;
	  g_timer = BOARD_START_DURATION;
	  g_livesLeft--;
	  if (g_livesLeft < 0) gameOver();
	}
      }
    }
    break;
  }
}

void movePacman() {

  int intendedTileX, intendedTileY, tileIndex;

  g_pacmanStatus.animStage++; // animate mouth

  if (g_lastDirectionRequested != DIR_NONE)
    g_pacmanStatus.intendedDirection = g_lastDirectionRequested;
  if (g_pacmanStatus.intendedDirection == DIR_NONE)
    g_pacmanStatus.intendedDirection = g_pacmanStatus.facingDirection;

  // check for direction flips
  switch (g_lastDirectionRequested) {
  case DIR_UP:
    if (g_pacmanStatus.facingDirection == DIR_DOWN) {
      g_pacmanStatus.facingDirection = DIR_UP;
      return;
    }
    break;
  case DIR_DOWN:
    if (g_pacmanStatus.facingDirection == DIR_UP) {
      g_pacmanStatus.facingDirection = DIR_DOWN;
      return;
    }
    break;
  case DIR_LEFT:
    if (g_pacmanStatus.facingDirection == DIR_RIGHT) {
      g_pacmanStatus.facingDirection = DIR_LEFT;
      return;
    }
    break;
  case DIR_RIGHT:
    if (g_pacmanStatus.facingDirection == DIR_LEFT) {
      g_pacmanStatus.facingDirection = DIR_RIGHT;
      return;
    }
    break; 
  }

  if (g_pacmanStatus.offsetDirection == g_pacmanStatus.facingDirection) {
    g_pacmanStatus.offsetAmount += g_pacmanStatus.speed;
    if (g_pacmanStatus.offsetAmount > (2 << SUB_PIXEL_BITS)) {
      switch (g_pacmanStatus.offsetDirection) {
      case DIR_UP:
	g_pacmanStatus.tilePosY--;
	g_pacmanStatus.offsetDirection = DIR_DOWN;
	break;
      case DIR_DOWN:
	g_pacmanStatus.tilePosY++;
	g_pacmanStatus.offsetDirection = DIR_UP;
	break;
      case DIR_LEFT:
	g_pacmanStatus.tilePosX--;
	// wrap around
	if (g_pacmanStatus.tilePosX < 0) g_pacmanStatus.tilePosX = 30;
	g_pacmanStatus.offsetDirection = DIR_RIGHT;
	break;
      case DIR_RIGHT:
	g_pacmanStatus.tilePosX++;
	// wrap around
	if (g_pacmanStatus.tilePosX > 29) g_pacmanStatus.tilePosX = 0;
	g_pacmanStatus.offsetDirection = DIR_LEFT;
	break;
      }
      g_pacmanStatus.offsetAmount = (2 << SUB_PIXEL_BITS)
	- (g_pacmanStatus.offsetAmount - (2 << SUB_PIXEL_BITS));
    }
  } else {
    g_pacmanStatus.offsetAmount -= g_pacmanStatus.speed;
    if (g_pacmanStatus.offsetAmount <= 0) {
      intendedTileX = g_pacmanStatus.tilePosX;
      intendedTileY = g_pacmanStatus.tilePosY;
      switch (g_pacmanStatus.intendedDirection) {
      case DIR_UP:
	intendedTileY--;
	break;
      case DIR_DOWN:
	intendedTileY++;
	break;
      case DIR_LEFT:
	intendedTileX--;
	break;
      case DIR_RIGHT:
	intendedTileX++;
	break;      
      }
      if (intendedTileX < 0 || intendedTileX > 29) tileIndex = 0;
      else tileIndex = (int) g_gameBoard[intendedTileY*BOARD_WIDTH
					+intendedTileX];
      if (tileIndex > 2) { // obstructed
	// test current direction instead
	intendedTileX = g_pacmanStatus.tilePosX;
	intendedTileY = g_pacmanStatus.tilePosY;
	switch (g_pacmanStatus.facingDirection) {
	case DIR_UP:
	  intendedTileY--;
	  break;
	case DIR_DOWN:
	  intendedTileY++;
	  break;
	case DIR_LEFT:
	  intendedTileX--;
	  break;
	case DIR_RIGHT:
	  intendedTileX++;
	  break;      
	}
	tileIndex = (int) g_gameBoard[intendedTileY*BOARD_WIDTH+intendedTileX];
	if (tileIndex > 2) { // obstructed - can't move
	  g_pacmanStatus.offsetDirection = DIR_NONE;
	  g_pacmanStatus.intendedDirection = DIR_NONE;
	  g_pacmanStatus.offsetAmount = 0;
	  g_pacmanStatus.animStage = 1; // freeze mouth
	} else {
	  g_pacmanStatus.intendedDirection = g_pacmanStatus.facingDirection;
	}
      }
      if (tileIndex <= 2) {
	// eat the ball
	if (intendedTileX >= 0 && intendedTileX <= 29)
	  g_gameBoard[intendedTileY*BOARD_WIDTH+intendedTileX] = 0;
	if (tileIndex != 0 && --g_ballsRemaining <= 0) {
	  boardComplete();
	} else {
	  if (tileIndex == 2) powerballEaten();
	  else if (tileIndex == 1) g_score += POINTS_EAT_BALL;
	  g_pacmanStatus.facingDirection = g_pacmanStatus.intendedDirection;
	  g_pacmanStatus.offsetDirection = g_pacmanStatus.intendedDirection;
	  g_pacmanStatus.offsetAmount = -g_pacmanStatus.offsetAmount;
	  
	  if (tileIndex == 0) g_pacmanStatus.speed = PACMAN_FREE_SPEED;
	  // slow down if eating
	  else g_pacmanStatus.speed = PACMAN_EATING_SPEED;
	}
      }
    }
  }
}

void initGhost(Ghost_status *status) {

  status->offsetDirection = DIR_NONE;
  status->intendedDirection = DIR_RIGHT;
  status->state = GHOSTSTATE_ROAMING;
  status->animStage = 0;
  status->tilePosX = 13;
  status->tilePosY = 12;
  status->offsetAmount = 0;
  status->speed = g_ghostBaseSpeed;
  status->eyesSpriteNum = 1;
  switch (status->id) {
  case 0:
    status->normalBodyColour = VFDSHADE_BRIGHT;
    status->tilePosX = 13;
    status->tilePosY = 12;
    break;
  case 1:
    status->normalBodyColour = VFDSHADE_MEDIUM;
    status->tilePosX = 16;
    status->tilePosY = 12;
    break;
  case 2:
    status->normalBodyColour = VFDSHADE_MEDIUM;
    status->state = GHOSTSTATE_WAITING_PEN;
    status->tilePosX = 13;
    status->tilePosY = 15;
    break;
  case 3:
    status->normalBodyColour = VFDSHADE_DIM;
    status->state = GHOSTSTATE_WAITING_PEN;
    status->tilePosX = 16;
    status->tilePosY = 15;
    break;
  }
  status->bodyColour = status->normalBodyColour;
}

void updateGhost(Ghost_status *status) {

  // animate
  if (status->id == 1) status->animStage++;
  if (++status->animStage > (GHOST_ANIM_CYCLE<<1)) status->animStage = 0;

  switch (status->state) {
  case GHOSTSTATE_ROAMING:
  case GHOSTSTATE_SCATTERING:
    status->speed = g_ghostBaseSpeed;
    if (status->tilePosY == 15 && (status->tilePosX < 7 ||
				   status->tilePosX > 22)) {
      // in tunnel
      status->speed -= g_ghostBaseSpeed / 5;
    } else if (status->id == 0 && g_ballsRemaining <= g_ballsHurryGhost) {
      // speed up chasing ghost
      status->speed += g_ghostBaseSpeed / 5;
    }
    moveGhost(status);
    if (touchingPacman(status)) pacmanTouched();
    status->eyesSpriteNum = getEyesSprite(status->intendedDirection);
    break;    
  case GHOSTSTATE_FLEEING:
    status->speed = g_ghostBaseSpeed >> 1;
    if (g_powerBallTimer > GHOST_BLINK_DURATION || g_blink) {
      status->eyesSpriteNum = 5;
      status->bodyColour = VFDSHADE_MEDIUM;
    } else {
      status->eyesSpriteNum = 0;
      status->bodyColour = VFDSHADE_BRIGHT;
    }
    if (g_powerBallTimer <= 0) { // reset ghost
      status->state = GHOSTSTATE_ROAMING;
      status->speed = 256;
      status->bodyColour = status->normalBodyColour;
    } else if (touchingPacman(status)) {
      status->state = GHOSTSTATE_EATEN;
      g_gameStatus = GAMESTATE_SCOREPAUSE;
      g_ghostIDJustEaten = status->id;
      g_timer = SCORE_PAUSE_DURATION;
      g_ghostsEaten++;
      // update score
      switch (g_ghostsEaten) {
      case 1: g_score += 200;
	break;
      case 2: g_score += 400;
	break;
      case 3: g_score += 800;
	break;
      case 4: g_score += 1600;
	break;
      }
    }
    moveGhost(status);
    break;
  case GHOSTSTATE_EATEN:
    status->bodyColour = 0;
    status->speed = g_ghostBaseSpeed << 1;
    moveGhost(status);
    status->eyesSpriteNum = getEyesSprite(status->intendedDirection);
    break;
  case GHOSTSTATE_ENTERING_PEN:
  case GHOSTSTATE_WAITING_PEN:
  case GHOSTSTATE_EXITING_PEN:
    status->speed = g_ghostBaseSpeed >> 1;
    moveGhost(status);
    status->eyesSpriteNum = getEyesSprite(status->intendedDirection);
    break;
  }
}

void moveGhost(Ghost_status *status) {

  int intendedTileX, intendedTileY;
  int directionChoices[4], numChoices = 0;

  if (status->offsetDirection == status->intendedDirection) {
    status->offsetAmount += status->speed;
    if (status->offsetAmount > (2 << SUB_PIXEL_BITS)) {
      switch (status->offsetDirection) {
      case DIR_UP:
	status->tilePosY--;
	status->offsetDirection = DIR_DOWN;
	break;
      case DIR_DOWN:
	status->tilePosY++;
	status->offsetDirection = DIR_UP;
	break;
      case DIR_LEFT:
	status->tilePosX--;
	// wrap around
	if (status->tilePosX < 0) status->tilePosX = 30;
	status->offsetDirection = DIR_RIGHT;
	break;
      case DIR_RIGHT:
	status->tilePosX++;
	// wrap around
	if (status->tilePosX > 29) status->tilePosX = 0;
	status->offsetDirection = DIR_LEFT;
	break;
      }
      if (status->tilePosX < 1 || status->tilePosX > 28) {
	directionChoices[numChoices++] = DIR_LEFT;
	directionChoices[numChoices++] = DIR_RIGHT;
      } else {
	if (g_gameBoard[(status->tilePosY-1)*BOARD_WIDTH+status->tilePosX] < 3)
	  directionChoices[numChoices++] = DIR_UP;
	if (g_gameBoard[(status->tilePosY+1)*BOARD_WIDTH+status->tilePosX] < 3)
	  directionChoices[numChoices++] = DIR_DOWN;
	if (g_gameBoard[status->tilePosY*BOARD_WIDTH+(status->tilePosX-1)] < 3)
	  directionChoices[numChoices++] = DIR_LEFT;
	if (g_gameBoard[status->tilePosY*BOARD_WIDTH+(status->tilePosX+1)] < 3)
	  directionChoices[numChoices++] = DIR_RIGHT;
      }
      status->intendedDirection =
	pickDirection(directionChoices, numChoices, status);

      status->offsetAmount = (2 << SUB_PIXEL_BITS)
	- (status->offsetAmount - (2 << SUB_PIXEL_BITS));
    }
  } else {
    status->offsetAmount -= status->speed;
    if (status->offsetAmount <= 0) {
      status->offsetDirection = status->intendedDirection;
      status->offsetAmount = -status->offsetAmount;
    }
  }
}

int pickDirection(int *directionChoices, int numChoices, Ghost_status *status)
{

  int i, x, y;
  int finalChoices[4];
  int finalNumChoices = 0;

  for (i=0; i<numChoices; i++) {
    if (directionChoices[i] != g_oppDirection[status->intendedDirection])
      finalChoices[finalNumChoices++] = directionChoices[i];
  } 
  
  if (status->state == GHOSTSTATE_EATEN) {

    if (status->tilePosX >= 14 && status->tilePosX <= 15 &&
	status->tilePosY == 12) {
      status->state = GHOSTSTATE_ENTERING_PEN;
      return DIR_DOWN;
    }
    return followTarget(14, 12, finalChoices, finalNumChoices, status);
  } else if (status->state == GHOSTSTATE_ENTERING_PEN) {
    if (status->tilePosY < 15) {
      return DIR_DOWN;
    } else {
      int destPosX = 13 + status->id;
      if (status->tilePosX == destPosX) {
	status->state = GHOSTSTATE_WAITING_PEN;
	status->bodyColour = status->normalBodyColour;
	status->waitTime = g_ghostWaitPenTime;
	return DIR_UP;
      } else if (status->tilePosX < destPosX) {
	return DIR_RIGHT;
      } else {
	return DIR_LEFT;
      }
    }
  } else if (status->state == GHOSTSTATE_WAITING_PEN) {
    if (status->waitTime > 0) status->waitTime--;
    else if (g_penExitFree) {
      status->state = GHOSTSTATE_EXITING_PEN;
      g_penExitFree = 0;
    }

    if (status->intendedDirection == DIR_UP) {
      if (status->tilePosY > 14) return DIR_UP;
      else return DIR_DOWN;
    }
    else {
      if (status->tilePosY < 16) return DIR_DOWN;
      else return DIR_UP;
    }
  } else if (status->state == GHOSTSTATE_EXITING_PEN) {

    if (status->tilePosX < 14) return DIR_RIGHT;
    if (status->tilePosX > 15) return DIR_LEFT;
    if (status->tilePosY > 12) return DIR_UP;
    else {
      if (g_powerBallDuration > 0) {
	status->state = GHOSTSTATE_FLEEING;
      }
      else status->state = GHOSTSTATE_ROAMING;
      g_penExitFree = 1;
      
      return pickDirection(directionChoices, numChoices, status);
    }
  } else if (status->state == GHOSTSTATE_SCATTERING) {

    // get favourite corners
    switch (status->id) {
    case 0:
      x = 2;
      y = 2;
      break;
    case 1:
      x = 2;
      y = 30;
      break;
    case 2:
      x = 27;
      y = 2;
      break;
    case 3:
      x = 27;
      y = 30;
      break; 
    }

    if (status->tilePosX == x && status->tilePosY == y) {
      // reached corner
      status->state = GHOSTSTATE_ROAMING;
      return pickDirection(directionChoices, numChoices, status);
    }

    return followTarget(x, y, finalChoices, finalNumChoices, status);
  } else {

    if (finalNumChoices < 1) return DIR_NONE;
    
    if (status->state == GHOSTSTATE_FLEEING)
      return fleeTarget(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
			finalChoices, finalNumChoices, status);

    if (status->id == 0) {
      return followTarget(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
			  finalChoices, finalNumChoices, status);
    } else if (status->id == 1) {
      
      if (findNextChoicePoint(&x, &y, g_pacmanStatus.tilePosX,
			      g_pacmanStatus.tilePosY,
			      g_pacmanStatus.intendedDirection,
			      status->tilePosX, status->tilePosY)) {
	return followTarget(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
			    finalChoices, finalNumChoices, status);
      } else {
	return followTarget(x, y, finalChoices, finalNumChoices, status);
      }
    } else if (status->id == 2) {
      if (findNextChoicePoint(&x, &y, g_pacmanStatus.tilePosX,
			      g_pacmanStatus.tilePosY,
			      g_pacmanStatus.intendedDirection,
			      status->tilePosX, status->tilePosY)) {
	// shyness behaviour
	return fleeTarget(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
			  directionChoices, numChoices, status);
      } else {
	if (findNextChoicePoint(&x, &y, g_pacmanStatus.tilePosX,
				g_pacmanStatus.tilePosY,
				g_oppDirection[g_pacmanStatus.intendedDirection],
				status->tilePosX, status->tilePosY)) {
	  return followTarget(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
			      finalChoices, finalNumChoices, status);
	} else return followTarget(x, y, finalChoices, finalNumChoices,
				   status);
      }
    } else {
      // random behaviour
      return(finalChoices[rand() % finalNumChoices]);
    }
  }
}

int followTarget(int tileTargetX, int tileTargetY,
		 int *directionChoices, int numChoices, Ghost_status *status) {

  int x, y, dist;
  int i, bestChoice, bestDist=99999999;

  for (i=0; i<numChoices; i++) {
    if (findNextChoicePoint(&x, &y, status->tilePosX, status->tilePosY,
			    directionChoices[i], tileTargetX, tileTargetY)) {
      // direct target hit
      return directionChoices[i];
    }
    x -= tileTargetX;
    y -= tileTargetY;
    dist = x*x + y*y;
    if (dist < bestDist) {
      bestChoice = directionChoices[i];
      bestDist = dist;
    }
  }

  return bestChoice;
}

int fleeTarget(int tileTargetX, int tileTargetY,
	       int *directionChoices, int numChoices, Ghost_status *status) {

  int x, y, dist;
  int i, bestChoice = directionChoices[0], bestDist=-1;

  for (i=0; i<numChoices; i++) {
    if (findNextChoicePoint(&x, &y, status->tilePosX, status->tilePosY,
			    directionChoices[i], tileTargetX, tileTargetY)) {
      // direct target hit
      continue;
    }
    x -= tileTargetX;
    y -= tileTargetY;
    dist = x*x + y*y;
    if (dist > bestDist) {
      bestChoice = directionChoices[i];
      bestDist = dist;
    }
  }

  return bestChoice;
}

int findNextChoicePoint(int *x, int *y, int startX, int startY, int direction,
			int targetX, int targetY) {

  int directionChoices[4], numChoices = 1;
  int hitTarget = 0;
  directionChoices[0] = direction;

  while (numChoices < 2) {

    direction = directionChoices[0];

    switch (direction) {
    case DIR_UP:
      startY--;
      break;
    case DIR_DOWN:
      startY++;
      break;
    case DIR_LEFT:
      startX--;
      if (startX < 1) startX = 28;
      break;
    case DIR_RIGHT:
      startX++;
      if (startX > 28) startX = 1;
      break;
    }

    numChoices = 0;
    if (direction != DIR_DOWN &&
	g_gameBoard[(startY-1)*BOARD_WIDTH+startX] < 3)
      directionChoices[numChoices++] = DIR_UP;
    if (direction != DIR_UP && g_gameBoard[(startY+1)*BOARD_WIDTH+startX] < 3)
      directionChoices[numChoices++] = DIR_DOWN;
    if (direction != DIR_RIGHT &&
	g_gameBoard[startY*BOARD_WIDTH+(startX-1)] < 3)
      directionChoices[numChoices++] = DIR_LEFT;
    if (direction != DIR_LEFT &&
	g_gameBoard[startY*BOARD_WIDTH+(startX+1)] < 3)
      directionChoices[numChoices++] = DIR_RIGHT;
    // check for direct hit
    if (startX == targetX && startY == targetY) hitTarget = 1;
  }

  *x = startX;
  *y = startY;
  return hitTarget;
}

int getEatingSprite(int stage, int direction) {

  if (stage == 0) return 0;
  switch (direction) {
  case DIR_UP:
    if (stage == 2) return 8;
    else return 7;
  case DIR_DOWN:
    if (stage == 2) return 4;
    else return 3;
  case DIR_LEFT:
    if (stage == 2) return 6;
    else return 5;
  case DIR_RIGHT:
    if (stage == 2) return 2;
    else return 1;
  }
}

int getEyesSprite(int lookingDirection) {

  switch (lookingDirection) {
  case DIR_UP:
    return 4;
  case DIR_DOWN:
    return 2;
  case DIR_LEFT:
    return 3;
  case DIR_RIGHT:
    return 1;
  }
  return 0;
}

int touchingPacman(Ghost_status *status) {

  int posX, posY, pacPosX, pacPosY, distance;

  if (g_gameStatus != GAMESTATE_PLAYING) return 0;

  convertToPixel(status->tilePosX, status->tilePosY,
		 status->offsetDirection, status->offsetAmount, &posX, &posY);

  convertToPixel(g_pacmanStatus.tilePosX, g_pacmanStatus.tilePosY,
		 g_pacmanStatus.offsetDirection, g_pacmanStatus.offsetAmount,
		 &pacPosX, &pacPosY);

  distance = ((posX - pacPosX) * (posX - pacPosX))
    + ((posY - pacPosY) * (posY - pacPosY));

  return (distance <= SQR_PIXEL_TOUCH_DISTANCE);
}

void convertToPixel(int tilePosX, int tilePosY, int offsetDirection,
		    int offsetAmount, int *x, int *y)
{

  int roundedPixelOffset = offsetAmount >> SUB_PIXEL_BITS;
  *x = tilePosX << 2;
  *y = tilePosY << 2;
  if (offsetAmount & (0x01 << (SUB_PIXEL_BITS - 1))) roundedPixelOffset++;
  switch (offsetDirection) {
  case DIR_UP:
    *y -= roundedPixelOffset;
    break;
  case DIR_DOWN:
    *y += roundedPixelOffset;
    break;
  case DIR_LEFT:
    *x -= roundedPixelOffset;
    break;
  case DIR_RIGHT:
    *x += roundedPixelOffset;
    break;
  }  
}
